from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.static import serve  # <-- IMPORTANTE para servir media com DEBUG=False
from django.urls import re_path        # <-- para rota regex
from loja.views import handler404, handler500, handler403, handler400

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('loja.urls')),
]

# ------------------------------------------------------------------------------------
# SERVE ARQUIVOS EM MODO DESENVOLVIMENTO (DEBUG=True)
# ------------------------------------------------------------------------------------
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

# ------------------------------------------------------------------------------------
# PERMITIR QUE MEDIA FUNCIONE MESMO COM DEBUG=False
# (Necessário para páginas 404 personalizadas e ngrok)
# ------------------------------------------------------------------------------------
else:
    urlpatterns += [
        re_path(r'^media/(?P<path>.*)$', serve, {
            'document_root': settings.MEDIA_ROOT,
        }),
        re_path(r'^static/(?P<path>.*)$', serve, {
            'document_root': settings.STATIC_ROOT,
        }),
    ]




handler404 = 'loja.views.handler404'
handler500 = 'loja.views.handler500'
handler403 = 'loja.views.handler403'
handler400 = 'loja.views.handler400'