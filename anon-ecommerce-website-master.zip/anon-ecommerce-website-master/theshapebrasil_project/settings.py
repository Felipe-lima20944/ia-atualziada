from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-ki#!-ox$p$$tp6c!xfd)d++)^zml9fi^@+**ktplj^t09a+c7^'
DEBUG = True
# =============================
#       ALLOWED HOSTS
# =============================
ALLOWED_HOSTS = [
    'localhost',
    '127.0.0.1',
    '0.0.0.0',

    '.ngrok.io',
    '.ngrok-free.app',

    # 🔥 seu domínio ngrok
    '5d7a690e0871.ngrok-free.app',
    '7abf67e089e9.ngrok-free.app',  # <-- coloque SEMPRE o novo aqui
]

# =============================
#       APLICATIVOS
# =============================
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',
    'loja',
]

AUTH_USER_MODEL = 'loja.Usuario'

# =============================
#       MIDDLEWARE
# =============================
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',

    'loja.middleware.MaintenanceModeMiddleware',  # MODO MANUTENÇÃO

    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]


ROOT_URLCONF = 'theshapebrasil_project.urls'

# =============================
#         TEMPLATES
# =============================
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [
            BASE_DIR / 'templates',
        ],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'theshapebrasil_project.wsgi.application'

# =============================
#       DATABASE
# =============================
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# =============================
#      PASSWORD VALIDATION
# =============================
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# =============================
#      LOCALE
# =============================
LANGUAGE_CODE = 'pt-br'
TIME_ZONE = 'America/Sao_Paulo'
USE_I18N = True
USE_TZ = True

# =============================
#      ARQUIVOS ESTÁTICOS
# =============================

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']     # Pasta de DEV
STATIC_ROOT = BASE_DIR / 'staticfiles'       # Pasta FINAL (produção)

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# =============================
#      AUTENTICAÇÃO
# =============================
LOGIN_URL = '/conta/entrar/'
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/'

# =============================
#      CSRF PARA NGROK
# =============================
CSRF_COOKIE_HTTPONLY = False
CSRF_COOKIE_SECURE = False
CSRF_COOKIE_SAMESITE = 'Lax'
CSRF_USE_SESSIONS = False

CSRF_TRUSTED_ORIGINS = [
    'http://localhost:8000',
    'https://localhost:8000',

    'http://*.ngrok.io',
    'https://*.ngrok.io',

    'http://*.ngrok-free.app',
    'https://*.ngrok-free.app',

    'https://5d7a690e0871.ngrok-free.app',
    'https://7abf67e089e9.ngrok-free.app',
]

# =============================
#     SESSÃO
# =============================
SESSION_COOKIE_AGE = 1209600
SESSION_SAVE_EVERY_REQUEST = True
SESSION_COOKIE_SECURE = False
SESSION_COOKIE_SAMESITE = 'Lax'

# =============================
#     SEGURANÇA
# =============================
SECURE_SSL_REDIRECT = False
SECURE_PROXY_SSL_HEADER = None

# =============================
#     GEMINI API
# =============================
GEMINI_API_KEY = "AIzaSyDSa1J4rh0QS0JAQgwqqEJgMkxxs4i_DCk"
SITE_URL = 'http://127.0.0.1:8000'

# =============================
#       E-MAIL
# =============================
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'flima20944@gmail.com'
EMAIL_HOST_PASSWORD = 'vdwyxcachuqgcbyg'
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER

