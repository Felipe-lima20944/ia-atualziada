# run_ngrok.py
import os
import sys
import threading
import time
from pyngrok import ngrok

# 🔐 SEU TOKEN CONFIGURADO!
NGROK_AUTH_TOKEN = "2SGYY0H3kHKVP3aDtC0zFgRmTUV_5MBkhknN2G6eVzAJhgEQB"

def start_django():
    """Inicia o servidor Django"""
    print("🚀 Iniciando Django na porta 8000...")
    os.system("python manage.py runserver 8000")

def start_ngrok():
    """Inicia o tunnel ngrok com autenticação"""
    # Espera o Django iniciar
    time.sleep(5)
    
    print("🌐 Configurando ngrok...")
    
    try:
        # 🔐 CONFIGURA O TOKEN DE AUTENTICAÇÃO
        ngrok.set_auth_token(NGROK_AUTH_TOKEN)
        print("✅ Token ngrok configurado!")
        
        print("🌐 Criando tunnel ngrok...")
        
        # Cria tunnel HTTPS (mais seguro)
        public_url = ngrok.connect(8000, bind_tls=True)
        
        print("✅ Ngrok conectado!")
        print(f"🔗 URL Pública: {public_url}")
        print(f"📊 Dashboard: http://localhost:4040")
        print(f"📋 Token: {NGROK_AUTH_TOKEN[:8]}...")  # Mostra apenas os primeiros caracteres
        print("\n" + "="*60)
        print("🎉 SEU SITE DJANGO ESTÁ ONLINE!")
        print(f"🌐 Acesse: {public_url}")
        print("="*60)
        
        return public_url
        
    except Exception as e:
        print(f"❌ Erro no ngrok: {e}")
        print("💡 Verifique sua conexão com a internet!")
        return None

def main():
    """Função principal"""
    
    print("🔐 Ngrok com Autenticação")
    print("="*30)
    print(f"✅ Token configurado: {NGROK_AUTH_TOKEN[:8]}...")
    
    # Inicia Django em thread separada
    django_thread = threading.Thread(target=start_django)
    django_thread.daemon = True
    django_thread.start()
    
    # Inicia ngrok
    public_url = start_ngrok()
    
    # Mantém o script rodando
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 Encerrando...")
        if public_url:
            ngrok.disconnect(public_url.public_url)
        print("✅ Ngrok desconectado!")

if __name__ == "__main__":
    main()