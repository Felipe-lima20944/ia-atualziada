from django.shortcuts import render
from .models import ConfiguracaoSite

class MaintenanceModeMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        # Sempre libera admin
        if request.path.startswith("/admin"):
            return self.get_response(request)

        # Libera arquivos estáticos e mídia
        if request.path.startswith("/static/") or request.path.startswith("/media/"):
            return self.get_response(request)

        # Libera webhooks
        if request.path.startswith("/webhook/"):
            return self.get_response(request)

        config = ConfiguracaoSite.load()

        if not config.manutencao_ativa:
            return self.get_response(request)

        return render(
            request,
            "erros/maintenance.html",
            {
                "mensagem": config.mensagem_manutencao,
                "config": config
            },
            status=503
        )
