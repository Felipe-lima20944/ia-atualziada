import logging
from datetime import timedelta

from django.conf import settings
from django.core.mail import send_mail
from django.core.management.base import BaseCommand
from django.template.loader import render_to_string
from django.utils import timezone
from django.utils.html import strip_tags

from loja.models import AbandonoCarrinho, ConfiguracaoSite

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = "Envia emails de carrinho abandonado para registros pendentes."

    def add_arguments(self, parser):
        parser.add_argument("--minutos", type=int, default=None, help="Janela de inatividade em minutos (override do config).")
        parser.add_argument("--limite", type=int, default=50, help="Limite de emails por execução (padrão 50).")

    def handle(self, *args, **options):
        config = ConfiguracaoSite.load()
        minutos_conf = getattr(config, "abandono_minutos", 45) or 45
        minutos = options["minutos"] if options["minutos"] is not None else minutos_conf
        limite = options["limite"]
        agora = timezone.now()
        limite_tempo = agora - timedelta(minutes=minutos)

        pendentes = (
            AbandonoCarrinho.objects.select_related("carrinho")
            .filter(status="pendente", data_ultimo_evento__lte=limite_tempo, subtotal_snapshot__gt=0)
            .order_by("data_ultimo_evento")[:limite]
        )

        enviados = 0
        for abandono in pendentes:
            try:
                carrinho = abandono.carrinho
                itens = carrinho.itens.select_related("produto")
                if not itens.exists():
                    abandono.status = "ignorado"
                    abandono.save(update_fields=["status", "data_ultimo_evento"])
                    continue

                email_destino = abandono.email_contato
                if not email_destino and carrinho.usuario:
                    email_destino = getattr(carrinho.usuario, "email", "")
                if not email_destino:
                    abandono.status = "ignorado"
                    abandono.save(update_fields=["status", "data_ultimo_evento"])
                    continue

                carrinho_url = f"{getattr(settings, 'SITE_URL', '').rstrip('/')}/carrinho/"
                ctx = {
                    "itens": itens,
                    "subtotal": carrinho.subtotal,
                    "carrinho_url": carrinho_url,
                    "site_url": getattr(settings, "SITE_URL", carrinho_url),
                }
                html_msg = render_to_string("emails/carrinho_abandonado.html", ctx)
                plain_msg = strip_tags(html_msg)

                send_mail(
                    subject="Seu carrinho te espera na The Shape",
                    message=plain_msg,
                    from_email=getattr(settings, "DEFAULT_FROM_EMAIL", None),
                    recipient_list=[email_destino],
                    html_message=html_msg,
                    fail_silently=False,
                )

                abandono.status = "enviado"
                abandono.data_disparo = agora
                abandono.email_contato = email_destino
                abandono.save(update_fields=["status", "data_disparo", "email_contato"])
                enviados += 1
            except Exception as exc:
                logger.exception("Falha ao enviar abandono %s: %s", abandono.id, exc)
                continue

        self.stdout.write(self.style.SUCCESS(f"Abandono: emails enviados {enviados} (janela {minutos} min, limite {limite})."))
