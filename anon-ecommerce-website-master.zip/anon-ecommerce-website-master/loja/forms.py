from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from .models import Usuario, PerfilUsuario, EnderecoEntrega, CupomDesconto

# ==============================================================================
# 1. FORMULÁRIO DE CADASTRO (CORRIGIDO)
# ==============================================================================
class UsuarioRegistrationForm(UserCreationForm):
    """
    Formulário de cadastro personalizado.
    Removemos 'username' pois o login é via email.
    """
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'seu@email.com'
        })
    )
    
    first_name = forms.CharField(
        max_length=30,
        required=True,
        label="Nome",
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Seu nome'
        })
    )
    
    last_name = forms.CharField(
        max_length=30,
        required=True,
        label="Sobrenome",
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Seu sobrenome'
        })
    )
    
    telefone = forms.CharField(
        max_length=20,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '(11) 99999-9999'
        })
    )
    
    cpf = forms.CharField(
        max_length=14,
        required=False,
        label="CPF",
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': '000.000.000-00'
        })
    )
    
    aceita_marketing = forms.BooleanField(
        required=False,
        initial=True,
        label="Desejo receber ofertas e novidades por email",
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        })
    )

    class Meta:
        model = Usuario
        # CORREÇÃO: Removemos 'username' desta lista
        fields = ('email', 'first_name', 'last_name', 'telefone', 'cpf', 'aceita_marketing')
    
    def __init__(self, *args, **kwargs):
        self.is_edition = kwargs.pop('is_edition', False)
        super().__init__(*args, **kwargs)
        
        # Ajustes para edição (se for apenas editar perfil, remove senhas)
        if self.is_edition:
            if 'password' in self.fields: self.fields.pop('password') # Garantia extra
            # UserCreationForm geralmente adiciona fields, mas se herdarmos diferente na edição:
            pass 
        
        # Estilizar todos os campos que ainda não têm classe
        for field_name, field in self.fields.items():
            if 'class' not in field.widget.attrs:
                if isinstance(field.widget, forms.CheckboxInput):
                    field.widget.attrs['class'] = 'form-check-input'
                else:
                    field.widget.attrs['class'] = 'form-control'
    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if email:
            if self.is_edition:
                # Na edição, permitir o próprio email (exclui o usuário atual da verificação)
                if Usuario.objects.filter(email=email).exclude(pk=self.instance.pk).exists():
                    raise ValidationError('Este email já está em uso por outro usuário.')
            else:
                # No cadastro, verificar se email já existe
                if Usuario.objects.filter(email=email).exists():
                    raise ValidationError('Este email já está cadastrado.')
        return email


# ==============================================================================
# 2. FORMULÁRIO DE PERFIL COMPLEMENTAR
# ==============================================================================
class PerfilUsuarioForm(forms.ModelForm):
    """
    Formulário para dados extras do perfil (Endereço padrão, Avatar, etc)
    """
    class Meta:
        model = PerfilUsuario
        fields = ['avatar', 'cpf', 'cnpj', 'cep', 'endereco', 'numero', 'complemento', 'bairro', 'cidade', 'estado', 'pais']
        widgets = {
            'avatar': forms.FileInput(attrs={'class': 'form-control'}),
            'cpf': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '000.000.000-00'}),
            'cnpj': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '00.000.000/0000-00'}),
            'cep': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '00000-000'}),
            'endereco': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Rua, Avenida, etc.'}),
            'numero': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '123'}),
            'complemento': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Apto, Bloco, etc.'}),
            'bairro': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Seu bairro'}),
            'cidade': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Sua cidade'}),
            'estado': forms.Select(attrs={'class': 'form-control'}),
            'pais': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'País'}),
        }


# ==============================================================================
# 3. FORMULÁRIO DE ENDEREÇO DE ENTREGA
# ==============================================================================
class EnderecoEntregaForm(forms.ModelForm):
    """
    Formulário para múltiplos endereços de entrega
    """
    class Meta:
        model = EnderecoEntrega
        fields = ['apelido', 'nome_destinatario', 'telefone', 'cep', 'endereco', 'numero', 'complemento', 'bairro', 'cidade', 'estado', 'pais', 'principal']
        widgets = {
            'apelido': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Casa, Trabalho, etc.'}),
            'nome_destinatario': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nome completo'}),
            'telefone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '(11) 99999-9999'}),
            'cep': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '00000-000'}),
            'endereco': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Rua, Avenida, etc.'}),
            'numero': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '123'}),
            'complemento': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Apto, Bloco, etc.'}),
            'bairro': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Seu bairro'}),
            'cidade': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Sua cidade'}),
            'estado': forms.Select(attrs={'class': 'form-control'}),
            'pais': forms.TextInput(attrs={'class': 'form-control', 'value': 'Brasil', 'readonly': 'readonly'}),
            'principal': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
    
    def clean_cep(self):
        cep = self.cleaned_data.get('cep')
        # Limpeza básica de caracteres não numéricos se necessário
        if cep:
            return cep.replace('-', '').replace('.', '')
        return cep


# ==============================================================================
# 4. FORMULÁRIO DE AFILIADOS (CRIAR CUPOM)
# ==============================================================================
class CupomAfiliadoForm(forms.ModelForm):
    """
    Formulário para o usuário criar seu próprio cupom de parceiro.
    """
    prefixo_sugerido = forms.CharField(
        required=False,
        label="Prefixo sugerido",
        help_text="Opcional: um prefixo para o código, se quiser personalizar.",
        widget=forms.TextInput(
            attrs={
                "class": "form-control",
                "placeholder": "Ex: MEUCANAL",
                "style": "text-transform:uppercase",
            }
        ),
    )

    codigo = forms.CharField(
        required=False,
        widget=forms.TextInput(
            attrs={
                "class": "form-control",
                "placeholder": "Ex: CANALDOJOAO",
                "style": "text-transform:uppercase",
            }
        ),
        label="Código do Cupom",
        help_text="Deixe em branco para gerar automaticamente.",
    )

    class Meta:
        model = CupomDesconto
        fields = ["codigo", "nome"]  # Usuário só edita isso (prefixo é auxiliar)
        widgets = {
            "nome": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Identificação (Ex: Instagram Stories)",
                }
            ),
        }
        labels = {
            "codigo": "Código do Cupom",
            "nome": "Apelido (Controle Interno)",
        }

    def clean_codigo(self):
        codigo = self.cleaned_data.get("codigo", "")
        if not codigo:
            return ""  # deixa o model gerar automaticamente

        codigo = codigo.upper().strip().replace(" ", "")

        # Verifica se já existe (case-insensitive)
        if CupomDesconto.objects.filter(codigo__iexact=codigo).exists():
            raise ValidationError("Este código já está em uso por outro parceiro. Escolha outro.")

        return codigo
