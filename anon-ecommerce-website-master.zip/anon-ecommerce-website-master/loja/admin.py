from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe

from .models import (
    AnaliticsEvento,
    AvaliacaoProduto,
    Badge,
    Banner,
    NewsletterHero,
    NewsletterLead,
    CampanhaCupom,
    Carrinho,
    Categoria,
    ConfiguracaoSite,
    CupomDesconto,
    CupomDescontoUso,
    Depoimento,
    EnderecoEntrega,
    HistoricoStatusPedido,
    HistoricoVisualizacao,
    ItemCarrinho,
    ItemPedido,
    LogPagamento,
    Marca,
    Notificacao,
    Pedido,
    PerfilUsuario,
    Produto,
    ProdutoImagem,
    ProdutoVariacao,
    ProdutoVariacaoImagem,  # NOVO: Importar o modelo de imagens da variação
    AtributoProduto,
    OpcaoAtributo,
    RegistroCashback,
    RegistroPontos,
    Usuario,
    UsuarioBadge,
    Wishlist,
    AbandonoCarrinho,
)


# ═══════════════════════════════════════════════════════════════════════════
# MIXINS
# ═══════════════════════════════════════════════════════════════════════════
class HelpTextMixin:
    """
    Mixin para injetar help_texts descritivos nos forms do admin.
    Defina `help_texts = {"campo": "explicação"}` na classe admin que herda este mixin.
    """

    help_texts = {}

    def _apply_help_texts(self, form):
        if getattr(self, "help_texts", None):
            for field, txt in self.help_texts.items():
                if field in form.base_fields:
                    form.base_fields[field].help_text = txt
        return form

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        return self._apply_help_texts(form)


class ImagePreviewMixin:
    def preview_imagem(self, obj):
        if hasattr(obj, "imagem") and obj.imagem:
            return format_html('<img src="{}" style="width:50px;height:auto;" />', obj.imagem.url)
        if hasattr(obj, "avatar") and obj.avatar:
            return format_html('<img src="{}" style="width:50px;height:50px;border-radius:50%;" />', obj.avatar.url)
        if hasattr(obj, "icone") and obj.icone:
            return format_html('<img src="{}" style="width:40px;height:auto;" />', obj.icone.url)
        if hasattr(obj, "imagem_principal") and obj.imagem_principal:
            return format_html('<img src="{}" style="width:50px;height:auto;" />', obj.imagem_principal.url)
        return "-"

    preview_imagem.short_description = "Prévia"


# ═══════════════════════════════════════════════════════════════════════════
# NOVO: INLINE PARA IMAGENS DA VARIAÇÃO
# ═══════════════════════════════════════════════════════════════════════════
class ProdutoVariacaoImagemInline(admin.TabularInline, ImagePreviewMixin):
    model = ProdutoVariacaoImagem
    extra = 1
    fields = ('imagem', 'preview', 'ordem', 'legenda', 'is_principal')
    readonly_fields = ('preview',)
    
    def preview(self, obj):
        if obj.imagem:
            return format_html(
                '<img src="{}" style="max-height: 50px; max-width: 50px;" />',
                obj.imagem.url
            )
        return "-"
    preview.short_description = "Prévia"


# ═══════════════════════════════════════════════════════════════════════════
# USUÁRIO E PERFIL
# ═══════════════════════════════════════════════════════════════════════════
class PerfilInline(admin.StackedInline):
    model = PerfilUsuario
    can_delete = False
    verbose_name_plural = "Perfil Complementar"


class EnderecoEntregaInline(admin.StackedInline):
    model = EnderecoEntrega
    extra = 0
    classes = ("collapse",)


class UsuarioBadgeInline(admin.TabularInline):
    model = UsuarioBadge
    extra = 0
    readonly_fields = ("data_obtida",)
    classes = ("collapse",)


@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    model = Usuario
    list_display = ("email", "nome_completo", "codigo_referencia", "referido_por", "nivel_fidelidade", "pontos_disponiveis", "saldo_cashback", "is_active")
    list_filter = ("nivel_fidelidade", "is_active", "tipo_cliente", "aceita_marketing")
    search_fields = ("email", "first_name", "last_name", "perfil__cpf", "perfil__cnpj", "codigo_referencia")
    ordering = ("email",)

    fieldsets = (
        (None, {"fields": ("email", "password")}),
        ("Informações Pessoais", {"fields": ("first_name", "last_name", "telefone", "data_nascimento", "tipo_cliente", "aceita_marketing")}),
        (
            "Gamificação & Fidelidade",
            {"fields": (("pontos_totais", "pontos_disponiveis"), ("nivel_fidelidade", "experiencia_xp"), ("saldo_cashback", "total_cashback_recebido"))},
        ),
        ("Sistema de Referência", {"fields": (("codigo_referencia", "referido_por"), "total_referencias"), "classes": ("collapse",)}),
        ("Estatísticas de Compra", {"fields": (("total_gasto", "numero_compras"), ("ticket_medio", "frequencia_compras_dias")), "classes": ("collapse",)}),
        ("Permissões", {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Datas", {"fields": ("last_login", "data_criacao", "data_atualizacao")}),
    )

    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "email",
                    "password1",
                    "password2",
                    "first_name",
                    "last_name",
                    "telefone",
                    "data_nascimento",
                    "tipo_cliente",
                    "aceita_marketing",
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                ),
            },
        ),
    )

    inlines = [PerfilInline, EnderecoEntregaInline, UsuarioBadgeInline]
    readonly_fields = ("data_criacao", "data_atualizacao", "last_login", "codigo_referencia", "total_referencias")

    def nome_completo(self, obj):
        return obj.get_full_name()

    nome_completo.short_description = "Nome completo"


# ═══════════════════════════════════════════════════════════════════════════
# GAMIFICAÇÃO (PONTOS, BADGES, CASHBACK)
# ═══════════════════════════════════════════════════════════════════════════
@admin.register(Badge)
class BadgeAdmin(admin.ModelAdmin, ImagePreviewMixin):
    list_display = ("preview_imagem", "nome", "raridade", "condicao_tipo", "condicao_valor", "pontos_bonus", "ativa")
    list_filter = ("raridade", "ativa", "condicao_tipo")
    search_fields = ("nome", "descricao")
    prepopulated_fields = {"slug": ("nome",)}


@admin.register(UsuarioBadge)
class UsuarioBadgeAdmin(admin.ModelAdmin, ImagePreviewMixin):
    list_display = ("preview_imagem", "usuario", "badge", "data_obtida", "novo")
    list_filter = ("badge__raridade", "novo", "data_obtida")
    search_fields = ("usuario__email", "badge__nome")
    readonly_fields = ("data_obtida",)
    autocomplete_fields = ["usuario", "badge"]


@admin.register(RegistroPontos)
class RegistroPontosAdmin(admin.ModelAdmin):
    list_display = ("usuario", "quantidade", "tipo", "origem", "referencia", "motivo", "pedido", "data_criacao")
    list_filter = ("tipo", "origem", "data_criacao")
    search_fields = ("usuario__email", "motivo", "referencia")
    autocomplete_fields = ["usuario", "pedido"]
    readonly_fields = ("data_criacao",)


@admin.register(RegistroCashback)
class RegistroCashbackAdmin(admin.ModelAdmin):
    list_display = ("usuario", "valor_formatado", "tipo", "origem", "referencia", "motivo", "pedido", "data_criacao")
    list_filter = ("tipo", "origem", "data_criacao")
    search_fields = ("usuario__email", "motivo", "referencia")
    autocomplete_fields = ["usuario", "pedido"]
    readonly_fields = ("data_criacao",)

    def valor_formatado(self, obj):
        return f"R$ {obj.valor:.2f}"

    valor_formatado.short_description = "Valor"


# ═══════════════════════════════════════════════════════════════════════════
# CUPONS
# ═══════════════════════════════════════════════════════════════════════════
class CupomUsoInline(admin.TabularInline):
    model = CupomDescontoUso
    extra = 0
    readonly_fields = ("usuario", "pedido", "valor_desconto", "comissao_gerada", "data_uso")
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(CupomDesconto)
class CupomDescontoAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nome", "tipo_desconto", "valor_desconto", "alcance", "criador", "usos_atuais", "status_validade")
    list_filter = ("ativo", "tipo_desconto", "alcance")
    search_fields = ("codigo", "nome", "criador__email")
    readonly_fields = ("usos_atuais",)
    filter_horizontal = ("produtos_aplicaveis", "categorias_aplicaveis", "usuarios_especificos")
    autocomplete_fields = ("criador",)
    inlines = [CupomUsoInline]

    fieldsets = (
        ("Básico", {"fields": ("codigo", "nome", "descricao", "ativo", "criador", "is_publico_marketplace", ("comissao_afiliado", "preco_venda"))}),
        ("Regras de Desconto", {"fields": (("tipo_desconto", "valor_desconto"), ("valor_maximo_desconto", "valor_minimo_compra"))}),
        ("Limites e Validade", {"fields": (("uso_maximo_total", "uso_maximo_por_usuario", "usos_atuais"), ("data_inicio", "data_fim"))}),
        ("Segmentação", {"fields": ("alcance", "niveis_fidelidade", "usuarios_especificos", "produtos_aplicaveis", "categorias_aplicaveis")}),
        ("Gamificação (Bônus)", {"fields": ("pontos_bonus_ao_usar", "criar_badge_ao_usar", "ativar_cashback_bonus")}),
    )

    def status_validade(self, obj):
        return obj.valido

    status_validade.boolean = True
    status_validade.short_description = "Válido Agora"


@admin.register(CupomDescontoUso)
class CupomDescontoUsoAdmin(admin.ModelAdmin):
    list_display = ("cupom", "usuario", "pedido", "valor_desconto", "comissao_gerada", "data_uso")
    list_filter = ("data_uso",)
    search_fields = ("cupom__codigo", "usuario__email")
    autocomplete_fields = ["cupom", "usuario", "pedido"]
    readonly_fields = ("data_uso",)


@admin.register(CampanhaCupom)
class CampanhaCupomAdmin(admin.ModelAdmin):
    list_display = ("nome", "tipo", "cupom", "total_enviado", "ativa")
    list_filter = ("tipo", "ativa")
    autocomplete_fields = ["cupom"]
    filter_horizontal = ("incluir_usuarios",)


# ═══════════════════════════════════════════════════════════════════════════
# CATÁLOGO - ATUALIZADO PARA MULTIPLAS IMAGENS POR VARIAÇÃO
# ═══════════════════════════════════════════════════════════════════════════
class ProdutoImagemInline(admin.TabularInline, ImagePreviewMixin):
    model = ProdutoImagem
    extra = 1
    fields = ("preview_imagem", "imagem", "ordem", "legenda")
    readonly_fields = ("preview_imagem",)


# NOVO: Inline para variações dentro do produto
# NOVO: Inline para variações dentro do produto
class ProdutoVariacaoInline(admin.StackedInline, ImagePreviewMixin):
    model = ProdutoVariacao
    extra = 0
    fieldsets = (
        ('Identificação', {
            'fields': ('opcoes', 'sku', 'barcode_gtin', 'slug')
        }),
        ('Preços', {
            'fields': ('preco', 'preco_promocional', 'percentual_cashback')
        }),
        ('Estoque', {
            'fields': ('estoque', 'estoque_minimo')
        }),
        ('Dimensões', {
            'fields': ('peso_gramas', 'largura_cm', 'altura_cm', 'profundidade_cm')
        }),
        ('Imagem Principal (Legado)', {
            'fields': ('imagem', 'imagem_preview'),
            'classes': ('collapse',),
        }),
    )
    readonly_fields = ('imagem_preview',)  # Removido 'galeria_preview' aqui
    autocomplete_fields = ["opcoes"]
    show_change_link = True
    
    # Adicionar inline de imagens da variação
    inlines = [ProdutoVariacaoImagemInline]
    
    def imagem_preview(self, obj):
        if obj and obj.imagem:
            return format_html(
                '<img src="{}" style="max-height: 100px; max-width: 100px;" /><br>'
                '<small>Imagem principal (legado)</small>',
                obj.imagem.url
            )
        return "Nenhuma imagem definida"
    imagem_preview.short_description = "Preview"


# NOVO: Admin para imagens da variação
@admin.register(ProdutoVariacaoImagem)
class ProdutoVariacaoImagemAdmin(admin.ModelAdmin, ImagePreviewMixin):
    list_display = ('variacao', 'preview_imagem', 'ordem', 'is_principal', 'legenda')
    list_filter = ('variacao__produto', 'is_principal')
    list_editable = ('ordem', 'is_principal')
    search_fields = ('variacao__sku', 'variacao__produto__nome', 'legenda')
    readonly_fields = ('preview',)
    autocomplete_fields = ['variacao']
    
    def preview(self, obj):
        if obj.imagem:
            return format_html(
                '<img src="{}" style="max-height: 100px; max-width: 100px;" />',
                obj.imagem.url
            )
        return "-"
    preview.short_description = "Preview"


# Admin para ProdutoVariacao (página própria)
@admin.register(ProdutoVariacao)
class ProdutoVariacaoAdmin(admin.ModelAdmin, ImagePreviewMixin):
    list_display = ('produto', 'opcoes_display', 'sku', 'preco_efetivo', 'estoque', 'disponivel', 'imagem_principal_preview')
    list_filter = ('produto', 'produto__categoria', 'produto__marca')
    search_fields = ('produto__nome', 'sku', 'barcode_gtin')
    autocomplete_fields = ["produto", "opcoes"]
    readonly_fields = ('imagem_principal_preview', 'slug')  # Removido 'galeria_preview' aqui
    inlines = [ProdutoVariacaoImagemInline]
    
    fieldsets = (
        ('Informações Gerais', {
            'fields': ('produto', 'opcoes', 'sku', 'barcode_gtin', 'slug')
        }),
        ('Preços e Estoque', {
            'fields': ('preco', 'preco_promocional', 'percentual_cashback', 'estoque', 'estoque_minimo')
        }),
        ('Dimensões', {
            'fields': ('peso_gramas', 'largura_cm', 'altura_cm', 'profundidade_cm')
        }),
        ('Imagens', {
            'fields': ('imagem', 'imagem_principal_preview'),  # Removido 'galeria_preview' aqui
            'classes': ('wide',),
        }),
    )
    
    def opcoes_display(self, obj):
        if obj.pk:
            return ", ".join(obj.opcoes.values_list('valor', flat=True))
        return "-"
    opcoes_display.short_description = 'Combinação'
    
    def imagem_principal_preview(self, obj):
        imagem = obj.imagem_principal
        if imagem:
            return format_html(
                '<img src="{}" style="max-height: 200px; max-width: 200px;" /><br>'
                '<small>Imagem principal da variação</small>',
                imagem.url
            )
        return "Nenhuma imagem definida"
    imagem_principal_preview.short_description = "Imagem Principal"
    
    def imagem_principal_preview_list(self, obj):
        imagem = obj.imagem_principal
        if imagem:
            return format_html(
                '<img src="{}" style="max-height: 50px; max-width: 50px;" />',
                imagem.url
            )
        return "-"
    imagem_principal_preview_list.short_description = "Imagem"
    
    # REMOVIDO COMPLETAMENTE O MÉTODO galeria_preview


@admin.register(Produto)
class ProdutoAdmin(admin.ModelAdmin, ImagePreviewMixin):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.request = None

    def changelist_view(self, request, extra_context=None):
        self.request = request
        return super().changelist_view(request, extra_context)

    def variacoes_count(self, obj):
        return obj.variacoes.count()

    variacoes_count.short_description = "Qtd. Variações"

    def link_afiliado(self, obj):
        if self.request and self.request.user.is_authenticated and hasattr(self.request.user, 'codigo_referencia'):
            url = obj.get_link_afiliado(self.request.user)
            return format_html('<a href="{}" target="_blank">Link Afiliado</a>', url)
        return "-"

    link_afiliado.short_description = "Link Afiliado"

    def link_produto(self, obj):
        from django.urls import reverse
        url = reverse('produto_detalhe', kwargs={'slug': obj.slug})
        return format_html('<a href="{}" target="_blank">Ver Produto</a>', url)

    link_produto.short_description = "Link do Produto"

    list_display = (
        "preview_imagem",
        "nome",
        "sku",
        "preco",
        "preco_antigo",
        "estoque",
        "disponivel",
        "has_variacoes",
        "variacoes_count",
        "estoque_baixo",
        "categoria",
        "link_produto",
        "link_afiliado",
    )
    list_filter = ("disponivel", "categoria", "marca", "is_destaque", "is_oferta_relampago", "has_variacoes")
    search_fields = ("nome", "sku", "descricao_completa")
    prepopulated_fields = {"slug": ("nome",)}
    autocomplete_fields = ["categoria", "marca"]
    inlines = [ProdutoVariacaoInline, ProdutoImagemInline]
    actions = ["marcar_disponivel", "marcar_indisponivel", "sincronizar_disponibilidade"]

    fieldsets = (
        ("Informações Básicas", {"fields": (("nome", "slug"), "sku", "categoria", "marca", "descricao_resumida")}),
        ("Imagens", {"fields": (("imagem_principal", "imagem_hover"),)}),
        (
            "Preço e Estoque",
            {
                "fields": (
                    ("preco", "preco_antigo", "custo"),
                    ("preco_em_pontos",),
                    ("estoque", "estoque_minimo", "disponivel", "has_variacoes"),
                )
            },
        ),
        ("Detalhes do Produto", {"fields": ("descricao_completa", "especificacoes", "sabor", "peso", "tipo_proteina")}),
        ("Badges e Destaques", {"fields": (("is_novo", "is_destaque", "is_mais_vendido", "is_kit"),)}),
        ("Oferta Relâmpago", {"fields": (("is_oferta_relampago", "fim_oferta"), ("limite_estoque_oferta", "unidades_vendidas_oferta")), "classes": ("collapse",)}),
        ("SEO", {"fields": ("meta_titulo", "meta_descricao", "palavras_chave"), "classes": ("collapse",)}),
        ("Cashback & Estatísticas", {"fields": ("percentual_cashback", ("vendas_totais", "visualizacoes"), ("avaliacao_media", "numero_avaliacoes")), "classes": ("collapse",)}),
    )


@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ("nome", "ordem", "ativa", "destaque_mega_menu")
    prepopulated_fields = {"slug": ("nome",)}
    list_editable = ("ordem", "ativa")
    search_fields = ("nome",)


@admin.register(Marca)
class MarcaAdmin(admin.ModelAdmin):
    list_display = ("nome", "ordem", "ativa")
    prepopulated_fields = {"slug": ("nome",)}
    search_fields = ("nome",)


# ═══════════════════════════════════════════════════════════════════════════
# CARRINHO
# ═══════════════════════════════════════════════════════════════════════════
class ItemCarrinhoInline(admin.TabularInline):
    model = ItemCarrinho
    extra = 0
    readonly_fields = ("produto", "variacao", "variacao_display", "quantidade", "preco_unitario", "data_adicao")
    autocomplete_fields = ["produto", "variacao"]

    def has_add_permission(self, request, obj=None):
        return False

    def variacao_display(self, obj):
        if obj.variacao:
            return ", ".join(obj.variacao.opcoes.values_list("valor", flat=True))
        return "-"

    variacao_display.short_description = "Variação"


@admin.register(Carrinho)
class CarrinhoAdmin(admin.ModelAdmin):
    list_display = ("id", "usuario", "session_key", "total_itens", "data_atualizacao")
    readonly_fields = ("data_criacao", "data_atualizacao", "cupom_ativo")
    inlines = [ItemCarrinhoInline]
    search_fields = ("usuario__email", "session_key")


# ═══════════════════════════════════════════════════════════════════════════
# PEDIDOS
# ═══════════════════════════════════════════════════════════════════════════
class ItemPedidoInline(admin.TabularInline):
    model = ItemPedido
    extra = 0
    readonly_fields = (
        "produto",
        "variacao",
        "variacao_opcoes",
        "quantidade",
        "preco_unitario",
        "subtotal",
        "nome_produto",
        "sku_produto",
    )
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


class HistoricoStatusPedidoInline(admin.TabularInline):
    model = HistoricoStatusPedido
    extra = 0
    readonly_fields = ("status_anterior", "status_novo", "data_mudanca", "responsavel", "observacao")
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


class LogPagamentoInline(admin.StackedInline):
    model = LogPagamento
    extra = 0
    readonly_fields = ("evento", "id_externo", "payload_recebido", "data_criacao")
    classes = ("collapse",)

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    list_display = ("numero_pedido", "usuario", "status", "pagamento_status", "total", "itens_count", "data_criacao", "metodo_pagamento")
    list_filter = ("status", "pagamento_status", "metodo_pagamento", "data_criacao")
    search_fields = ("numero_pedido", "usuario__email", "usuario__first_name")
    readonly_fields = (
        "numero_pedido",
        "data_criacao",
        "subtotal",
        "total",
        "desconto_cupom",
        "desconto_fidelidade",
        "pontos_utilizados",
        "valor_pontos_utilizados",
        "cashback_utilizado",
        "valor_frete",
        "asaas_payment_id",
        "asaas_invoice_url",
    )
    inlines = [ItemPedidoInline, HistoricoStatusPedidoInline, LogPagamentoInline]

    fieldsets = (
        ("Dados do Pedido", {"fields": (("numero_pedido", "status"), ("usuario", "data_criacao"))}),
        ("Pagamento", {"fields": (("metodo_pagamento", "pagamento_status"), ("numero_parcelas", "valor_parcela"), "data_pagamento")}),
        ("Integração Asaas", {"fields": ("asaas_customer_id", "asaas_payment_id", "asaas_invoice_url", "asaas_pix_code"), "classes": ("collapse",)}),
        ("Entrega", {"fields": ("endereco_entrega", ("data_envio", "data_entrega"), "codigo_rastreamento")}),
        (
            "Valores",
            {
                "fields": (
                    ("subtotal", "valor_frete"),
                    ("desconto_cupom", "desconto_fidelidade"),
                    ("pontos_utilizados", "valor_pontos_utilizados"),
                    ("cashback_utilizado", "total"),
                )
            },
        ),
        ("Notas", {"fields": ("observacoes",)}),
    )

    def itens_count(self, obj):
        return obj.itens.count()

    itens_count.short_description = "Qtd. Itens"
    itens_count.admin_order_field = "itens__count"


@admin.register(AtributoProduto)
class AtributoProdutoAdmin(admin.ModelAdmin):
    list_display = ("nome", "slug")
    prepopulated_fields = {"slug": ("nome",)}
    search_fields = ("nome",)


@admin.register(OpcaoAtributo)
class OpcaoAtributoAdmin(admin.ModelAdmin):
    list_display = ("atributo", "valor", "slug")
    list_filter = ("atributo",)
    search_fields = ("valor", "atributo__nome")
    autocomplete_fields = ["atributo"]


# ═══════════════════════════════════════════════════════════════════════════
# CONTEÚDO E CONFIGURAÇÃO
# ═══════════════════════════════════════════════════════════════════════════
@admin.register(Banner)
class BannerAdmin(admin.ModelAdmin, ImagePreviewMixin):
    list_display = ("preview_imagem", "titulo", "tipo", "ordem", "ativo", "data_inicio", "data_fim")
    list_editable = ("ordem", "ativo")
    list_filter = ("ativo", "tipo", "cor_botao")
    search_fields = ("titulo", "subtitulo", "texto_destaque")


@admin.register(NewsletterHero)
class NewsletterHeroAdmin(admin.ModelAdmin):
    list_display = ("titulo", "tipo_conteudo_display", "ativo", "mostrar_botao", "ordem")
    list_filter = ("ativo", "mostrar_botao")
    list_editable = ("ativo", "mostrar_botao", "ordem")
    search_fields = ("titulo", "subtitulo")
    readonly_fields = ("preview_imagem", "preview_video", "data_criacao", "data_atualizacao")
    
    fieldsets = (
        ("Conteúdo Principal", {
            "fields": ("titulo", "subtitulo")
        }),
        ("Mídia", {
            "fields": ("imagem", "video", "preview_imagem", "preview_video"),
            "description": "Escolha imagem ou vídeo. Se ambos forem preenchidos, o vídeo terá prioridade."
        }),
        ("Botão de Ação", {
            "fields": ("mostrar_botao", "cta_texto", "cta_link"),
            "description": "Configurações do botão call-to-action"
        }),
        ("Configurações", {
            "fields": ("ativo", "ordem", "data_criacao", "data_atualizacao")
        }),
    )
    
    def tipo_conteudo_display(self, obj):
        """Exibe o tipo de conteúdo na lista"""
        if obj.video:
            return format_html(
                '<span style="background: #4CAF50; color: white; padding: 3px 8px; border-radius: 12px; font-size: 12px;">🎬 Vídeo</span>'
            )
        elif obj.imagem:
            return format_html(
                '<span style="background: #2196F3; color: white; padding: 3px 8px; border-radius: 12px; font-size: 12px;">🖼️ Imagem</span>'
            )
        else:
            return format_html(
                '<span style="background: #9E9E9E; color: white; padding: 3px 8px; border-radius: 12px; font-size: 12px;">📄 Texto</span>'
            )
    
    tipo_conteudo_display.short_description = "Tipo"
    
    def preview_imagem(self, obj):
        """Preview da imagem no admin"""
        if obj.imagem:
            return format_html(
                '<div style="margin-top: 10px;">'
                '<p><strong>Preview da Imagem:</strong></p>'
                f'<img src="{obj.imagem.url}" style="max-width: 300px; max-height: 200px; border-radius: 8px; border: 2px solid #e0e0e0;" />'
                '</div>'
            )
        return format_html('<p style="color: #888;">Nenhuma imagem definida</p>')
    
    preview_imagem.short_description = "Preview da Imagem"
    
    def preview_video(self, obj):
        """Preview do vídeo no admin"""
        if obj.video:
            return format_html(
                '<div style="margin-top: 10px;">'
                '<p><strong>Preview do Vídeo:</strong></p>'
                f'<p>Arquivo: <code>{obj.video.name}</code></p>'
                f'<video controls style="max-width: 300px; max-height: 200px; border-radius: 8px; border: 2px solid #e0e0e0;">'
                f'<source src="{obj.video.url}" type="video/mp4">'
                'Seu navegador não suporta vídeos HTML5.'
                '</video>'
                '</div>'
            )
        return format_html('<p style="color: #888;">Nenhum vídeo definido</p>')
    
    preview_video.short_description = "Preview do Vídeo"
    
    def save_model(self, request, obj, form, change):
        """Validações antes de salvar"""
        # Se tem vídeo, remove a imagem para evitar conflitos
        if obj.video and obj.imagem:
            # Manter apenas o vídeo
            obj.imagem = None
        
        # Se não tem mídia, mas está ativo, avisar
        if obj.ativo and not obj.imagem and not obj.video:
            from django.contrib import messages
            messages.warning(
                request, 
                "Este newsletter está ativo mas não tem imagem nem vídeo. Ele pode não aparecer corretamente."
            )
        
        super().save_model(request, obj, form, change)


@admin.register(NewsletterLead)
class NewsletterLeadAdmin(admin.ModelAdmin):
    list_display = ("email", "criado_em")
    search_fields = ("email",)


@admin.register(AvaliacaoProduto)
class AvaliacaoProdutoAdmin(admin.ModelAdmin):
    list_display = ("produto", "usuario", "avaliacao", "aprovado", "data_criacao")
    list_filter = ("aprovado", "avaliacao")
    search_fields = ("produto__nome", "comentario")
    actions = ["aprovar_avaliacoes", "rejeitar_avaliacoes"]

    def aprovar_avaliacoes(self, request, queryset):
        queryset.update(aprovado=True)

    aprovar_avaliacoes.short_description = "Aprovar avaliações selecionadas"

    def rejeitar_avaliacoes(self, request, queryset):
        queryset.update(aprovado=False)

    rejeitar_avaliacoes.short_description = "Rejeitar avaliações selecionadas"


@admin.register(ConfiguracaoSite)
class ConfiguracaoSiteAdmin(HelpTextMixin, admin.ModelAdmin):
    """
    Admin com help_texts detalhados + exemplos práticos.
    Requer HelpTextMixin para aplicar help_texts dinamicamente no form.
    """

    help_texts = {
        # =========================
        # IDENTIDADE
        # =========================
        "nome_site": "Nome exibido no site e em e-mails. Ex.: The Shape Brasil",
        "logo": "Logo principal do topo. Recomendado: PNG com fundo transparente, 512px.",
        "favicon": "Ícone do navegador. Recomendado: PNG/ICO 32x32 ou 48x48.",

        # =========================
        # CONTATO & SOCIAL
        # =========================
        "email": "E-mail de contato exibido no site. Ex.: contato@theshape.com.br",
        "telefone": "Telefone de atendimento. Ex.: 1133334444",
        "whatsapp": "WhatsApp com DDD (somente números). Ex.: 11950401358",
        "instagram_url": "URL do Instagram da loja. Ex.: https://www.instagram.com/theshapebrasil",
        "facebook_url": "URL do Facebook da loja. Ex.: https://www.facebook.com/theshapebrasil",
        "youtube_url": "URL do canal no YouTube. Ex.: https://www.youtube.com/@theshapebrasil",

        # =========================
        # ECONOMIA & FRETE
        # =========================
        "valor_frete_gratis": "Frete grátis acima deste valor. Ex.: 199,00",
        "valor_frete_padrao": "Frete fallback (quando não calcular). Ex.: 15,00",

        # =========================
        # ABANDONO DE CARRINHO
        # =========================
        "abandono_minutos": "Minutos sem atividade para marcar carrinho como abandonado. Ex.: 45",

        # =========================
        # MANUTENÇÃO
        # =========================
        "manutencao_ativa": "Ativa modo manutenção para toda a loja (bloqueia compras).",
        "mensagem_manutencao": "Texto exibido na página de manutenção. Ex.: Estamos realizando melhorias. Voltamos logo!",

        # =========================
        # GAMIFICAÇÃO GLOBAL
        # =========================
        "pontos_por_real_gasto": "Pontos ganhos por R$1,00 gasto. Ex.: 1,00",
        "valor_ponto_em_reais": "Quanto 1 ponto vale no resgate (R$). Ex.: 0,01",
        "pontos_minimos_cashback": "Mínimo de pontos para converter em cashback. Ex.: 100",
        "cashback_automatico": "Se ligado, aplica cashback padrão em todos os pedidos.",
        "percentual_cashback_padrao": "Cashback (%) aplicado quando automático. Ex.: 2,00 (equivale a 2%).",
        "bonus_pontos_boas_vindas": "Pontos dados no cadastro. Ex.: 0 (recomendado) ou 50.",
        "cashback_saque_minimo": "Valor mínimo para permitir saque. Ex.: 30,00",
        "cashback_saque_maximo": "Valor máximo permitido por saque. Ex.: 300,00",

        # =========================
        # LIMITES DE RESGATE (CHECKOUT)
        # =========================
        "pontos_minimos_resgate": "Mínimo de pontos para liberar uso no checkout. Ex.: 200",
        "cashback_minimo_resgate": "Valor mínimo de cashback para usar no checkout. Ex.: 10,00",
        "max_percentual_pontos_resgate": "Percentual máximo (0 a 100) do subtotal pago com pontos. Ex.: 20",
        "max_percentual_cashback_resgate": "Percentual máximo (0 a 100) pago com cashback. Ex.: 30",

        # =========================
        # REFERÊNCIA / INDICAÇÃO
        # =========================
        "bonus_referencia_referidor": "Bônus (R$) para o padrinho na 1ª compra do indicado. Ex.: 10,00",
        "bonus_referencia_novo": "Bônus (R$) para o novo usuário na 1ª compra. Ex.: 0,00 ou 10,00",
        "referencia_bonus_cadastro_ativo": "Se ligado, paga bônus já no cadastro (sem compra). Recomendado: desmarcado.",
        "referencia_bonus_cadastro_referidor_cashback": "Cashback do padrinho no cadastro. Ex.: 5,00",
        "referencia_bonus_cadastro_novo_cashback": "Cashback do indicado no cadastro. Ex.: 5,00",
        "referencia_bonus_cadastro_referidor_pontos": "Pontos do padrinho no cadastro. Ex.: 50",
        "referencia_bonus_cadastro_novo_pontos": "Pontos do indicado no cadastro. Ex.: 50",

        # =========================
        # DESCONTOS DE FIDELIDADE
        # =========================
        "fidelidade_bronze_pct": "Desconto (%) para Bronze. Ex.: 0,00",
        "fidelidade_prata_pct": "Desconto (%) para Prata. Ex.: 3,00",
        "fidelidade_ouro_pct": "Desconto (%) para Ouro. Ex.: 5,00",
        "fidelidade_platina_pct": "Desconto (%) para Platina. Ex.: 8,00",
        "fidelidade_diamante_pct": "Desconto (%) para Diamante. Ex.: 10,00",

        # =========================
        # METAS DE NÍVEL
        # =========================
        "fidelidade_meta_prata": "Gasto acumulado (R$) para atingir Prata. Ex.: 500,00",
        "fidelidade_meta_ouro": "Gasto acumulado (R$) para atingir Ouro. Ex.: 2000,00",
        "fidelidade_meta_platina": "Gasto acumulado (R$) para atingir Platina. Ex.: 5000,00",
        "fidelidade_meta_diamante": "Gasto acumulado (R$) para atingir Diamante. Ex.: 10000,00",

        # =========================
        # AFILIADOS
        # =========================
        "afiliado_desconto_padrao": "Desconto (%) padrão do cupom/link afiliado. Ex.: 5,00",
        "afiliado_comissao_padrao": "Comissão (%) padrão do afiliado. Ex.: 3,00",
        "afiliado_limite_cupons": "Máximo de cupons ativos por afiliado. Ex.: 5",
        "afiliado_validade_dias": "Validade (dias) do cupom/link gerado. Ex.: 365",
        "afiliado_prefixo_codigo": "Prefixo do código/cupom. Ex.: THESHAPE",
        "afiliado_codigo_auto": "Se ligado, cria código/cupom automaticamente quando necessário.",

        # =========================
        # SEO
        # =========================
        "meta_titulo_padrao": "Título SEO padrão. Ex.: The Shape Brasil | Suplementos, Creatina, Whey e Pré-Treino",
        "meta_descricao_padrao": "Descrição SEO padrão. Ex.: Creatina, whey e pré-treino com entrega rápida. Promoções e cashback.",
    }

    def _existing_fields(self, *names):
        """Evita FieldError se algum campo ainda não existir no model."""
        model_fields = {f.name for f in self.model._meta.get_fields()}
        return [n for n in names if n in model_fields]

    def get_fieldsets(self, request, obj=None):
        afiliados_fields = self._existing_fields(
            "afiliado_desconto_padrao",
            "afiliado_comissao_padrao",
            "afiliado_limite_cupons",
            "afiliado_validade_dias",
            "afiliado_prefixo_codigo",
            "afiliado_codigo_auto",
        )

        fieldsets = (
            ("Identidade", {"fields": self._existing_fields("nome_site", "logo", "favicon")}),

            ("Contato & Social", {"fields": self._existing_fields(
                "email", "telefone", "whatsapp", "instagram_url", "facebook_url", "youtube_url"
            )}),

            # ✅ FIX: sem parênteses extras
            ("Economia & Frete", {"fields": self._existing_fields("valor_frete_gratis", "valor_frete_padrao")}),

            ("Abandono de Carrinho", {"fields": self._existing_fields("abandono_minutos")}),

            ("Modo Manutenção", {
                "description": "Controle total da manutenção pelo admin.",
                "fields": self._existing_fields("manutencao_ativa", "mensagem_manutencao"),
            }),

            ("Gamificação Global", {"fields": self._existing_fields(
                "pontos_por_real_gasto",
                "valor_ponto_em_reais",
                "pontos_minimos_cashback",
                "cashback_automatico",
                "percentual_cashback_padrao",
                "bonus_pontos_boas_vindas",
                "cashback_saque_minimo",
                "cashback_saque_maximo",
            )}),

            ("Limites de Resgate (Checkout)", {
                "description": "Controle quanto do pedido pode ser pago com pontos ou cashback.",
                "fields": self._existing_fields(
                    "pontos_minimos_resgate",
                    "cashback_minimo_resgate",
                    "max_percentual_pontos_resgate",
                    "max_percentual_cashback_resgate",
                ),
            }),

            ("Sistema de Referência", {"fields": self._existing_fields(
                "bonus_referencia_referidor",
                "bonus_referencia_novo",
                "referencia_bonus_cadastro_ativo",
                "referencia_bonus_cadastro_referidor_cashback",
                "referencia_bonus_cadastro_novo_cashback",
                "referencia_bonus_cadastro_referidor_pontos",
                "referencia_bonus_cadastro_novo_pontos",
            )}),

            ("Descontos de Fidelidade", {"fields": self._existing_fields(
                "fidelidade_bronze_pct",
                "fidelidade_prata_pct",
                "fidelidade_ouro_pct",
                "fidelidade_platina_pct",
                "fidelidade_diamante_pct",
            )}),

            ("Metas de Nível", {"fields": self._existing_fields(
                "fidelidade_meta_prata",
                "fidelidade_meta_ouro",
                "fidelidade_meta_platina",
                "fidelidade_meta_diamante",
            )}),
        )

        if afiliados_fields:
            fieldsets = fieldsets + (
                ("Afiliados", {
                    "description": "Configurações globais do programa de afiliados (comissão, validade, prefixos).",
                    "fields": tuple(afiliados_fields),
                }),
            )

        fieldsets = fieldsets + (
            ("SEO Global", {"fields": self._existing_fields("meta_titulo_padrao", "meta_descricao_padrao")}),
        )

        return fieldsets

    def has_add_permission(self, request):
        return not ConfiguracaoSite.objects.exists()




# ═══════════════════════════════════════════════════════════════════════════
# OUTROS
# ═══════════════════════════════════════════════════════════════════════════
@admin.register(Notificacao)
class NotificacaoAdmin(admin.ModelAdmin):
    list_display = ("titulo", "usuario", "tipo", "lida", "data_criacao")
    list_filter = ("tipo", "lida")
    search_fields = ("usuario__email", "mensagem")


@admin.register(AnaliticsEvento)
class AnaliticsEventoAdmin(admin.ModelAdmin):
    list_display = ("tipo_evento", "usuario", "data_evento", "ip_cliente")
    list_filter = ("tipo_evento", "data_evento")
    readonly_fields = ("tipo_evento", "usuario", "produto", "pedido", "dados_adicionais", "ip_cliente", "user_agent", "data_evento")

    def has_add_permission(self, request):
        return False


# Registros simples
admin.site.register(Depoimento)
admin.site.register(Wishlist)
admin.site.register(HistoricoVisualizacao)
admin.site.register(EnderecoEntrega)
admin.site.register(LogPagamento)


@admin.register(AbandonoCarrinho)
class AbandonoCarrinhoAdmin(admin.ModelAdmin):
    list_display = ("carrinho", "email_contato", "subtotal_snapshot", "status", "data_ultimo_evento", "data_disparo")
    list_filter = ("status",)
    search_fields = ("email_contato", "carrinho__usuario__email", "carrinho__session_key")
    readonly_fields = ("data_ultimo_evento", "data_disparo")