import csv
import json
import logging
import re
import requests
from datetime import datetime, timedelta
from decimal import Decimal

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm, PasswordResetForm
from django.contrib.auth import views as auth_views
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.core.mail import send_mail
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import F, Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.utils.html import strip_tags
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.views.generic import DetailView, ListView, TemplateView
from django.template.loader import render_to_string

from .asaas_service import get_asaas_service
from .forms import CupomAfiliadoForm
from .models import *

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════
# HELPERS E UTILIDADES
# ═══════════════════════════════════════════════════════════════════════════

def obter_carrinho(request):
    """Helper para obter carrinho do usuário ou sessão."""
    if request.user.is_authenticated:
        carrinho, _ = Carrinho.objects.get_or_create(usuario=request.user)
    else:
        session_key = request.session.session_key
        if not session_key:
            request.session.create()
            session_key = request.session.session_key
        carrinho, _ = Carrinho.objects.get_or_create(session_key=session_key)
    return carrinho


def obter_carrinho_count(request):
    """Helper para obter contagem de itens no carrinho."""
    try:
        carrinho = obter_carrinho(request)
        return carrinho.total_itens if carrinho else 0
    except Exception:
        return 0


def atualizar_sessao_carrinho(request, carrinho):
    """Atualiza a sessão com a contagem atual do carrinho."""
    try:
        count = carrinho.total_itens if carrinho else 0
        request.session["carrinho_count"] = count
        request.session.modified = True
        return count
    except Exception as e:
        print(f"Erro ao atualizar sessão carrinho: {e}")
        return 0

def processar_abandonos_lazy():
    """Processa abandono de carrinho de forma pregui?osa, disparando emails conforme janela configurada."""
    try:
        if not cache.add("abandono_lock", 1, 60):
            return
        agora = timezone.now()
        try:
            config = ConfiguracaoSite.load()
            janela = getattr(config, "abandono_minutos", 45) or 45
        except Exception:
            janela = 45
        limite_tempo = agora - timedelta(minutes=janela)
        pendentes = (
            AbandonoCarrinho.objects.select_related("carrinho", "carrinho__usuario")
            .filter(status="pendente", data_ultimo_evento__lte=limite_tempo, subtotal_snapshot__gt=0)
            .order_by("data_ultimo_evento")[:5]
        )
        for abandono in pendentes:
            try:
                carrinho = abandono.carrinho
                itens = carrinho.itens.select_related("produto")
                if not itens.exists():
                    abandono.status = "ignorado"
                    abandono.save(update_fields=["status", "data_ultimo_evento"])
                    continue
                email_destino = abandono.email_contato
                if not email_destino and carrinho.usuario:
                    email_destino = getattr(carrinho.usuario, "email", "")
                if not email_destino:
                    abandono.status = "ignorado"
                    abandono.save(update_fields=["status", "data_ultimo_evento"])
                    continue
                carrinho_url = f"{getattr(settings, 'SITE_URL', '').rstrip('/')}/carrinho/"
                ctx = {
                    "itens": itens,
                    "subtotal": carrinho.subtotal,
                    "carrinho_url": carrinho_url,
                    "site_url": getattr(settings, "SITE_URL", carrinho_url),
                }
                html_msg = render_to_string("emails/carrinho_abandonado.html", ctx)
                plain_msg = strip_tags(html_msg)
                send_mail(
                    subject="Seu carrinho te espera na The Shape",
                    message=plain_msg,
                    from_email=getattr(settings, "DEFAULT_FROM_EMAIL", None),
                    recipient_list=[email_destino],
                    html_message=html_msg,
                    fail_silently=False,
                )
                abandono.status = "enviado"
                abandono.data_disparo = agora
                abandono.email_contato = email_destino
                abandono.save(update_fields=["status", "data_disparo", "email_contato"])
            except Exception as exc:
                logger.error(f"Falha abandono lazy {abandono.id}: {exc}")
                continue
    finally:
        cache.delete("abandono_lock")


# ═══════════════════════════════════════════════════════════════════════════
# VIEWS INSTITUCIONAIS
# ═══════════════════════════════════════════════════════════════════════════

def HomeView(request):
    """View principal da home."""
    processar_abandonos_lazy()
    config_site = ConfiguracaoSite.load()
    produtos_ativos = Produto.objects.filter(
        disponivel=True,
        estoque__gt=0,
    ).select_related("categoria", "marca")

    carrinho_count = obter_carrinho_count(request)
    notificacoes_nao_lidas = 0
    try:
        if request.user.is_authenticated:
            notificacoes_nao_lidas = Notificacao.objects.filter(usuario=request.user, lida=False).count()
    except Exception:
        notificacoes_nao_lidas = 0

    all_banners = Banner.objects.filter(ativo=True)
    hero_banners = all_banners.filter(tipo="hero").order_by("ordem")
    cta_cards = list(all_banners.filter(tipo="cta").order_by("ordem")[:2])
    service_boxes = all_banners.filter(tipo="service_box").order_by("ordem")[:10]  # ← ADICIONE ISSO
    
    if not cta_cards:
        cta_cards = list(hero_banners[3:5]) or list(hero_banners[:2])

    context = {
        "config_site": config_site,
        "carrinho_count": carrinho_count,
        "notificacoes_nao_lidas": notificacoes_nao_lidas,
        "produtos_mais_vendidos": produtos_ativos.order_by("-vendas_totais")[:12],
        "categorias": Categoria.objects.filter(ativa=True).order_by("ordem", "nome")[:8],
        "marcas": Marca.objects.filter(ativa=True).order_by("ordem")[:12],
        "banners": hero_banners[:3],
        "cta_cards": cta_cards,
        "service_boxes": service_boxes,  # ← ADICIONE ISSO
        "ofertas_relampago": produtos_ativos.filter(
            is_oferta_relampago=True, fim_oferta__gte=timezone.now()
        ),
        "novos_produtos": produtos_ativos.order_by("-data_criacao")[:8],
        "destaques": produtos_ativos.filter(is_destaque=True)[:8],
        "newsletter_hero": NewsletterHero.objects.filter(ativo=True).order_by("ordem").first(),
    }

    return render(request, "loja/public/home.html", context)


class SobreView(TemplateView):
    template_name = "loja/public/sobre.html"


from django.utils import timezone
from django.views.generic import TemplateView
from loja.models import ConfiguracaoSite, Banner   # <— IMPORTANTE

class ContatoView(TemplateView):
    template_name = "loja/public/contato.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        config = ConfiguracaoSite.objects.first()

        # ░░░ CONTATOS ░░░
        context["contato"] = {
            "email": config.email if config else "",
            "telefone": config.telefone if config else "",
            "whatsapp": config.whatsapp if config else "",
        }

        # ░░░ REDES SOCIAIS ░░░
        context["social"] = {
            "instagram_url": config.instagram_url if config else "",
            "facebook_url": config.facebook_url if config else "",
            "youtube_url": config.youtube_url if config else "",
        }

        # ░░░ BANNERS ░░░
        agora = timezone.now()

        context["banners_hero"] = Banner.objects.filter(
            tipo="hero",
            ativo=True,
            data_inicio__lte=agora
        ).filter(
            models.Q(data_fim__gte=agora) | models.Q(data_fim__isnull=True)
        )

        context["banners_cta"] = Banner.objects.filter(
            tipo="cta",
            ativo=True,
            data_inicio__lte=agora
        ).filter(
            models.Q(data_fim__gte=agora) | models.Q(data_fim__isnull=True)
        )

        context["banners_secundario"] = Banner.objects.filter(
            tipo="secundario",
            ativo=True,
            data_inicio__lte=agora
        ).filter(
            models.Q(data_fim__gte=agora) | models.Q(data_fim__isnull=True)
        )

        return context


def newsletter_inscrever(request):
    """Cria ou reutiliza lead da newsletter e volta para a home."""
    if request.method == "POST":
        email = (request.POST.get("email") or "").strip().lower()
        if email:
            try:
                _, created = NewsletterLead.objects.get_or_create(email=email)
                if created:
                    messages.success(request, "Inscrição realizada com sucesso!")
                else:
                    messages.info(request, "Você já está inscrito na nossa newsletter.")
            except Exception:
                messages.error(request, "Não foi possível concluir a inscrição agora.")
        else:
            messages.error(request, "Informe um e-mail válido.")
    return redirect("home")


def MarcasView(request):
    """Lista todas as marcas ativas em uma página dedicada."""
    carrinho_count = obter_carrinho_count(request)
    notificacoes_nao_lidas = 0
    try:
        if request.user.is_authenticated:
            notificacoes_nao_lidas = Notificacao.objects.filter(usuario=request.user, lida=False).count()
    except Exception:
        notificacoes_nao_lidas = 0

    context = {
        "carrinho_count": carrinho_count,
        "notificacoes_nao_lidas": notificacoes_nao_lidas,
        "marcas": Marca.objects.filter(ativa=True).order_by("ordem", "nome"),
    }
    return render(request, "loja/public/marcas.html", context)


class MarcaDetailView(DetailView):
    model = Marca
    template_name = "loja/catalogo/categoria.html"
    context_object_name = "marca"
    slug_field = "slug"
    slug_url_kwarg = "slug"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["config_site"] = ConfiguracaoSite.load()
        marca = self.object

        produtos = Produto.objects.filter(marca=marca, disponivel=True).select_related("categoria", "marca")

        preco_max = self.request.GET.get("preco_max")
        if preco_max:
            try:
                produtos = produtos.filter(preco__lte=float(preco_max))
            except ValueError:
                pass

        categorias_ids = self.request.GET.getlist("categorias")
        if categorias_ids:
            produtos = produtos.filter(categoria__id__in=categorias_ids)

        apenas_disponivel = self.request.GET.get("disponivel")
        if apenas_disponivel == "true":
            produtos = produtos.filter(estoque__gt=0)

        em_promocao = self.request.GET.get("promocao")
        if em_promocao == "true":
            produtos = produtos.filter(preco_antigo__gt=F("preco"))

        ordenacao = self.request.GET.get("ordenacao", "relevancia")
        if ordenacao == "preco_asc":
            produtos = produtos.order_by("preco")
        elif ordenacao == "preco_desc":
            produtos = produtos.order_by("-preco")
        elif ordenacao == "nome":
            produtos = produtos.order_by("nome")
        elif ordenacao == "novidades":
            produtos = produtos.order_by("-data_criacao")
        elif ordenacao == "mais_vendidos":
            produtos = produtos.order_by("-vendas_totais")
        else:
            produtos = produtos.order_by("-is_destaque", "-vendas_totais")

        paginator = Paginator(produtos, 12)
        page_number = self.request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        carrinho_count = obter_carrinho_count(self.request)

        context["page_obj"] = page_obj
        context["produtos"] = page_obj.object_list
        context["categorias"] = Categoria.objects.filter(ativa=True)
        context["marcas"] = Marca.objects.filter(ativa=True)
        context["ordenacao_atual"] = ordenacao
        context["carrinho_count"] = carrinho_count
        context["marca_atual"] = marca

        return context


class AutocompleteProdutosView(View):
    """Sugestões rápidas para o campo de busca."""

    def get(self, request, *args, **kwargs):
        termo = (request.GET.get("q") or "").strip()
        results = []
        if termo:
            # Categorias
            categorias = (
                Categoria.objects.filter(ativa=True, nome__icontains=termo)
                .order_by("ordem", "nome")[:5]
            )
            for cat in categorias:
                results.append(
                    {
                        "label": f"Categoria: {cat.nome}",
                        "url": reverse("categoria", args=[cat.slug]),
                        "type": "categoria",
                    }
                )

            # Marcas
            marcas = (
                Marca.objects.filter(ativa=True, nome__icontains=termo)
                .order_by("ordem", "nome")[:5]
            )
            for marca in marcas:
                results.append(
                    {
                        "label": f"Marca: {marca.nome}",
                        "url": reverse("marca", args=[marca.slug]),
                        "type": "marca",
                    }
                )

            # Produtos
            produtos = (
                Produto.objects.filter(disponivel=True, nome__icontains=termo)
                .order_by("-vendas_totais")[:8]
            )
            for produto in produtos:
                results.append(
                    {
                        "label": produto.nome,
                        "url": reverse("produto_detalhe", args=[produto.slug]),
                        "type": "produto",
                    }
                )

        return JsonResponse({"results": results})


class FreteCorreiosView(View):
    """
    Calculadora de frete local (estimativa tipo SEDEX).
    Se o subtotal atingir frete grátis, retorna frete zero.
    """

    @staticmethod
    def _regiao_por_uf(uf: str) -> str:
        """Região aproximada pela UF."""
        uf = (uf or "").upper()
        sudeste = {"SP", "RJ", "MG", "ES"}
        sul = {"PR", "SC", "RS"}
        centro = {"DF", "GO", "MT", "MS"}
        nordeste = {"BA", "SE", "AL", "PE", "PB", "RN", "CE", "PI", "MA"}
        norte = {"AM", "RR", "AP", "PA", "TO", "RO", "AC"}
        if uf in sudeste:
            return "sudeste"
        if uf in sul:
            return "sul_co"
        if uf in centro:
            return "centro_oeste"
        if uf in nordeste:
            return "nordeste"
        if uf in norte:
            return "norte"
        return "sudeste"

    @staticmethod
    def _calculo_sedex_local(peso: Decimal, regiao: str) -> dict:
        """
        Tabela simples de SEDEX offline por região/peso.
        Valores fictícios para fallback rápido.
        """
        tiers = [
            (Decimal("1"), {"sudeste": 18, "sul_co": 22, "centro_oeste": 24, "nordeste": 26, "norte": 28}),
            (Decimal("3"), {"sudeste": 24, "sul_co": 27, "centro_oeste": 30, "nordeste": 32, "norte": 35}),
            (Decimal("10"), {"sudeste": 32, "sul_co": 36, "centro_oeste": 40, "nordeste": 42, "norte": 46}),
            ("acima", {"sudeste": 48, "sul_co": 52, "centro_oeste": 56, "nordeste": 60, "norte": 65}),
        ]
        valor = 0
        for limite, tabela in tiers:
            if limite == "acima" or peso <= limite:
                valor = tabela.get(regiao, 40)
                break
        prazos = {
            "sudeste": "2-4 dias úteis",
            "sul_co": "3-6 dias úteis",
            "centro_oeste": "3-6 dias úteis",
            "nordeste": "4-8 dias úteis",
            "norte": "5-10 dias úteis",
        }
        return {
            "frete_gratis": False,
            "valor": float(valor),
            "prazo": prazos.get(regiao, "4-8 dias úteis"),
            "fallback": True,
            "message": "Estimativa SEDEX (local)",
        }

    def get(self, request, *args, **kwargs):
        cep = (request.GET.get("cep") or "").strip()
        subtotal = Decimal(request.GET.get("subtotal", "0") or "0")

        if not cep:
            return JsonResponse({"error": "CEP obrigatório"}, status=400)

        cep_destino = re.sub(r"\\D", "", cep)
        if len(cep_destino) != 8:
            return JsonResponse({"error": "CEP inválido"}, status=400)

        config = ConfiguracaoSite.load()
        if subtotal >= (config.valor_frete_gratis or Decimal("0")):
            return JsonResponse({"frete_gratis": True, "valor": 0, "prazo": "5-7 dias úteis"})

        peso = Decimal(request.GET.get("peso", "1") or "1")  # kg
        comprimento = request.GET.get("comp", "20")
        altura = request.GET.get("alt", "10")
        largura = request.GET.get("larg", "15")
        formato = "1"  # caixa/pacote

        # Descobre UF via ViaCEP para mapear melhor a região
        regiao = "sudeste"
        try:
            resp_cep = requests.get(f"https://viacep.com.br/ws/{cep_destino}/json/", timeout=5)
            if resp_cep.ok:
                data = resp_cep.json()
                uf = data.get("uf")
                regiao = self._regiao_por_uf(uf) if uf else regiao
        except requests.exceptions.RequestException:
            regiao = regiao

        params = {
            "nCdEmpresa": "",
            "sDsSenha": "",
            "nCdServico": "04510",  # PAC; troque para 04014 (SEDEX) se quiser
            "sCepOrigem": re.sub(r"\\D", "", getattr(config, "cep_origem", "") or "01001000"),
            "sCepDestino": cep_destino,
            "nVlPeso": peso,
            "nCdFormato": formato,
            "nVlComprimento": comprimento,
            "nVlAltura": altura,
            "nVlLargura": largura,
            "nVlDiametro": "0",
            "nVlValorDeclarado": str(max(subtotal, Decimal("0"))),
            "sCdMaoPropria": "N",
            "sCdAvisoRecebimento": "N",
            "StrRetorno": "xml",
        }

        # Apenas cálculo local (tabela interna)
        return JsonResponse(self._calculo_sedex_local(peso, regiao), status=200)


# ═══════════════════════════════════════════════════════════════════════════
# CATÁLOGO E PRODUTOS
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
# CATÁLOGO E PRODUTOS
# ═══════════════════════════════════════════════════════════════════════════

from django.db.models import Q, F
from django.views.generic import ListView

class CatalogoView(ListView):
    model = Produto
    template_name = "loja/catalogo/catalogo.html"
    context_object_name = "produtos"
    paginate_by = 12

    def get_queryset(self):
        queryset = (
            Produto.objects
            .filter(disponivel=True)
            .select_related("categoria", "marca")
        )

        # ---------------------------------------------------------
        # CATEGORIAS (múltiplas via checkbox) + fallback legado
        # ---------------------------------------------------------
        categorias_slugs = self.request.GET.getlist("categoria")  # ?categoria=a&categoria=b
        if not categorias_slugs:
            # fallback: caso venha apenas uma categoria (legado)
            categoria_slug = self.request.GET.get("categoria")
            if categoria_slug:
                categorias_slugs = [categoria_slug]

        if categorias_slugs:
            queryset = queryset.filter(categoria__slug__in=categorias_slugs)

        # ---------------------------------------------------------
        # MARCA (normalmente uma só pelo seu layout)
        # ---------------------------------------------------------
        marca_slug = self.request.GET.get("marca")
        if marca_slug:
            queryset = queryset.filter(marca__slug=marca_slug)

        # ---------------------------------------------------------
        # BUSCA
        # ---------------------------------------------------------
        busca = (self.request.GET.get("q") or "").strip()
        if busca:
            queryset = queryset.filter(
                Q(nome__icontains=busca)
                | Q(descricao_resumida__icontains=busca)
                | Q(descricao_completa__icontains=busca)
                | Q(marca__nome__icontains=busca)
                | Q(categoria__nome__icontains=busca)
            )

        # ---------------------------------------------------------
        # PREÇOS
        # ---------------------------------------------------------
        preco_min = self.request.GET.get("preco_min")
        preco_max = self.request.GET.get("preco_max")
        if preco_min:
            queryset = queryset.filter(preco__gte=preco_min)
        if preco_max:
            queryset = queryset.filter(preco__lte=preco_max)

        # ---------------------------------------------------------
        # FLAGS
        # ---------------------------------------------------------
        if self.request.GET.get("em_promocao") == "true":
            queryset = queryset.filter(preco_antigo__gt=F("preco"))

        if self.request.GET.get("disponivel") == "true":
            queryset = queryset.filter(estoque__gt=0)

        # ---------------------------------------------------------
        # ORDENAÇÃO
        # ---------------------------------------------------------
        ordenacao = self.request.GET.get("ordenacao", "relevancia")
        if ordenacao == "preco_asc":
            queryset = queryset.order_by("preco")
        elif ordenacao == "preco_desc":
            queryset = queryset.order_by("-preco")
        elif ordenacao == "nome":
            queryset = queryset.order_by("nome")
        elif ordenacao == "novidades":
            queryset = queryset.order_by("-data_criacao")
        elif ordenacao == "mais_vendidos":
            queryset = queryset.order_by("-vendas_totais")
        else:
            queryset = queryset.order_by("-is_destaque", "-vendas_totais", "-data_criacao")

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        context["config_site"] = ConfiguracaoSite.load()
        context["categorias"] = Categoria.objects.filter(ativa=True)
        context["marcas"] = Marca.objects.filter(ativa=True)

        # Para checkbox "checked" no template (NÃO usar request.GET.getlist no template)
        selected_cats = self.request.GET.getlist("categoria")
        if not selected_cats:
            cat = self.request.GET.get("categoria")
            if cat:
                selected_cats = [cat]
        context["selected_cats"] = selected_cats

        # Melhor que dict() quando há múltiplos valores
        context["parametros"] = self.request.GET

        context["carrinho_count"] = obter_carrinho_count(self.request)

        context["hero_banners"] = Banner.objects.filter(ativo=True, tipo="hero").order_by("ordem")
        context["cta_cards"] = Banner.objects.filter(ativo=True, tipo="cta").order_by("ordem")[:2]

        try:
            if self.request.user.is_authenticated:
                context["notificacoes_nao_lidas"] = Notificacao.objects.filter(
                    usuario=self.request.user, lida=False
                ).count()
            else:
                context["notificacoes_nao_lidas"] = 0
        except Exception:
            context["notificacoes_nao_lidas"] = 0

        return context


class ProdutoDetailView(DetailView):
    model = Produto
    template_name = "loja/catalogo/produto_detalhe.html"
    context_object_name = "produto"
    slug_field = "slug"
    slug_url_kwarg = "slug"

    def get_queryset(self):
        return (
            Produto.objects.filter(disponivel=True)
            .select_related("categoria", "marca")
            .prefetch_related("imagens_adicionais", "variacoes__opcoes")
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        produto = self.object
        context["config_site"] = ConfiguracaoSite.load()

        # Captura parâmetros de afiliado
        ref = self.request.GET.get('ref')
        sku = self.request.GET.get('sku')
        if ref:
            self.request.session['afiliado_codigo_ref'] = ref
            if sku:
                self.request.session['afiliado_sku'] = sku

        if self.request.user.is_authenticated:
            historico, created = HistoricoVisualizacao.objects.get_or_create(
                usuario=self.request.user, produto=produto
            )
            if not created:
                historico.incrementar()
            produto.registrar_visualizacao()

            try:
                wishlist = Wishlist.objects.get(usuario=self.request.user)
                context["in_wishlist"] = wishlist.produtos.filter(id=produto.id).exists()
                context["wishlist_count"] = wishlist.produtos.count()
            except Wishlist.DoesNotExist:
                context["in_wishlist"] = False
                context["wishlist_count"] = 0
        else:
            context["in_wishlist"] = False
            context["wishlist_count"] = 0

        context["carrinho_count"] = obter_carrinho_count(self.request)

        avaliacoes_aprovadas = produto.avaliacoes.filter(aprovado=True).order_by("-data_criacao")
        # Garante números atualizados para o template
        produto.numero_avaliacoes = avaliacoes_aprovadas.count()
        produto.avaliacao_media = avaliacoes_aprovadas.aggregate(avg=Avg("avaliacao"))["avg"] or 0

        context["produtos_relacionados"] = (
            Produto.objects.filter(disponivel=True, categoria=produto.categoria)
            .exclude(id=produto.id)
            .select_related("categoria", "marca")[:4]
        )
        context["avaliacoes"] = avaliacoes_aprovadas[:10]
        context["avaliacoes_count"] = produto.numero_avaliacoes
        context["galeria_imagens"] = produto.imagens_adicionais.all().order_by("ordem")

        if produto.has_variacoes:
            context["variacoes"] = produto.variacoes.prefetch_related("opcoes__atributo").all()
        else:
            context["variacoes"] = []
        return context


class CategoriaDetailView(DetailView):
    model = Categoria
    template_name = "loja/catalogo/categoria.html"
    context_object_name = "categoria"
    slug_field = "slug"
    slug_url_kwarg = "slug"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["config_site"] = ConfiguracaoSite.load()
        categoria = self.object

        produtos = Produto.objects.filter(categoria=categoria, disponivel=True).select_related(
            "categoria", "marca"
        )

        preco_max = self.request.GET.get("preco_max")
        if preco_max:
            try:
                produtos = produtos.filter(preco__lte=float(preco_max))
            except ValueError:
                pass

        marcas_ids = self.request.GET.getlist("marcas")
        if marcas_ids:
            produtos = produtos.filter(marca__id__in=marcas_ids)

        apenas_disponivel = self.request.GET.get("disponivel")
        if apenas_disponivel == "true":
            produtos = produtos.filter(estoque__gt=0)

        em_promocao = self.request.GET.get("promocao")
        if em_promocao == "true":
            produtos = produtos.filter(preco_antigo__gt=F("preco"))

        ordenacao = self.request.GET.get("ordenacao", "relevancia")
        if ordenacao == "preco_asc":
            produtos = produtos.order_by("preco")
        elif ordenacao == "preco_desc":
            produtos = produtos.order_by("-preco")
        elif ordenacao == "nome":
            produtos = produtos.order_by("nome")
        elif ordenacao == "novidades":
            produtos = produtos.order_by("-data_criacao")
        elif ordenacao == "mais_vendidos":
            produtos = produtos.order_by("-vendas_totais")
        else:
            produtos = produtos.order_by("-is_destaque", "-vendas_totais")

        paginator = Paginator(produtos, 12)
        page_number = self.request.GET.get("page")
        page_obj = paginator.get_page(page_number)

        carrinho_count = obter_carrinho_count(self.request)

        context["page_obj"] = page_obj
        context["produtos"] = page_obj.object_list
        context["categorias"] = Categoria.objects.filter(ativa=True)
        context["marcas"] = Marca.objects.filter(ativa=True)
        context["ordenacao_atual"] = ordenacao
        context["carrinho_count"] = carrinho_count

        return context

from django.shortcuts import render, redirect
from django.views import View
from django.contrib import messages
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_POST
from decimal import Decimal
import json
import logging

# Certifique-se de que as importações dos seus models e utils estão corretas
# from .models import CupomDesconto, Produto, ItemCarrinho, ConfiguracaoSite
# from .utils import obter_carrinho, atualizar_sessao_carrinho

logger = logging.getLogger(__name__)

class CarrinhoView(View):
    template_name = "loja/carrinho/carrinho.html"

    def get(self, request, *args, **kwargs):
        try:
            processar_abandonos_lazy()
            carrinho = self._get_carrinho(request)

            if carrinho:
                atualizar_sessao_carrinho(request, carrinho)

            # Recalcula desconto do cupom com base no subtotal atual
            cupom_data = request.session.get("cupom_aplicado")
            cupom_aplicado = None
            desconto = Decimal("0.00")
            itens = []
            total_com_desconto = Decimal("0.00")

            if carrinho:
                itens = carrinho.itens.select_related("produto").order_by("id")

                if cupom_data:
                    try:
                        cupom_obj = CupomDesconto.objects.get(id=cupom_data.get("id"))
                    except (CupomDesconto.DoesNotExist, TypeError, ValueError):
                        request.session.pop("cupom_aplicado", None)
                        messages.info(request, "Cupom expirado ou indispon?vel. Aplique novamente.")
                    else:
                        cupom_valido = cupom_obj.valido
                        erros_validacao = []

                        if request.user.is_authenticated and cupom_valido:
                            cupom_valido, erros_validacao = cupom_obj.validar_para_usuario(
                                usuario=request.user,
                                valor_total=float(carrinho.subtotal),
                                carrinho=carrinho,
                            )

                        if not cupom_valido:
                            for erro in erros_validacao or ["Cupom inv?lido ou expirado."]:
                                messages.error(request, erro)
                            request.session.pop("cupom_aplicado", None)
                        else:
                            desconto = cupom_obj.calcular_desconto(carrinho.subtotal)
                            if desconto > carrinho.subtotal:
                                desconto = carrinho.subtotal

                            cupom_aplicado = {**cupom_data, "codigo": cupom_obj.codigo, "desconto": desconto}
                            request.session["cupom_aplicado"] = {
                                **cupom_aplicado,
                                "desconto": float(desconto),
                                "id": cupom_obj.id,
                            }
                            request.session.modified = True

                total_com_desconto = max(Decimal("0.00"), carrinho.subtotal - desconto)
            else:
                total_com_desconto = Decimal("0.00")
                itens = []

            # CEP padr├úo para simula├º├úo de frete no carrinho (endere├ºo principal ou primeiro)
            cep_padrao = ""
            if request.user.is_authenticated:
                try:
                    endereco_principal = (
                        request.user.enderecos_entrega.filter(principal=True, ativo=True).first()
                        or request.user.enderecos_entrega.filter(ativo=True).first()
                    )
                    if endereco_principal and getattr(endereco_principal, "cep", ""):
                        cep_padrao = endereco_principal.cep
                    elif hasattr(request.user, "perfil") and getattr(request.user.perfil, "cep", ""):
                        cep_padrao = request.user.perfil.cep
                except Exception:
                    cep_padrao = ""

            context = {
                "carrinho": carrinho,
                "itens": itens,
                "config_site": ConfiguracaoSite.objects.first(),
                "cupom": cupom_aplicado,
                "valor_desconto_real": desconto,
                "total_com_desconto": total_com_desconto,
                "cep_padrao": cep_padrao,
                "notificacoes_nao_lidas": Notificacao.objects.filter(usuario=request.user, lida=False).count() if request.user.is_authenticated else 0,
            }
            return render(request, self.template_name, context)

        except Exception as e:
            logger.error(f"Erro ao carregar carrinho: {str(e)}")
            messages.error(request, "Erro ao carregar carrinho. Tente novamente.")
            return redirect("home")

    def _get_carrinho(self, request):
        """Obtém o carrinho de forma segura."""
        try:
            return obter_carrinho(request)
        except Exception as e:
            logger.error(f"Erro ao obter carrinho: {str(e)}")
            return None

    def post(self, request, *args, **kwargs):
        action = request.POST.get("action")

        if action == "limpar":
            return self._limpar_carrinho(request)
        elif action == "aplicar_cupom":
            return self._aplicar_cupom(request)
        elif action == "remover_cupom":
            return self._remover_cupom(request)
        elif action == "enviar_lembrete":
            return self._enviar_lembrete(request)
        else:
            messages.error(request, "Ação inválida.")
            return redirect("carrinho")

    def _enviar_lembrete(self, request):
        """Envia lembrete do carrinho para o email informado (ou do usuario)."""
        try:
            carrinho = self._get_carrinho(request)
            if not carrinho or carrinho.total_itens == 0:
                messages.error(request, "Carrinho vazio. Adicione itens antes de enviar lembrete.")
                return redirect("carrinho")

            email_destino = request.POST.get("email_lembrete", "").strip()
            if not email_destino and request.user.is_authenticated:
                email_destino = request.user.email

            if not email_destino:
                messages.error(request, "Informe um email para receber o lembrete.")
                return redirect("carrinho")

            itens = carrinho.itens.select_related("produto")
            carrinho_url = request.build_absolute_uri(reverse("carrinho"))
            context_email = {
                "itens": itens,
                "subtotal": carrinho.subtotal,
                "carrinho_url": carrinho_url,
                "site_url": getattr(settings, "SITE_URL", carrinho_url),
            }

            html_msg = render_to_string("emails/carrinho_abandonado.html", context_email)
            plain_msg = strip_tags(html_msg)

            send_mail(
                subject="Seu carrinho te espera na The Shape",
                message=plain_msg,
                from_email=getattr(settings, "DEFAULT_FROM_EMAIL", None),
                recipient_list=[email_destino],
                html_message=html_msg,
                fail_silently=False,
            )

            messages.success(request, "Enviamos o lembrete do carrinho para o email informado.")
        except Exception as e:
            logger.error(f"Lembrete carrinho erro: {e}")
            messages.error(request, "Nao foi possivel enviar o lembrete. Tente novamente.")

        return redirect("carrinho")

    def _limpar_carrinho(self, request):
        """Limpa o carrinho de forma segura."""
        try:
            carrinho = self._get_carrinho(request)
            if carrinho:
                carrinho.limpar()

            request.session["carrinho_count"] = 0

            # Se limpar o carrinho, remove o cupom (opcional, mas recomendado)
            if "cupom_aplicado" in request.session:
                del request.session["cupom_aplicado"]

            messages.success(request, "Carrinho limpo!")

        except Exception as e:
            logger.error(f"Erro ao limpar carrinho: {str(e)}")
            messages.error(request, "Erro ao limpar carrinho.")

        return redirect("carrinho")

    def _aplicar_cupom(self, request):
        """Aplica cupom com validações robustas."""
        codigo_cupom = request.POST.get("codigo_cupom", "").strip().upper()

        if not codigo_cupom:
            messages.error(request, "Digite um código de cupom.")
            return redirect("carrinho")

        try:
            cupom = CupomDesconto.objects.filter(codigo__iexact=codigo_cupom).first()
            if not cupom:
                messages.error(request, "Cupom não encontrado.")
                return redirect("carrinho")

            if not cupom.valido:
                messages.error(request, "Cupom expirado ou inativo.")
                return redirect("carrinho")

            carrinho = self._get_carrinho(request)
            if not carrinho or carrinho.total_itens == 0:
                messages.error(request, "Adicione produtos ao carrinho para usar o cupom.")
                return redirect("carrinho")

            if carrinho.subtotal < cupom.valor_minimo_compra:
                messages.error(request, f"Valor mínimo para este cupom: R$ {cupom.valor_minimo_compra:.2f}")
                return redirect("carrinho")

            usuario = request.user if request.user.is_authenticated else None

            if usuario:
                valido, erros = cupom.validar_para_usuario(
                    usuario=usuario,
                    valor_total=float(carrinho.subtotal),
                    carrinho=carrinho,
                )

                if not valido:
                    for erro in erros:
                        messages.error(request, erro)
                    return redirect("carrinho")

            desconto = cupom.calcular_desconto(carrinho.subtotal)

            # Armazena na sessão os dados necessários para recálculo futuro
            request.session["cupom_aplicado"] = {
                "id": cupom.id,
                "codigo": cupom.codigo,
                "desconto": float(desconto), # Valor calculado no momento (apenas para referência)
                "tipo": cupom.tipo_desconto, # Importante: 'percentual' ou 'fixo'
                "valor_original": float(cupom.valor_desconto), # Importante: O valor base (ex: 10% ou R$50)
                "nome": cupom.nome,
            }

            messages.success(request, f'Cupom "{cupom.codigo}" aplicado com sucesso!')

        except CupomDesconto.DoesNotExist:
            messages.error(request, "Cupom não encontrado.")
        except Exception as e: # ValidationError deve ser importado ou pego aqui
            logger.error(f"Erro ao aplicar cupom: {str(e)}")
            messages.error(request, "Erro ao aplicar cupom ou cupom inválido.")

        return redirect("carrinho")

    def _remover_cupom(self, request):
        """Remove cupom da sessão."""
        try:
            if "cupom_aplicado" in request.session:
                cupom_codigo = request.session["cupom_aplicado"].get("codigo", "")
                del request.session["cupom_aplicado"]
                messages.success(request, f'Cupom "{cupom_codigo}" removido.')
            else:
                messages.info(request, "Nenhum cupom aplicado.")

        except Exception as e:
            logger.error(f"Erro ao remover cupom: {str(e)}")
            messages.error(request, "Erro ao remover cupom.")

        return redirect("carrinho")


class AdicionarAoCarrinhoView(View):
    """View para adicionar itens via AJAX."""

    @method_decorator(require_POST)
    def post(self, request, *args, **kwargs):
        produto_id = request.POST.get("produto_id")
        variacao_id = request.POST.get("variacao_id") or ""
        try:
            quantidade = int(request.POST.get("quantidade", 1))
        except (TypeError, ValueError):
            quantidade = 1

        try:
            produto = Produto.objects.get(id=produto_id, disponivel=True)
            carrinho = obter_carrinho(request)

            # Se o produto tem variações cadastradas mas a flag não foi marcada, corrija para garantir fallback.
            if not produto.has_variacoes and produto.variacoes.exists():
                produto.has_variacoes = True
                produto.save(update_fields=["has_variacoes"])
            # Se o produto está marcado para ter variações mas nenhuma está cadastrada/ativa, avise.
            if produto.has_variacoes and not produto.variacoes.exists():
                return JsonResponse(
                    {"success": False, "message": "Produto configurado com variações, mas nenhuma variação está cadastrada."},
                    status=400,
                )

            variacao = None
            if variacao_id:
                variacao = get_object_or_404(ProdutoVariacao, id=variacao_id, produto=produto)
            elif produto.has_variacoes:
                # fallback: primeira variação disponível (tenta com estoque > 0, senão pega a primeira)
                variacao = (
                    produto.variacoes.filter(estoque__gt=0).order_by("-estoque").first()
                    or produto.variacoes.order_by("-estoque").first()
                )

            if produto.has_variacoes and not variacao:
                return JsonResponse({"success": False, "message": "Selecione uma variação válida."}, status=400)

            # Captura código de afiliado da sessão
            afiliado_codigo_ref = request.session.get('afiliado_codigo_ref')

            carrinho.adicionar_item(produto, quantidade, variacao, afiliado_codigo_ref)

            # AJUSTE: REMOVIDA A LINHA QUE DELETAVA O CUPOM DA SESSÃO
            # if "cupom_aplicado" in request.session:
            #    del request.session["cupom_aplicado"]

            atualizar_sessao_carrinho(request, carrinho)

            return JsonResponse(
                {
                    "success": True,
                    "message": f"{produto.nome} adicionado!",
                    "total_itens": carrinho.total_itens,
                    "subtotal": str(carrinho.subtotal),
                }
            )

        except Produto.DoesNotExist:
            return JsonResponse({"success": False, "message": "Produto não encontrado."}, status=404)
        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)}, status=500)


class AtualizarCarrinhoView(View):
    """View para atualizar quantidades via AJAX."""

    @method_decorator(require_POST)
    def post(self, request, *args, **kwargs):
        try:
            if request.content_type == "application/json":
                data = json.loads(request.body)
                item_id = data.get("item_id")
                quantidade = int(data.get("quantidade", 1))
            else:
                item_id = request.POST.get("item_id")
                quantidade = int(request.POST.get("quantidade", 1))
        except json.JSONDecodeError:
            return JsonResponse({"success": False, "message": "JSON inválido"}, status=400)

        try:
            carrinho = obter_carrinho(request)
            item = ItemCarrinho.objects.get(id=item_id, carrinho=carrinho)

            if quantidade <= 0:
                item.delete()
                message = "Item removido."
            else:
                carrinho.atualizar_quantidade(item.produto, quantidade, variacao=item.variacao)
                message = "Quantidade atualizada."

            # AJUSTE: REMOVIDA A LINHA QUE DELETAVA O CUPOM DA SESSÃO
            # if "cupom_aplicado" in request.session:
            #    del request.session["cupom_aplicado"]

            atualizar_sessao_carrinho(request, carrinho)
            
            # Opcional: Recalcular o novo total para atualizar via JS no front-end
            novo_total = carrinho.subtotal
            # Lógica simples para devolver o valor correto pro front se necessário
            # (O ideal é dar um reload ou tratar isso no JS)

            return JsonResponse(
                {
                    "success": True,
                    "message": message,
                    "total_itens": carrinho.total_itens,
                    "subtotal": str(carrinho.subtotal),
                }
            )

        except (Carrinho.DoesNotExist, ItemCarrinho.DoesNotExist):
            return JsonResponse({"success": False, "message": "Item não encontrado."}, status=404)
        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)}, status=500)
# ═══════════════════════════════════════════════════════════════════════════
# CHECKOUT E PAGAMENTO
# ═══════════════════════════════════════════════════════════════════════════

from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.contrib import messages
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import transaction
from decimal import Decimal
import logging
import re # Importante para limpar o CPF

# Certifique-se de importar seus models e services
# from .models import Pedido, ItemPedido, CupomDesconto, EnderecoEntrega, ConfiguracaoSite
# from .utils import obter_carrinho, get_asaas_service

logger = logging.getLogger(__name__)

from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.contrib import messages
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import transaction
from decimal import Decimal
import logging
import re



logger = logging.getLogger(__name__)

@method_decorator(login_required, name="dispatch")
class CheckoutView(View):
    template_name = "loja/carrinho/checkout.html"

    # ---------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------
    @staticmethod
    def _limpar_cpf(valor) -> str:
        return re.sub(r"\D", "", str(valor or ""))

    @staticmethod
    def _cpf_basico_valido(cpf_limpo: str) -> bool:
        # Validação básica (tamanho + não repetir todos os dígitos).
        if not cpf_limpo or len(cpf_limpo) != 11:
            return False
        if cpf_limpo == cpf_limpo[0] * 11:
            return False
        return True

    # ---------------------------------------------------------
    # Afiliado (resolver ref) — NOVO
    # ---------------------------------------------------------
    @staticmethod
    def _limpar_ref_afiliado(valor) -> str:
        # Mantém letras/números/_; remove resto
        ref = re.sub(r"[^A-Za-z0-9_]", "", str(valor or "")).strip()
        return ref

    def _resolver_afiliado_ref(self, request, carrinho=None) -> str:
        """
        Resolve o código de referência do afiliado responsável pela compra.
        Prioridade:
          1) session (quando o cliente entrou via link afiliado)
          2) itens do carrinho (se existir campo no ItemCarrinho)
        """
        ref = (
            request.session.get("afiliado_ref")
            or request.session.get("codigo_referencia_afiliado")
            or request.session.get("ref")
            or request.session.get("referrer")
            or ""
        )
        ref = self._limpar_ref_afiliado(ref)

        if not ref and carrinho is not None:
            try:
                for it in carrinho.itens.all():
                    ref_item = (
                        getattr(it, "afiliado_codigo_ref", "")
                        or getattr(it, "afiliado_ref", "")
                        or ""
                    )
                    ref_item = self._limpar_ref_afiliado(ref_item)
                    if ref_item:
                        ref = ref_item
                        break
            except Exception:
                pass

        return ref

    def _peso_total_carrinho(self, carrinho) -> Decimal:
        """
        Tenta calcular peso total. Se não houver campos/modelos, cai em 1.
        """
        try:
            total_gramas = Decimal("0")
            for item in carrinho.itens.select_related("produto", "variacao"):
                qtd = Decimal(str(item.quantidade or 0))
                alvo = item.variacao if getattr(item, "variacao", None) else item.produto
                # Tente peso_gramas / peso (fallback)
                peso_item = getattr(alvo, "peso_gramas", None)
                if peso_item is None:
                    peso_item = getattr(alvo, "peso", None)
                if peso_item is None:
                    peso_item = 0
                total_gramas += Decimal(str(peso_item)) * qtd

            # Converte gramas -> “peso” (kg aproximado) para tiers simples
            if total_gramas <= 0:
                return Decimal("1")
            kg = (total_gramas / Decimal("1000")).quantize(Decimal("0.01"))
            return max(Decimal("1"), kg)
        except Exception:
            return Decimal("1")

    # ---------------------------------------------------------
    # GET
    # ---------------------------------------------------------
    def get(self, request, *args, **kwargs):
        carrinho = obter_carrinho(request)

        if carrinho.total_itens == 0:
            messages.error(request, "Seu carrinho está vazio.")
            return redirect("carrinho")

        # Verifica estoque (produto ou variação)
        for item in carrinho.itens.select_related("produto", "variacao"):
            estoque_alvo = item.variacao.estoque if item.variacao else item.produto.estoque
            if int(item.quantidade) > int(estoque_alvo):
                messages.error(
                    request,
                    f"Estoque insuficiente para {item.produto.nome}. Disponível: {estoque_alvo}"
                )
                return redirect("carrinho")

        # CPF “visual” (apenas aviso; validação real no POST)
        cpf_visual = getattr(request.user, "cpf", "") or ""
        if not cpf_visual and hasattr(request.user, "perfil"):
            cpf_visual = getattr(request.user.perfil, "cpf", "") or ""

        if not cpf_visual:
            messages.warning(request, "Se não tiver CPF no perfil, você poderá informá-lo na finalização.")

        parcelas_disponiveis = []
        if carrinho.subtotal and carrinho.subtotal > 0:
            try:
                asaas_service = get_asaas_service()
                parcelas_disponiveis = asaas_service.obter_parcelas_disponiveis(float(carrinho.subtotal))
            except Exception as e:
                logger.exception("Erro ao obter parcelas Asaas: %s", e)

        config_site = ConfiguracaoSite.load()

        max_percent_pontos = getattr(config_site, "max_percentual_pontos_resgate", 100) or 0
        max_percent_cashback = getattr(config_site, "max_percentual_cashback_resgate", 100) or 0
        min_pontos_resgate = getattr(config_site, "pontos_minimos_resgate", 0) or 0
        min_cashback_resgate = getattr(config_site, "cashback_minimo_resgate", Decimal("0")) or Decimal("0")
        valor_ponto = getattr(config_site, "valor_ponto_em_reais", Decimal("0.01")) or Decimal("0.01")

        pontos_disponiveis = int(getattr(request.user, "pontos_disponiveis", 0) or 0)
        pontos_em_reais = (Decimal(str(pontos_disponiveis)) * Decimal(str(valor_ponto))).quantize(Decimal("0.01"))

        cashback_disponivel = Decimal(
            str(getattr(request.user, "saldo_cashback", Decimal("0")) or Decimal("0"))
        ).quantize(Decimal("0.01"))

        # Endereços (mantém como você estava; ajuste se seu related_name for outro)
        enderecos_qs = getattr(request.user, "enderecos_entrega", None)
        enderecos = enderecos_qs.filter(ativo=True) if enderecos_qs else []

        context = {
            "carrinho": carrinho,
            "enderecos": enderecos,
            "cupom": request.session.get("cupom_aplicado"),
            "config_site": config_site,
            "METODO_PAGAMENTO_CHOICES": Pedido.METODO_PAGAMENTO_CHOICES,
            "parcelas_disponiveis": parcelas_disponiveis,
            "pontos_disponiveis": pontos_disponiveis,
            "cashback_disponivel": cashback_disponivel,
            "max_percent_pontos_resgate": max_percent_pontos,
            "max_percent_cashback_resgate": max_percent_cashback,
            "min_pontos_resgate": min_pontos_resgate,
            "min_cashback_resgate": min_cashback_resgate,
            "pontos_em_reais": pontos_em_reais,
            "cashback_em_reais": cashback_disponivel,
        }
        return render(request, self.template_name, context)

    # ---------------------------------------------------------
    # POST
    # ---------------------------------------------------------
    def post(self, request, *args, **kwargs):
        action = request.POST.get("action", "").strip()

        if action == "processar_pedido":
            return self._processar_pedido_asaas(request)

        messages.error(request, "Ação inválida.")
        return redirect("checkout")

    # ---------------------------------------------------------
    # Frete
    # ---------------------------------------------------------
    def _calcular_frete(self, subtotal, cep=None, peso=1):
        config = ConfiguracaoSite.load()
        if config and getattr(config, "valor_frete_gratis", None) and subtotal >= config.valor_frete_gratis:
            return Decimal("0.00")

        # Região via CEP (ViaCEP)
        regiao = "sudeste"
        if cep:
            cep_clean = re.sub(r"\D", "", str(cep))
            if len(cep_clean) == 8:
                try:
                    resp = requests.get(f"https://viacep.com.br/ws/{cep_clean}/json/", timeout=5)
                    if resp.ok:
                        uf = (resp.json() or {}).get("uf")
                        if uf:
                            regiao = FreteCorreiosView._regiao_por_uf(uf)
                except requests.exceptions.RequestException:
                    pass

        peso_dec = Decimal(str(peso or 1))
        tiers = [
            (Decimal("1"), {"sudeste": 18, "sul_co": 22, "centro_oeste": 24, "nordeste": 26, "norte": 28}),
            (Decimal("3"), {"sudeste": 24, "sul_co": 27, "centro_oeste": 30, "nordeste": 32, "norte": 35}),
            (Decimal("10"), {"sudeste": 32, "sul_co": 36, "centro_oeste": 40, "nordeste": 42, "norte": 46}),
            ("acima", {"sudeste": 48, "sul_co": 52, "centro_oeste": 56, "nordeste": 60, "norte": 65}),
        ]

        valor = Decimal("20.00")
        for limite, tabela in tiers:
            if limite == "acima" or peso_dec <= limite:
                valor = Decimal(str(tabela.get(regiao, tabela.get("sudeste", 20))))
                break

        return valor.quantize(Decimal("0.01"))

    # ---------------------------------------------------------
    # Processamento
    # ---------------------------------------------------------
    def _processar_pedido_asaas(self, request):
        carrinho = obter_carrinho(request)

        if carrinho.total_itens == 0:
            messages.error(request, "Seu carrinho está vazio.")
            return redirect("carrinho")

        try:
            # =========================================================================
            # Estratégia de busca e limpeza de CPF “indestrutível”
            # =========================================================================
            cpf_candidato = (
                request.POST.get("cpf", "")
                or request.POST.get("cpf_checkout", "")
                or getattr(request.user, "cpf", "")
                or ""
            )

            if not cpf_candidato:
                if hasattr(request.user, "perfil"):
                    cpf_candidato = getattr(request.user.perfil, "cpf", "") or ""
                elif hasattr(request.user, "profile"):
                    cpf_candidato = getattr(request.user.profile, "cpf", "") or ""

            cpf_limpo = self._limpar_cpf(cpf_candidato)

            if not self._cpf_basico_valido(cpf_limpo):
                raise ValidationError(f"CPF inválido ou não encontrado ({cpf_candidato}). Verifique seu cadastro.")

            # Guarda em memória para esta transação
            request.user.cpf_temporario_checkout = cpf_limpo

            # Se seu model User tiver cpf, tenta persistir (silencioso)
            if hasattr(request.user, "cpf") and not (getattr(request.user, "cpf", "") or "").strip():
                request.user.cpf = cpf_limpo
                try:
                    request.user.save(update_fields=["cpf"])
                except Exception:
                    pass

            metodo_pagamento = (request.POST.get("metodo_pagamento") or "").strip()
            if not metodo_pagamento or metodo_pagamento not in dict(Pedido.METODO_PAGAMENTO_CHOICES):
                raise ValidationError("Selecione um método de pagamento válido.")

            numero_parcelas = 1
            if metodo_pagamento == "cartao_credito":
                try:
                    numero_parcelas = int(request.POST.get("numero_parcelas", 1) or 1)
                except ValueError:
                    numero_parcelas = 1

                if numero_parcelas < 1 or numero_parcelas > 12:
                    raise ValidationError("Número de parcelas inválido.")

            endereco_id = request.POST.get("endereco_entrega")
            if not endereco_id:
                raise ValidationError("Selecione um endereço de entrega.")

            endereco = get_object_or_404(EnderecoEntrega, id=endereco_id, usuario=request.user)

            subtotal = Decimal(str(carrinho.subtotal or 0)).quantize(Decimal("0.01"))

            cupom_data = request.session.get("cupom_aplicado", {}) or {}
            desconto_cupom = Decimal(str(cupom_data.get("desconto", 0) or 0)).quantize(Decimal("0.01"))

            desconto_fidelidade = Decimal("0.00")
            if hasattr(request.user, "nivel_fidelidade") and getattr(request.user, "nivel_fidelidade", "bronze") != "bronze":
                if hasattr(request.user, "obter_desconto_fidelidade"):
                    percentual = Decimal(str(request.user.obter_desconto_fidelidade() or 0))
                    desconto_fidelidade = (subtotal * percentual / Decimal("100")).quantize(Decimal("0.01"))

            base_resgate = (subtotal - desconto_cupom - desconto_fidelidade)
            if base_resgate < 0:
                base_resgate = Decimal("0.00")

            config_site = ConfiguracaoSite.load()
            valor_ponto = getattr(config_site, "valor_ponto_em_reais", Decimal("0.01")) or Decimal("0.01")

            # Pontos
            max_percent_pontos = getattr(config_site, "max_percentual_pontos_resgate", 100) or 0
            min_pontos_resgate = int(getattr(config_site, "pontos_minimos_resgate", 0) or 0)

            max_pontos_valor = (base_resgate * Decimal(str(max_percent_pontos)) / Decimal("100"))
            if max_pontos_valor < 0:
                max_pontos_valor = Decimal("0.00")

            max_pontos_disponiveis = int(getattr(request.user, "pontos_disponiveis", 0) or 0)

            try:
                pontos_resgatar = int(request.POST.get("pontos_resgatar", 0) or 0)
            except ValueError:
                pontos_resgatar = 0

            pontos_resgatar = max(0, min(pontos_resgatar, max_pontos_disponiveis))

            if min_pontos_resgate and 0 < pontos_resgatar < min_pontos_resgate:
                raise ValidationError(f"Quantidade mínima para usar pontos: {min_pontos_resgate}.")

            valor_pontos_utilizados = Decimal("0.00")
            if valor_ponto > 0 and pontos_resgatar > 0:
                valor_pontos_utilizados = (Decimal(str(pontos_resgatar)) * Decimal(str(valor_ponto))).quantize(Decimal("0.01"))
                if valor_pontos_utilizados > max_pontos_valor:
                    valor_pontos_utilizados = max_pontos_valor.quantize(Decimal("0.01"))
                    pontos_resgatar = int((valor_pontos_utilizados / Decimal(str(valor_ponto))).to_integral_value())

            base_pos_pontos = (base_resgate - valor_pontos_utilizados)
            if base_pos_pontos < 0:
                base_pos_pontos = Decimal("0.00")

            # Cashback
            max_percent_cashback = getattr(config_site, "max_percentual_cashback_resgate", 100) or 0
            min_cashback_resgate = Decimal(
                str(getattr(config_site, "cashback_minimo_resgate", Decimal("0")) or Decimal("0"))
            ).quantize(Decimal("0.01"))

            max_cashback_valor = (base_pos_pontos * Decimal(str(max_percent_cashback)) / Decimal("100"))
            if max_cashback_valor < 0:
                max_cashback_valor = Decimal("0.00")
            max_cashback_valor = max_cashback_valor.quantize(Decimal("0.01"))

            cashback_disponivel = Decimal(str(getattr(request.user, "saldo_cashback", Decimal("0")) or 0)).quantize(Decimal("0.01"))

            cashback_raw = str(request.POST.get("cashback_utilizar", 0) or 0).replace(",", ".").strip()
            try:
                cashback_utilizar = Decimal(cashback_raw or "0").quantize(Decimal("0.01"))
            except Exception:
                cashback_utilizar = Decimal("0.00")

            if cashback_utilizar < 0:
                cashback_utilizar = Decimal("0.00")

            cashback_utilizar = min(cashback_utilizar, cashback_disponivel, max_cashback_valor)

            if min_cashback_resgate and Decimal("0.00") < cashback_utilizar < min_cashback_resgate:
                raise ValidationError(f"Valor mínimo de cashback para uso: R$ {min_cashback_resgate:.2f}.")

            # Frete
            cep_frete = (request.POST.get("cep_frete") or request.POST.get("cep") or "").strip()
            if not cep_frete and endereco and getattr(endereco, "cep", ""):
                cep_frete = endereco.cep

            peso = self._peso_total_carrinho(carrinho)
            valor_frete = self._calcular_frete(subtotal, cep_frete, peso=peso)

            total = (base_pos_pontos - cashback_utilizar + valor_frete).quantize(Decimal("0.01"))
            if total < 0:
                total = Decimal("0.00")

            # Checagem final de estoque (antes de gravar)
            for item in carrinho.itens.select_related("produto", "variacao"):
                estoque_alvo = item.variacao.estoque if item.variacao else item.produto.estoque
                if int(item.quantidade) > int(estoque_alvo):
                    raise ValidationError(
                        f"Estoque insuficiente para {item.produto.nome}. Disponível: {estoque_alvo}"
                    )

            # ---------------------------------------------------------
            # Afiliado (captura do ref) — ESSENCIAL
            # ---------------------------------------------------------
            afiliado_codigo_ref = self._resolver_afiliado_ref(request, carrinho=carrinho)

            with transaction.atomic():
                pedido_kwargs = dict(
                    usuario=request.user,
                    endereco_entrega=endereco,
                    metodo_pagamento=metodo_pagamento,
                    subtotal=subtotal,
                    valor_frete=valor_frete,
                    desconto_cupom=desconto_cupom,
                    desconto_fidelidade=desconto_fidelidade,
                    pontos_utilizados=pontos_resgatar,
                    valor_pontos_utilizados=valor_pontos_utilizados,
                    cashback_utilizado=cashback_utilizar,
                    total=total,
                    status="aguardando_pagamento",
                    numero_parcelas=numero_parcelas,
                )

                # Se existir no model Pedido, salva também nele
                if afiliado_codigo_ref and hasattr(Pedido, "afiliado_codigo_ref"):
                    pedido_kwargs["afiliado_codigo_ref"] = afiliado_codigo_ref

                pedido = Pedido.objects.create(**pedido_kwargs)

                # Liga cupom no pedido (se existir)
                if cupom_data and cupom_data.get("id"):
                    try:
                        cupom = CupomDesconto.objects.get(id=cupom_data["id"])
                        pedido.cupom_utilizado = cupom
                        pedido.save(update_fields=["cupom_utilizado"])
                    except Exception:
                        pass

                # Itens do pedido
                for item in carrinho.itens.select_related("variacao", "produto__marca"):
                    variacao = item.variacao
                    opcoes_txt = ""
                    if variacao:
                        try:
                            opcoes_txt = ", ".join(variacao.opcoes.values_list("valor", flat=True))
                        except Exception:
                            opcoes_txt = ""

                    # Afiliado por item (se existir no ItemCarrinho), senão usa o global
                    af_ref_item = (
                        getattr(item, "afiliado_codigo_ref", "")
                        or getattr(item, "afiliado_ref", "")
                        or afiliado_codigo_ref
                        or ""
                    )
                    af_ref_item = self._limpar_ref_afiliado(af_ref_item)

                    ItemPedido.objects.create(
                        pedido=pedido,
                        produto=item.produto,
                        variacao=variacao,
                        quantidade=item.quantidade,
                        preco_unitario=item.preco_unitario,
                        nome_produto=item.produto.nome,
                        sku_produto=(variacao.sku if variacao else getattr(item.produto, "sku", "")),
                        marca_produto=(item.produto.marca.nome if getattr(item.produto, "marca", None) else ""),
                        variacao_opcoes=opcoes_txt,

                        # ✅ AQUI: preenche o campo do afiliado no ItemPedido
                        afiliado_codigo_ref=af_ref_item,
                    )

                # Debita pontos/cashback
                if pontos_resgatar > 0:
                    try:
                        request.user.remover_pontos(
                            pontos_resgatar,
                            motivo=f"Resgate no pedido #{pedido.numero_pedido}",
                            origem="resgate",
                            referencia=pedido.numero_pedido,
                            pedido=pedido,
                        )
                    except Exception:
                        pass

                if cashback_utilizar > 0:
                    try:
                        request.user.usar_cashback(
                            cashback_utilizar,
                            origem="compra",
                            motivo=f"Uso de cashback no pedido #{pedido.numero_pedido}",
                            referencia=pedido.numero_pedido,
                            pedido=pedido,
                        )
                    except Exception:
                        pass

                return self._gerar_checkout_asaas(
                    request=request,
                    pedido=pedido,
                    carrinho=carrinho,
                    metodo_pagamento=metodo_pagamento,
                    numero_parcelas=numero_parcelas,
                )

        except ValidationError as e:
            messages.error(request, str(e))
            return redirect("checkout")
        except Exception as e:
            logger.exception("Erro Processar: %s", e)
            messages.error(request, f"Erro no processamento: {str(e)}")
            return redirect("checkout")

    # ---------------------------------------------------------
    # Integração Asaas
    # ---------------------------------------------------------
    def _gerar_checkout_asaas(self, request, pedido, carrinho, metodo_pagamento, numero_parcelas):
        asaas_service = get_asaas_service()

        try:
            # Injeta CPF limpo em memória para esta transação
            if hasattr(request.user, "cpf_temporario_checkout"):
                request.user.cpf = request.user.cpf_temporario_checkout

            # Cria ou recupera cliente no Asaas
            cliente_asaas = asaas_service.criar_cliente(request.user)

            if not cliente_asaas or "id" not in cliente_asaas:
                erro_msg = "Erro ao criar cliente no Asaas."
                if isinstance(cliente_asaas, dict) and cliente_asaas.get("errors"):
                    erro_msg = cliente_asaas["errors"][0].get("description", erro_msg)
                raise Exception(erro_msg)

            pedido.asaas_customer_id = cliente_asaas["id"]

            # Cria cobrança
            if metodo_pagamento == "cartao_credito" and int(numero_parcelas) > 1:
                cobranca = asaas_service.criar_pagamento_cartao_credito_parcelado(
                    pedido=pedido,
                    customer_id=cliente_asaas["id"],
                    numero_parcelas=numero_parcelas,
                )
            else:
                cobranca = asaas_service.criar_pagamento(
                    pedido=pedido,
                    customer_id=cliente_asaas["id"],
                    metodo_pagamento=metodo_pagamento,
                )

            if not cobranca or "id" not in cobranca:
                erro_msg = "Erro ao gerar cobrança."
                if isinstance(cobranca, dict) and cobranca.get("errors"):
                    erro_msg = f"Asaas: {cobranca['errors'][0].get('description', erro_msg)}"
                raise Exception(erro_msg)

            pedido.asaas_payment_id = cobranca["id"]
            pedido.asaas_invoice_url = cobranca.get("invoiceUrl", "")

            if metodo_pagamento == "cartao_credito" and int(numero_parcelas) > 1:
                pedido.valor_parcela = Decimal(str(cobranca.get("installmentValue", 0) or 0)).quantize(Decimal("0.01"))
                pedido.asaas_installment_id = cobranca.get("installment")

            if metodo_pagamento == "pix":
                pedido.asaas_payment_url = cobranca.get("pixQrCodeUrl", "") or ""
                pedido.asaas_qr_code = cobranca.get("pixQrCodeUrl", "") or ""
                pedido.asaas_pix_code = cobranca.get("payload", "") or ""

            elif metodo_pagamento == "boleto":
                pedido.asaas_payment_url = cobranca.get("bankSlipUrl", "") or ""
                pedido.asaas_barcode = cobranca.get("identificationField", "") or ""

            elif metodo_pagamento in ["cartao_credito", "cartao_debito"]:
                pedido.asaas_payment_url = cobranca.get("invoiceUrl", "") or ""

            pedido.save()

            # --- Processamento do Cupom/Fidelidade ---
            if "cupom_aplicado" in request.session:
                cupom_id = (request.session.get("cupom_aplicado") or {}).get("id")
                if cupom_id:
                    try:
                        cupom = CupomDesconto.objects.get(id=cupom_id)
                        uso, recompensas = cupom.aplicar(request.user, float(pedido.subtotal), carrinho)

                        if uso:
                            uso.pedido = pedido
                            uso.save()

                        if recompensas:
                            msg_recompensas = []
                            for r in recompensas:
                                if r.get("tipo") == "pontos":
                                    msg_recompensas.append(f"+{r.get('valor')} pontos")
                                elif r.get("tipo") == "badge":
                                    msg_recompensas.append(f"Badge: {r.get('valor')}")
                                elif r.get("tipo") == "cashback":
                                    msg_recompensas.append(f"+R$ {float(r.get('valor', 0)):.2f} cashback")

                            if msg_recompensas:
                                messages.info(request, f"Recompensas do cupom: {', '.join(msg_recompensas)}")
                    except Exception:
                        pass

                # Remove cupom da sessão (independente do sucesso)
                try:
                    del request.session["cupom_aplicado"]
                except KeyError:
                    pass

            # ---------------------------------------------------------
            # Afiliado — limpa da sessão após concluir pedido (RECOMENDADO)
            # ---------------------------------------------------------
            for k in ("afiliado_ref", "codigo_referencia_afiliado", "ref", "referrer"):
                try:
                    del request.session[k]
                except KeyError:
                    pass

            # Limpa carrinho (modelo)
            try:
                carrinho.itens.all().delete()
                carrinho.delete()
            except Exception:
                pass

            # Mensagens finais
            if metodo_pagamento == "cartao_credito" and int(numero_parcelas) > 1:
                messages.success(
                    request,
                    f"Pedido realizado! Pague em {numero_parcelas}x de R$ {pedido.valor_parcela:.2f} no cartão."
                )
            else:
                messages.success(
                    request,
                    f"Pedido realizado! Efetue o pagamento via {pedido.get_metodo_pagamento_display()}."
                )

            return redirect("detalhe_pedido", pk=pedido.id)

        except Exception as e:
            pedido.status = "cancelado"
            pedido.save(update_fields=["status"])
            logger.exception("Erro Integração Asaas: %s", e)
            messages.error(request, f"Não foi possível concluir o pedido: {str(e)}")
            return redirect("checkout")




@method_decorator(login_required, name="dispatch")
class PagamentoView(View):
    template_name = "loja/carrinho/pagamento.html"

    def get(self, request, numero_pedido, *args, **kwargs):
        pedido = get_object_or_404(Pedido, numero_pedido=numero_pedido, usuario=request.user)

        # Se for PIX ou Boleto, geralmente temos campos específicos
        if not pedido.asaas_payment_id:
             messages.error(request, "Erro ao recuperar dados de pagamento.")
             return redirect("meus_pedidos")

        context = {
            "pedido": pedido,
            "checkout_url": pedido.asaas_invoice_url,
            # Garante que as variáveis existem no modelo Pedido ou usa strings vazias
            "qr_code": getattr(pedido, 'asaas_payment_url', '') if pedido.metodo_pagamento == 'pix' else '', 
            "pix_cola_e_copia": getattr(pedido, 'asaas_pix_code', ''),
            "barcode": getattr(pedido, 'asaas_barcode', ''),
            "invoice_url": pedido.asaas_invoice_url,
        }
        return render(request, self.template_name, context)


@method_decorator(login_required, name="dispatch")
class PagamentoSucessoView(View):
    def get(self, request, *args, **kwargs):
        payment_id = request.GET.get("payment_id")

        if payment_id:
            try:
                asaas_service = get_asaas_service()
                payment_info = asaas_service.consultar_pagamento(payment_id)

                if payment_info and payment_info.get("status") in ["RECEIVED", "CONFIRMED"]:
                    try:
                        pedido = Pedido.objects.get(asaas_payment_id=payment_id)
                        pedido.processar_pagamento_confirmado()
                        messages.success(
                            request, f"Pagamento confirmado! Seu pedido #{pedido.numero_pedido} foi processado."
                        )
                        return redirect("detalhe_pedido", pk=pedido.id)
                    except Pedido.DoesNotExist:
                        logger.error(f"Pedido não encontrado para payment_id: {payment_id}")

            except Exception as e:
                logger.error(f"Erro ao processar sucesso de pagamento: {str(e)}")

        messages.info(request, "Seu pagamento está sendo processado. Você receberá uma confirmação em breve.")
        return redirect("meus_pedidos")


@method_decorator(login_required, name="dispatch")
class PagamentoFalhaView(View):
    def get(self, request, *args, **kwargs):
        payment_id = request.GET.get("payment_id")

        if payment_id:
            try:
                pedido = Pedido.objects.get(asaas_payment_id=payment_id)
                pedido.cancelar(motivo="Falha no pagamento (Retorno Asaas)")
                messages.error(request, "Pagamento não realizado. Seu pedido foi cancelado.")
            except Pedido.DoesNotExist:
                messages.error(request, "Pedido não encontrado.")

        return redirect("carrinho")
# ═══════════════════════════════════════════════════════════════════════════
# PERFIL E CONTA
# ═══════════════════════════════════════════════════════════════════════════

@method_decorator(login_required, name="dispatch")
class PerfilView(View):
    template_name = "loja/conta/perfil.html"

    def get(self, request, *args, **kwargs):
        try:
            perfil, created = PerfilUsuario.objects.get_or_create(usuario=request.user)
            carrinho = obter_carrinho(request)
            carrinho_count = obter_carrinho_count(request)
            register_link = request.build_absolute_uri(reverse("registro")) + f"?codigo_referencia={request.user.codigo_referencia}"
            config = ConfiguracaoSite.load()
            steps = [
                {"name": "Prata", "target": float(getattr(config, "fidelidade_meta_prata", 500) or 0)},
                {"name": "Ouro", "target": float(getattr(config, "fidelidade_meta_ouro", 2000) or 0)},
                {"name": "Platina", "target": float(getattr(config, "fidelidade_meta_platina", 5000) or 0)},
                {"name": "Diamante", "target": float(getattr(config, "fidelidade_meta_diamante", 10000) or 0)},
            ]

            # Atualiza badges pendentes (inclui referidos) antes de renderizar
            try:
                request.user.avaliar_badges()
            except Exception:
                pass

            badges_usuario = request.user.badges.select_related("badge").order_by("-data_obtida")
            badges_map = {ub.badge_id: ub for ub in badges_usuario}
            todas_badges = list(Badge.objects.filter(ativa=True).order_by("raridade", "nome"))
            badges_list = []
            for badge in todas_badges:
                ub = badges_map.get(badge.id)
                badges_list.append(
                    {
                        "badge": badge,
                        "conquistada": ub is not None,
                        "data_obtida": ub.data_obtida if ub else None,
                        "novo": ub.novo if ub else False,
                    }
                )

            context = {
                "usuario": request.user,
                "perfil": perfil,
                "carrinho": carrinho,
                "carrinho_count": carrinho_count,
                "register_link": register_link,
                "config_site": config,
                "badges_usuario": badges_usuario,
                "badges_list": badges_list,
                "notificacoes_nao_lidas": Notificacao.objects.filter(usuario=request.user, lida=False).count() if request.user.is_authenticated else 0,
                "level_steps_json": json.dumps(steps),
            }
            return render(request, self.template_name, context)

        except Exception as e:
            messages.error(request, f"Erro ao carregar perfil: {str(e)}")
            return redirect("home")

    def post(self, request, *args, **kwargs):
        try:
            usuario = request.user
            perfil, created = PerfilUsuario.objects.get_or_create(usuario=usuario)

            usuario.first_name = request.POST.get("first_name", usuario.first_name)
            usuario.last_name = request.POST.get("last_name", usuario.last_name)

            telefone_bruto = request.POST.get("telefone", "")
            if telefone_bruto:
                usuario.telefone = re.sub(r"\D", "", telefone_bruto)

            usuario.tipo_cliente = request.POST.get("tipo_cliente", "F")
            usuario.aceita_marketing = "aceita_marketing" in request.POST

            data_nascimento_str = request.POST.get("data_nascimento")
            if data_nascimento_str:
                try:
                    usuario.data_nascimento = datetime.strptime(data_nascimento_str, "%Y-%m-%d").date()
                except ValueError:
                    pass

            if usuario.tipo_cliente == "F":
                perfil.cpf = request.POST.get("cpf", "")
                perfil.cnpj = ""
            else:
                perfil.cnpj = request.POST.get("cnpj", "")
                perfil.cpf = ""

            perfil.cep = request.POST.get("cep", "")
            perfil.endereco = request.POST.get("endereco", "")
            perfil.numero = request.POST.get("numero", "")
            perfil.complemento = request.POST.get("complemento", "")
            perfil.bairro = request.POST.get("bairro", "")
            perfil.cidade = request.POST.get("cidade", "")
            perfil.estado = request.POST.get("estado", "")

            if "avatar" in request.FILES:
                imagem = request.FILES["avatar"]
                if imagem.size > 5 * 1024 * 1024:
                    messages.error(request, "A imagem deve ter no máximo 5MB.")
                    return redirect("perfil")
                else:
                    if perfil.avatar:
                        try:
                            perfil.avatar.delete(save=False)
                        except Exception:
                            pass
                    perfil.avatar = imagem

            perfil.full_clean()
            usuario.save()
            perfil.save()

            messages.success(request, "Perfil atualizado com sucesso!")

        except ValidationError as e:
            messages.error(request, f"Erro de validação: {e.message_dict}")
        except Exception as e:
            messages.error(request, f"Erro ao atualizar: {str(e)}")

        return redirect("perfil")


class BadgesListView(View):
    template_name = "loja/badges.html"

    def get(self, request, *args, **kwargs):
        try:
            if request.user.is_authenticated:
                try:
                    request.user.avaliar_badges()
                except Exception:
                    pass
            badges = Badge.objects.filter(ativa=True).order_by("raridade", "nome")
            conquistas = {}
            if request.user.is_authenticated:
                conquistas = {ub.badge_id: ub for ub in request.user.badges.select_related("badge")}

            badges_list = []
            for badge in badges:
                ub = conquistas.get(badge.id)
                badges_list.append(
                    {
                        "badge": badge,
                        "conquistada": ub is not None,
                        "data_obtida": getattr(ub, "data_obtida", None),
                        "novo": getattr(ub, "novo", False),
                    }
                )

            context = {
                "badges": badges,
                "badges_list": badges_list,
                "config_site": ConfiguracaoSite.load(),
                "carrinho_count": obter_carrinho_count(request),
                "notificacoes_nao_lidas": Notificacao.objects.filter(usuario=request.user, lida=False).count()
                if request.user.is_authenticated
                else 0,
            }
            return render(request, self.template_name, context)
        except Exception as e:
            messages.error(request, f"Erro ao carregar badges: {str(e)}")
            return redirect("home")


class BadgeDetailView(View):
    template_name = "loja/badge_detalhe.html"

    def _descricao_condicao(self, badge):
        tipos = {
            "primeira_compra": "Primeira compra realizada",
            "compras_totais": f"{badge.condicao_valor} compras concluídas",
            "valor_total": f"Gasto acumulado de R$ {badge.condicao_valor}",
            "pontos_acumulados": f"{badge.condicao_valor} pontos acumulados",
            "avaliacoes": f"{badge.condicao_valor} avaliações aprovadas",
            "referidos": f"{badge.condicao_valor} referidos convertidos",
            "nivel_fidelidade": f"Nível de fidelidade mínimo: {badge.condicao_valor}",
        }
        return tipos.get(badge.condicao_tipo, "")

    def get(self, request, slug, *args, **kwargs):
        try:
            badge = get_object_or_404(Badge, slug=slug, ativa=True)
            conquista = None
            if request.user.is_authenticated:
                try:
                    request.user.avaliar_badges()
                except Exception:
                    pass
                conquista = request.user.badges.select_related("badge").filter(badge=badge).first()

            context = {
                "badge": badge,
                "conquista": conquista,
                "descricao_condicao": self._descricao_condicao(badge),
                "config_site": ConfiguracaoSite.load(),
                "carrinho_count": obter_carrinho_count(request),
                "notificacoes_nao_lidas": Notificacao.objects.filter(usuario=request.user, lida=False).count()
                if request.user.is_authenticated
                else 0,
            }
            return render(request, self.template_name, context)
        except Exception as e:
            messages.error(request, f"Badge nao encontrada ou inativa: {str(e)}")
            return redirect("badges")


@method_decorator(login_required, name="dispatch")
class MeusPedidosView(ListView):
    model = Pedido
    template_name = "loja/conta/meus_pedidos.html"
    context_object_name = "pedidos"
    paginate_by = 10

    def get_queryset(self):
        queryset = (
            Pedido.objects.filter(usuario=self.request.user)
            .select_related("endereco_entrega")
            .prefetch_related("itens__produto")
        )

        status_filter = self.request.GET.get("status")
        if status_filter:
            queryset = queryset.filter(status=status_filter)

        ordenacao = self.request.GET.get("ordenacao")
        if ordenacao == "data_criacao":
            queryset = queryset.order_by("data_criacao")
        elif ordenacao == "-total":
            queryset = queryset.order_by("-total")
        else:
            queryset = queryset.order_by("-data_criacao")

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["notificacoes_nao_lidas"] = Notificacao.objects.filter(
            usuario=self.request.user, lida=False
        ).count()
        context["carrinho_count"] = obter_carrinho_count(self.request)
        context["config_site"] = ConfiguracaoSite.load()
        return context


@method_decorator(login_required, name="dispatch")
class DetalhePedidoView(DetailView):
    model = Pedido
    template_name = "loja/conta/detalhe_pedido.html"
    context_object_name = "pedido"

    def get_queryset(self):
        return Pedido.objects.filter(usuario=self.request.user).prefetch_related("itens__produto")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["notificacoes_nao_lidas"] = Notificacao.objects.filter(
            usuario=self.request.user, lida=False
        ).count()
        context["carrinho_count"] = obter_carrinho_count(self.request)
        context["config_site"] = ConfiguracaoSite.load()
        return context


@login_required
@require_POST
def cancelar_pedido(request, pedido_id):
    pedido = get_object_or_404(Pedido, id=pedido_id, usuario=request.user)

    status_cancelaveis = ["pendente", "aguardando_pagamento", "processando"]

    if pedido.status in status_cancelaveis:
        pedido.cancelar(motivo="Cancelamento solicitado pelo cliente")
        messages.success(request, f"Pedido #{pedido.numero_pedido} cancelado com sucesso.")
    else:
        messages.error(request, "Este pedido não pode ser cancelado pois já foi enviado ou finalizado.")

    return redirect("meus_pedidos")


@method_decorator(login_required, name="dispatch")
class EnderecosView(View):
    template_name = "loja/conta/enderecos.html"

    def get(self, request, *args, **kwargs):
        enderecos = EnderecoEntrega.objects.filter(usuario=request.user, ativo=True).order_by("-principal", "-id")
        context = {"enderecos": enderecos, "estados": EnderecoEntrega.ESTADO_CHOICES}
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        action = request.POST.get("action")

        if action == "adicionar":
            return self._adicionar_endereco(request)
        elif action == "editar":
            return self._editar_endereco(request)
        elif action == "excluir":
            return self._excluir_endereco(request)
        elif action == "definir_principal":
            return self._definir_principal(request)
        else:
            messages.error(request, "Ação inválida.")
            return redirect("enderecos")

    def _adicionar_endereco(self, request):
        try:
            is_principal = request.POST.get("principal") == "on"

            with transaction.atomic():
                if is_principal:
                    EnderecoEntrega.objects.filter(usuario=request.user, principal=True).update(principal=False)

                if not EnderecoEntrega.objects.filter(usuario=request.user, ativo=True).exists():
                    is_principal = True

                endereco = EnderecoEntrega(
                    usuario=request.user,
                    apelido=request.POST.get("tipo", "Casa"),
                    nome_destinatario=request.POST.get("nome_destinatario"),
                    telefone=request.POST.get("telefone"),
                    cep=request.POST.get("cep"),
                    endereco=request.POST.get("endereco"),
                    numero=request.POST.get("numero"),
                    complemento=request.POST.get("complemento", ""),
                    bairro=request.POST.get("bairro"),
                    cidade=request.POST.get("cidade"),
                    estado=request.POST.get("estado"),
                    principal=is_principal,
                    ativo=True,
                )

                endereco.full_clean()
                endereco.save()
                messages.success(request, "Endereço adicionado com sucesso!")

        except ValidationError as e:
            for field, errors in e.message_dict.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
        except Exception as e:
            messages.error(request, f"Erro ao adicionar: {str(e)}")

        return redirect("enderecos")

    def _editar_endereco(self, request):
        endereco_id = request.POST.get("endereco_id")
        try:
            with transaction.atomic():
                endereco = get_object_or_404(EnderecoEntrega, id=endereco_id, usuario=request.user)

                is_principal = request.POST.get("principal") == "on"
                if is_principal and not endereco.principal:
                    EnderecoEntrega.objects.filter(usuario=request.user, principal=True).update(principal=False)

                endereco.apelido = request.POST.get("tipo", endereco.apelido)
                endereco.nome_destinatario = request.POST.get("nome_destinatario")
                endereco.telefone = request.POST.get("telefone")
                endereco.cep = request.POST.get("cep")
                endereco.endereco = request.POST.get("endereco")
                endereco.numero = request.POST.get("numero")
                endereco.complemento = request.POST.get("complemento", "")
                endereco.bairro = request.POST.get("bairro")
                endereco.cidade = request.POST.get("cidade")
                endereco.estado = request.POST.get("estado")
                endereco.principal = is_principal

                endereco.full_clean()
                endereco.save()
                messages.success(request, "Endereço atualizado!")

        except ValidationError as e:
            messages.error(request, f"Erro de validação: {e}")
        except Exception as e:
            messages.error(request, f"Erro ao atualizar: {str(e)}")

        return redirect("enderecos")

    def _excluir_endereco(self, request):
        endereco_id = request.POST.get("endereco_id")
        try:
            endereco = get_object_or_404(EnderecoEntrega, id=endereco_id, usuario=request.user)
            tem_pedidos = Pedido.objects.filter(endereco_entrega=endereco).exists()

            if tem_pedidos:
                endereco.ativo = False
                endereco.principal = False
                endereco.save()

                outro = EnderecoEntrega.objects.filter(usuario=request.user, ativo=True).first()
                if outro:
                    outro.principal = True
                    outro.save()
                messages.success(request, "Endereço removido (arquivado).")
            else:
                endereco.delete()
                messages.success(request, "Endereço excluído.")
        except Exception as e:
            messages.error(request, f"Erro ao excluir: {str(e)}")
        return redirect("enderecos")

    def _definir_principal(self, request):
        endereco_id = request.POST.get("endereco_id")
        try:
            with transaction.atomic():
                endereco = get_object_or_404(EnderecoEntrega, id=endereco_id, usuario=request.user, ativo=True)
                EnderecoEntrega.objects.filter(usuario=request.user, principal=True).update(principal=False)
                endereco.principal = True
                endereco.save()
                messages.success(request, "Endereço principal atualizado!")
        except Exception as e:
            messages.error(request, "Erro ao definir principal.")
        return redirect("enderecos")


@method_decorator(login_required, name="dispatch")
class AlterarSenhaView(View):
    template_name = "loja/conta/alterar_senha.html"

    def get(self, request, *args, **kwargs):
        form = PasswordChangeForm(request.user)
        context = {
            "form": form,
            "carrinho_count": obter_carrinho_count(request),
            "notificacoes_nao_lidas": Notificacao.objects.filter(usuario=request.user, lida=False).count() if request.user.is_authenticated else 0,
        }
        return render(request, self.template_name, context)


class EsqueciSenhaView(View):
    template_name = "loja/conta/esqueci_senha.html"

    def get(self, request, *args, **kwargs):
        form = PasswordResetForm()
        form.fields["email"].widget.attrs.update(
            {"placeholder": "seuemail@dominio.com", "autocomplete": "email", "required": True}
        )
        context = {
            "form": form,
            "carrinho_count": obter_carrinho_count(request),
            "notificacoes_nao_lidas": Notificacao.objects.filter(usuario=request.user, lida=False).count() if request.user.is_authenticated else 0,
        }
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        form = PasswordResetForm(request.POST)
        form.fields["email"].widget.attrs.update(
            {"placeholder": "seuemail@dominio.com", "autocomplete": "email", "required": True}
        )
        if form.is_valid():
            domain = request.get_host()
            form.save(
                request=request,
                use_https=request.is_secure(),
                domain_override=domain,
                email_template_name="emails/password_reset_email.txt",
                subject_template_name="emails/password_reset_subject.txt",
            )
            messages.success(request, "Enviamos um e-mail com instruções e código para redefinir sua senha.")
            return redirect("password_reset_done")

        context = {
            "form": form,
            "carrinho_count": obter_carrinho_count(request),
            "notificacoes_nao_lidas": Notificacao.objects.filter(usuario=request.user, lida=False).count() if request.user.is_authenticated else 0,
        }
        return render(request, self.template_name, context)


@method_decorator(login_required, name="dispatch")
class ExportarDadosView(View):
    def get(self, request, *args, **kwargs):
        response = HttpResponse(content_type="text/csv")
        response["Content-Disposition"] = 'attachment; filename="meus_dados.csv"'

        writer = csv.writer(response)
        writer.writerow(["Campo", "Valor"])

        usuario = request.user
        writer.writerow(["Nome", usuario.get_full_name()])
        writer.writerow(["Email", usuario.email])
        writer.writerow(["Telefone", usuario.telefone])
        writer.writerow(["Tipo de Cliente", usuario.get_tipo_cliente_display()])
        writer.writerow(["Data de Nascimento", usuario.data_nascimento])
        writer.writerow(["Data de Cadastro", usuario.date_joined])
        writer.writerow(["Pontos Disponíveis", usuario.pontos_disponiveis])
        writer.writerow(["Nível Fidelidade", usuario.nivel_fidelidade])
        writer.writerow(["Cashback Disponível", usuario.saldo_cashback])

        if hasattr(usuario, "perfil"):
            perfil = usuario.perfil
            writer.writerow(["CPF/CNPJ", perfil.cpf or perfil.cnpj])
            writer.writerow(["CEP", perfil.cep])
            writer.writerow(["Endereço", perfil.endereco])
            writer.writerow(["Número", perfil.numero])
            writer.writerow(["Complemento", perfil.complemento])
            writer.writerow(["Bairro", perfil.bairro])
            writer.writerow(["Cidade", perfil.cidade])
            writer.writerow(["Estado", perfil.estado])
            writer.writerow(["País", perfil.pais])

        return response


@method_decorator(login_required, name="dispatch")
class NotificacoesView(ListView):
    model = Notificacao
    template_name = "loja/conta/notificacoes.html"
    context_object_name = "notificacoes"
    paginate_by = 20

    def get_queryset(self):
        return Notificacao.objects.filter(usuario=self.request.user).order_by("-data_criacao")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        try:
            context["carrinho_count"] = obter_carrinho_count(self.request)
        except Exception:
            context["carrinho_count"] = 0
        return context

    def post(self, request, *args, **kwargs):
        action = request.POST.get("action")

        if action == "marcar_todas_lidas":
            Notificacao.objects.filter(usuario=request.user, lida=False).update(lida=True)
            messages.success(request, "Todas as notificações marcadas como lidas!")
        elif action == "limpar_todas":
            Notificacao.objects.filter(usuario=request.user).delete()
            messages.success(request, "Todas as notificações foram removidas!")

        return redirect("notificacoes")


@method_decorator(login_required, name="dispatch")
class SaqueCashbackView(View):
    template_name = "loja/conta/saque_cashback.html"

    def get(self, request, *args, **kwargs):
        saldo = getattr(request.user, "saldo_cashback", Decimal("0"))
        return render(request, self.template_name, {"saldo": saldo})

    def post(self, request, *args, **kwargs):
        saldo = getattr(request.user, "saldo_cashback", Decimal("0"))
        valor_raw = str(request.POST.get("valor", "0")).replace(",", ".")

        try:
            valor = Decimal(valor_raw)
        except Exception:
            messages.error(request, "Valor inválido.")
            return redirect("saque_cashback")

        if valor <= 0:
            messages.error(request, "Informe um valor maior que zero.")
            return redirect("saque_cashback")

        if valor > saldo:
            messages.error(request, "Saldo de cashback insuficiente.")
            return redirect("saque_cashback")

        # Obrigar saque apenas para o CPF cadastrado (minimiza fraude)
        cpf_candidato = ""
        if hasattr(request.user, "cpf") and request.user.cpf:
            cpf_candidato = request.user.cpf
        if not cpf_candidato and hasattr(request.user, "perfil") and getattr(request.user.perfil, "cpf", ""):
            cpf_candidato = request.user.perfil.cpf

        cpf_limpo = re.sub(r"\D", "", str(cpf_candidato or ""))
        if not cpf_limpo or len(cpf_limpo) != 11:
            messages.error(request, "Cadastre um CPF válido no perfil para sacar via PIX.")
            return redirect("saque_cashback")

        # Força a chave a ser o CPF cadastrado (não permite outra)
        chave_pix = cpf_limpo

        config = ConfiguracaoSite.load()
        minimo = getattr(config, "cashback_saque_minimo", Decimal("0"))
        maximo = getattr(config, "cashback_saque_maximo", Decimal("0"))
        if minimo and valor < minimo:
            messages.error(request, f"Valor mínimo para saque: R$ {minimo:.2f}")
            return redirect("saque_cashback")
        if maximo and valor > maximo:
            messages.error(request, f"Valor máximo para saque: R$ {maximo:.2f}")
            return redirect("saque_cashback")

        try:
            asaas_service = get_asaas_service()
            descricao = f"Saque cashback usuário #{request.user.id}"
            resp = asaas_service.criar_transferencia_pix_cashback(request.user, valor, chave_pix, descricao=descricao)

            # Debita saldo local somente após sucesso
            referencia = ""
            try:
                referencia = str(resp.get("id", "")) if isinstance(resp, dict) else ""
            except Exception:
                referencia = ""
            request.user.usar_cashback(
                valor,
                origem="saque_pix",
                motivo="Saque de cashback via PIX",
                referencia=referencia or "",
            )

            messages.success(request, "Solicitação de saque enviada com sucesso!")
            return redirect("saque_cashback")
        except Exception as e:
            messages.error(request, f"Erro ao solicitar saque: {e}")
            return redirect("saque_cashback")


@method_decorator(login_required, name="dispatch")
class RegistrosCashbackView(ListView):
    template_name = "loja/conta/registros_cashback.html"
    context_object_name = "registros"
    paginate_by = 20

    def get_queryset(self):
        return (
            RegistroCashback.objects.filter(usuario=self.request.user)
            .select_related("pedido")
            .order_by("-data_criacao")
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["saldo_cashback"] = getattr(self.request.user, "saldo_cashback", Decimal("0"))
        context["total_recebido"] = getattr(self.request.user, "total_cashback_recebido", Decimal("0"))
        return context


@method_decorator(login_required, name="dispatch")
class RegistrosPontosView(ListView):
    template_name = "loja/conta/registros_pontos.html"
    context_object_name = "registros"
    paginate_by = 20

    def get_queryset(self):
        return (
            RegistroPontos.objects.filter(usuario=self.request.user)
            .select_related("pedido")
            .order_by("-data_criacao")
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["pontos_disponiveis"] = getattr(self.request.user, "pontos_disponiveis", 0)
        context["pontos_totais"] = getattr(self.request.user, "pontos_totais", 0)
        return context


@method_decorator(login_required, name="dispatch")
class MarcarNotificacaoLidaView(View):
    def post(self, request, notificacao_id, *args, **kwargs):
        try:
            notificacao = Notificacao.objects.get(id=notificacao_id, usuario=request.user)
            notificacao.marcar_como_lida()

            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse({"success": True})
            else:
                messages.success(request, "Notificação marcada como lida!")

        except Notificacao.DoesNotExist:
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse({"success": False, "error": "Notificação não encontrada"})
            else:
                messages.error(request, "Notificação não encontrada.")

        return redirect("notificacoes")

# ═══════════════════════════════════════════════════════════════════════════
# WISHLIST
# ═══════════════════════════════════════════════════════════════════════════

@method_decorator(login_required, name="dispatch")
class WishlistView(View):
    template_name = "loja/wishlist/wishlist.html"

    def get(self, request, *args, **kwargs):
        wishlist, created = Wishlist.objects.get_or_create(usuario=request.user)

        wishlist_count = wishlist.produtos.count()
        carrinho_count = obter_carrinho_count(request)

        context = {
            "wishlist": wishlist,
            "wishlist_items": wishlist.produtos.filter(disponivel=True).select_related("categoria", "marca"),
            "wishlist_count": wishlist_count,
            "carrinho_count": carrinho_count,
        }
        return render(request, self.template_name, context)


@method_decorator(login_required, name="dispatch")
class AdicionarWishlistView(View):
    @method_decorator(require_POST)
    def post(self, request, *args, **kwargs):
        produto_id = request.POST.get("produto_id")

        try:
            produto = Produto.objects.get(id=produto_id, disponivel=True)
            wishlist, created = Wishlist.objects.get_or_create(usuario=request.user)
            wishlist.adicionar_produto(produto)

            wishlist_count = wishlist.produtos.count()

            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse(
                    {
                        "success": True,
                        "message": "Produto adicionado à wishlist!",
                        "wishlist_count": wishlist_count,
                    }
                )
            else:
                messages.success(request, "Produto adicionado à wishlist!")
                return redirect(request.META.get("HTTP_REFERER", "wishlist"))

        except Produto.DoesNotExist:
            message = "Produto não encontrado."
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse({"success": False, "message": message})
            else:
                messages.error(request, message)
                return redirect(request.META.get("HTTP_REFERER", "wishlist"))


@method_decorator(login_required, name="dispatch")
class RemoverWishlistView(View):
    @method_decorator(require_POST)
    def post(self, request, *args, **kwargs):
        produto_id = request.POST.get("produto_id")

        try:
            produto = Produto.objects.get(id=produto_id)
            wishlist = Wishlist.objects.get(usuario=request.user)
            wishlist.remover_produto(produto)

            wishlist_count = wishlist.produtos.count()

            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse(
                    {
                        "success": True,
                        "message": "Produto removido da wishlist!",
                        "wishlist_count": wishlist_count,
                    }
                )
            else:
                messages.success(request, "Produto removido da wishlist!")
                return redirect("wishlist")

        except (Produto.DoesNotExist, Wishlist.DoesNotExist):
            message = "Produto não encontrado na wishlist."
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse({"success": False, "message": message})
            else:
                messages.error(request, message)
                return redirect("wishlist")


@method_decorator(login_required, name="dispatch")
class LimparWishlistView(View):
    @method_decorator(require_POST)
    def post(self, request, *args, **kwargs):
        try:
            wishlist = Wishlist.objects.get(usuario=request.user)
            wishlist.produtos.clear()

            messages.success(request, "Wishlist limpa com sucesso!")
            return redirect("wishlist")

        except Wishlist.DoesNotExist:
            messages.error(request, "Wishlist não encontrada.")
            return redirect("wishlist")

# ═══════════════════════════════════════════════════════════════════════════
# AVALIAÇÕES
# ═══════════════════════════════════════════════════════════════════════════

@method_decorator(login_required, name="dispatch")
class CriarAvaliacaoView(View):
    @method_decorator(require_POST)
    def post(self, request, *args, **kwargs):
        produto_id = request.POST.get("produto_id")
        avaliacao = request.POST.get("avaliacao")
        titulo = request.POST.get("titulo")
        comentario = request.POST.get("comentario")
        recomendacao = request.POST.get("recomendacao") == "on"

        try:
            produto = Produto.objects.get(id=produto_id)

            item = ItemPedido.objects.filter(
                pedido__usuario=request.user,
                pedido__status__in=["entregue"],
                produto=produto,
            ).first()

            if not item:
                messages.error(request, "Você só pode avaliar produtos já entregues.")
                return redirect("produto_detalhe", slug=produto.slug)

            if AvaliacaoProduto.objects.filter(usuario=request.user, produto=produto, pedido=item.pedido).exists():
                messages.info(request, "Você já avaliou este produto neste pedido.")
                return redirect("produto_detalhe", slug=produto.slug)

            AvaliacaoProduto.objects.create(
                produto=produto,
                usuario=request.user,
                nome_cliente=f"{request.user.first_name} {request.user.last_name}",
                email=request.user.email,
                avaliacao=int(avaliacao),
                titulo=titulo,
                comentario=comentario,
                recomendacao=recomendacao,
                aprovado=False,
                pedido=item.pedido,
                item_pedido=item,
            )

            messages.success(request, "Avaliação enviada com sucesso! Ela será publicada após aprovação.")

        except Produto.DoesNotExist:
            messages.error(request, "Produto não encontrado.")
        except Exception:
            messages.error(request, "Erro ao enviar avaliação.")

        return redirect("produto_detalhe", slug=produto.slug)

# ═══════════════════════════════════════════════════════════════════════════
# AUTENTICAÇÃO
# ═══════════════════════════════════════════════════════════════════════════

class LoginView(View):
    template_name = "loja/conta/login.html"

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            next_url = request.GET.get("next", "home")
            return redirect(next_url)

        context = {
            "next": request.GET.get("next", ""),
            "marcas": Marca.objects.filter(ativa=True).order_by("ordem")[:12],
        }
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        email = request.POST.get("email")
        password = request.POST.get("password")
        next_url = request.POST.get("next", "home")

        if not email or not password:
            messages.error(request, "Por favor, preencha todos os campos.")
            context = {
                "next": next_url,
                "marcas": Marca.objects.filter(ativa=True).order_by("ordem")[:12],
            }
            return render(request, self.template_name, context)

        try:
            from django.contrib.auth import get_user_model

            User = get_user_model()

            user = User.objects.get(email=email)

            if user.check_password(password):
                login(request, user)
                messages.success(request, f"Bem-vindo de volta, {user.first_name or user.email}!")

                if next_url and next_url != "None":
                    return redirect(next_url)
                return redirect("home")
            else:
                messages.error(request, "Senha incorreta. Tente novamente.")

        except User.DoesNotExist:
            messages.error(request, "E-mail não cadastrado. Verifique ou crie uma conta.")
        except Exception as e:
            messages.error(request, f"Erro durante o login: {str(e)}")

        context = {
            "next": next_url,
            "marcas": Marca.objects.filter(ativa=True).order_by("ordem")[:12],
        }
        return render(request, self.template_name, context)


class LogoutView(View):
    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            logout(request)
            messages.success(request, "Você saiu da sua conta. Até logo!")

        return redirect("home")


class RegistroView(View):
    template_name = "loja/conta/registro.html"

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect("home")

        codigo_ref = request.GET.get("codigo_referencia", "").strip().upper()
        if codigo_ref:
            request.session["codigo_referencia"] = codigo_ref
        else:
            codigo_ref = request.session.get("codigo_referencia", "")

        context = {
            "marcas": Marca.objects.filter(ativa=True).order_by("ordem")[:12],
            "codigo_referencia": codigo_ref,
        }
        return render(request, self.template_name, context)

    def post(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect("home")

        try:
            from django.contrib.auth import get_user_model

            User = get_user_model()

            first_name = request.POST.get("first_name", "").strip()
            last_name = request.POST.get("last_name", "").strip()
            email = request.POST.get("email", "").strip()
            password = request.POST.get("password", "")
            confirm_password = request.POST.get("confirm_password", "")

            telefone = request.POST.get("telefone", "").strip()
            data_nascimento_str = request.POST.get("data_nascimento")

            cpf = request.POST.get("cpf", "").replace(".", "").replace("-", "")
            cep = request.POST.get("cep", "").replace("-", "")
            endereco = request.POST.get("endereco", "")
            numero = request.POST.get("numero", "")
            complemento = request.POST.get("complemento", "")
            bairro = request.POST.get("bairro", "")
            cidade = request.POST.get("cidade", "")
            estado = request.POST.get("estado", "")
            referido_codigo = request.POST.get("codigo_referencia", "").strip().upper()
            if not referido_codigo:
                referido_codigo = request.session.pop("codigo_referencia", "").strip().upper()

            referidor = None
            if referido_codigo:
                referidor = User.objects.filter(codigo_referencia=referido_codigo).first()
                if not referidor:
                    messages.warning(request, "Código de indicação inválido ou expirado.")
                    referidor = None

            data_nascimento = None
            if data_nascimento_str:
                try:
                    data_nascimento = datetime.strptime(data_nascimento_str, "%Y-%m-%d").date()
                except ValueError:
                    pass

            if not email or not password:
                messages.error(request, "E-mail e senha são obrigatórios.")
                return render(request, self.template_name)

            if password != confirm_password:
                messages.error(request, "As senhas não coincidem.")
                return render(request, self.template_name)

            if not request.POST.get("termos"):
                messages.error(request, "Você precisa aceitar os Termos de Uso para continuar.")
                return render(request, self.template_name)

            if User.objects.filter(email=email).exists():
                messages.error(request, "Este email já está em uso.")
                return render(request, self.template_name)

            user = User.objects.create_user(
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name,
                referido_por=referidor,
            )

            PerfilUsuario.objects.create(
                usuario=user,
                cpf=cpf,
                cep=cep,
                endereco=endereco,
                numero=numero,
                complemento=complemento,
                bairro=bairro,
                cidade=cidade,
                estado=estado,
            )

            user.gerar_codigo_referencia()

            if referidor:
                try:
                    referidor.total_referencias += 1
                    referidor.save(update_fields=["total_referencias"])

                    # Garantir bônus de indicação no cadastro (reaplica se por algum motivo o save inicial não aplicou)
                    try:
                        ja_bonificado = (
                            RegistroCashback.objects.filter(
                                usuario=referidor, motivo__icontains="cadastro", data_criacao__gte=user.data_criacao
                            ).exists()
                            or RegistroPontos.objects.filter(
                                usuario=referidor, motivo__icontains="cadastro", data_criacao__gte=user.data_criacao
                            ).exists()
                        )
                        if not ja_bonificado:
                            user._aplicar_bonus_referencia_registro()
                    except Exception:
                        pass

                    Notificacao.objects.create(
                        usuario=referidor,
                        tipo="fidelidade",
                        titulo="Indicação convertida",
                        mensagem=f"Sua indicação {user.first_name or user.email} se cadastrou. Bônus aplicado.",
                    )
                except Exception:
                    pass

            try:
                Wishlist.objects.create(usuario=user)
            except Exception:
                pass

            login(request, user)

            pontos_bonus = 0
            try:
                config = ConfiguracaoSite.load()
                if config and getattr(config, "bonus_pontos_boas_vindas", 0) > 0:
                    pontos_bonus = int(config.bonus_pontos_boas_vindas)
                    user.adicionar_pontos(pontos_bonus, motivo="Bônus de boas-vindas")
            except Exception:
                pass

            if pontos_bonus > 0:
                messages.success(request, f"Bem-vindo(a), {first_name}! Você ganhou {pontos_bonus} pontos de boas-vindas.")
            else:
                messages.success(request, f"Bem-vindo(a), {first_name}!")
            return redirect("home")

        except Exception as e:
            logger.error(f"Erro: {e}")
            messages.error(request, "Ocorreu um erro ao criar a conta. Verifique os dados.")
            return render(request, self.template_name)

# ═══════════════════════════════════════════════════════════════════════════
# WEBHOOKS
# ═══════════════════════════════════════════════════════════════════════════

import json
import logging
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.urls import reverse
from django.utils import timezone

from loja.models import Pedido
from loja.models import LogPagamento
from loja.models import Notificacao

logger = logging.getLogger(__name__)


# ================================================
# 🔔 WEBHOOK OFICIAL ASAAS
# ================================================
@csrf_exempt
@require_POST
def webhook_asaas(request):
    """Recebe notificações do Asaas e atualiza automaticamente o Pedido."""

    try:
        # ------------------------------
        # 1. PARSE DO JSON ENVIADO
        # ------------------------------
        try:
            data = json.loads(request.body.decode("utf-8"))
        except Exception:
            return JsonResponse({"error": "JSON inválido"}, status=400)

        event = data.get("event")
        payment = data.get("payment", {})

        payment_id = payment.get("id")
        external_reference = payment.get("externalReference")
        status = (payment.get("status") or "").upper()

        logger.info(f"📩 Webhook recebido: {event} | Payment {payment_id} | Status {status}")

        if not external_reference:
            return JsonResponse({"error": "externalReference ausente"}, status=400)

        # ------------------------------
        # 2. LOCALIZA O PEDIDO
        # ------------------------------
        try:
            pedido = Pedido.objects.get(numero_pedido=external_reference)
        except Pedido.DoesNotExist:
            return JsonResponse({"error": "Pedido não encontrado"}, status=404)

        # ------------------------------
        # 3. REGISTRA LOG DO EVENTO
        # ------------------------------
        LogPagamento.objects.create(
            pedido=pedido,
            evento=event,
            id_externo=payment_id,
            payload_recebido=data
        )

        # ------------------------------
        # 4. MAPA OFICIAL DE STATUS
        # ------------------------------
        STATUS_MAP = {
            "RECEIVED": "pago",
            "CONFIRMED": "pago",
            "RECEIVED_IN_CASH": "pago",
            "PENDING": "pendente",
            "OVERDUE": "atrasado",
            "REFUNDED": "reembolsado",
            "CANCELLED": "cancelado",
            "DELETED": "cancelado",
            "FAILED": "falha",
            "CHARGEBACK": "chargeback",
        }

        status_normalizado = STATUS_MAP.get(status, "pendente")

        # ================================================
        # 🔥 TRATAMENTO AUTOMÁTICO POR EVENTO
        # ================================================

        # ------------------------------
        # PAGAMENTO RECEBIDO (MAIS IMPORTANTE)
        # ------------------------------
        if status in ["RECEIVED", "CONFIRMED", "RECEIVED_IN_CASH"]:
            pedido.processar_pagamento_confirmado()

            Notificacao.objects.create(
                usuario=pedido.usuario,
                tipo="pagamento",
                titulo="Pagamento Confirmado",
                mensagem=f"Seu pedido #{pedido.numero_pedido} foi pago com sucesso! 🎉",
                link=reverse("detalhe_pedido", kwargs={"pk": pedido.id})
            )

            logger.info(f"✅ Pagamento confirmado para pedido {pedido.numero_pedido}")

        # ------------------------------
        # PAGAMENTO VENCIDO
        # ------------------------------
        elif status == "OVERDUE":
            pedido.cancelar(motivo="Pagamento vencido")

            Notificacao.objects.create(
                usuario=pedido.usuario,
                tipo="pagamento",
                titulo="Pagamento Vencido",
                mensagem=f"O pagamento do pedido #{pedido.numero_pedido} não foi realizado e o pedido foi cancelado.",
                link=reverse("detalhe_pedido", kwargs={"pk": pedido.id})
            )

            logger.warning(f"⚠ Pedido {pedido.numero_pedido} cancelado por atraso de pagamento")

        # ------------------------------
        # ESTORNO (REFUND)
        # ------------------------------
        elif status == "REFUNDED":
            pedido.status_pagamento = "reembolsado"
            pedido.save()

            Notificacao.objects.create(
                usuario=pedido.usuario,
                tipo="pagamento",
                titulo="Pagamento Estornado",
                mensagem=f"O pagamento do pedido #{pedido.numero_pedido} foi estornado pelo Asaas.",
                link=reverse("detalhe_pedido", kwargs={"pk": pedido.id})
            )

            logger.warning(f"💸 Pedido {pedido.numero_pedido} estornado")

        # ------------------------------
        # CANCELADO / DELETADO
        # ------------------------------
        elif status in ["CANCELLED", "DELETED"]:
            pedido.cancelar(motivo="Cancelado no Asaas")

            logger.warning(f"🚫 Pedido {pedido.numero_pedido} cancelado no Asaas")

        # ------------------------------
        # CHARGEBACK
        # ------------------------------
        elif status == "CHARGEBACK":
            pedido.status_pagamento = "chargeback"
            pedido.save()

            logger.error(f"❌ Chargeback registrado no pedido {pedido.numero_pedido}")

        # ------------------------------
        # ATUALIZA STATUS PADRÃO
        # ------------------------------
        pedido.status_pagamento = status_normalizado
        pedido.data_atualizacao_pagamento = timezone.now()
        pedido.save()

        return JsonResponse({"success": True})

    except Exception as e:
        logger.error(f"❌ Erro no webhook Asaas: {e}")
        return JsonResponse({"error": str(e)}, status=500)


# ═══════════════════════════════════════════════════════════════════════════
# APIs E AJAX
# ═══════════════════════════════════════════════════════════════════════════

def calcular_frete(request):
    if request.method == "POST":
        cep = request.POST.get("cep")
        subtotal = float(request.POST.get("subtotal", 0))

        config_site = ConfiguracaoSite.objects.first()

        if config_site and subtotal >= float(config_site.valor_frete_gratis):
            return JsonResponse({"frete_gratis": True, "valor": 0, "prazo": "5-7 dias úteis"})

        valor_frete = float(config_site.valor_frete_padrao) if config_site else 15.00
        prazo = "7-10 dias úteis"

        return JsonResponse({"frete_gratis": False, "valor": valor_frete, "prazo": prazo})

    return JsonResponse({"error": "Método não permitido"}, status=405)


def buscar_cep(request):
    cep = re.sub(r"\D", "", request.GET.get("cep", ""))

    if len(cep) != 8:
        return JsonResponse({"error": "CEP inválido"}, status=400)

    try:
        resp = requests.get(f"https://viacep.com.br/ws/{cep}/json/", timeout=5)
        resp.raise_for_status()
        data = resp.json()
        if data.get("erro"):
            return JsonResponse({"error": "CEP não encontrado"}, status=404)

        return JsonResponse(
            {
                "cep": data.get("cep", f"{cep[:5]}-{cep[5:]}"),
                "logradouro": data.get("logradouro", ""),
                "bairro": data.get("bairro", ""),
                "cidade": data.get("localidade", ""),
                "estado": data.get("uf", ""),
            }
        )
    except requests.exceptions.RequestException as e:
        logging.warning("Erro ao consultar ViaCEP: %s", e)
        return JsonResponse({"error": "Não foi possível consultar o CEP agora"}, status=503)


def filtrar_produtos(request):
    """View para filtrar produtos via AJAX."""
    if request.method == "GET":
        try:
            categorias = request.GET.getlist("category[]")
            marcas = request.GET.getlist("brand[]")
            preco_max = request.GET.get("preco_max")
            ratings = request.GET.getlist("rating[]")
            search_query = request.GET.get("q", "")

            produtos = Produto.objects.filter(disponivel=True)

            if categorias:
                produtos = produtos.filter(categoria__nome__in=categorias)

            if marcas:
                produtos = produtos.filter(marca__nome__in=marcas)

            if preco_max and preco_max != "799":
                produtos = produtos.filter(preco__lte=float(preco_max))

            if ratings:
                rating_queries = Q()
                for rating in ratings:
                    rating_value = int(rating)
                    rating_queries |= Q(avaliacao_media__gte=rating_value)
                produtos = produtos.filter(rating_queries)

            if search_query:
                produtos = produtos.filter(
                    Q(nome__icontains=search_query)
                    | Q(descricao_resumida__icontains=search_query)
                    | Q(categoria__nome__icontains=search_query)
                    | Q(marca__nome__icontains=search_query)
                )

            produtos_data = []
            for produto in produtos:
                produto_data = {
                    "id": produto.id,
                    "nome": produto.nome,
                    "slug": produto.slug,
                    "preco": float(produto.preco),
                    "preco_antigo": float(produto.preco_antigo) if produto.preco_antigo else None,
                    "em_promocao": produto.em_promocao,
                    "percentual_desconto": produto.percentual_desconto,
                    "imagem_principal": produto.imagem_principal.url if produto.imagem_principal else "",
                    "categoria": produto.categoria.nome if produto.categoria else "",
                    "categoria_slug": produto.categoria.slug if produto.categoria else "",
                    "marca": produto.marca.nome if produto.marca else "",
                    "marca_slug": produto.marca.slug if produto.marca else "",
                    "avaliacao_media": float(produto.avaliacao_media) if produto.avaliacao_media else 0,
                    "numero_avaliacoes": produto.numero_avaliacoes,
                    "estoque": produto.estoque,
                    "is_novo": produto.is_novo,
                    "is_kit": produto.is_kit,
                }
                produtos_data.append(produto_data)

            return JsonResponse(
                {"success": True, "produtos": produtos_data, "total_produtos": produtos.count(), "message": f"{produtos.count()} produtos encontrados"}
            )

        except Exception as e:
            return JsonResponse({"success": False, "error": str(e), "message": "Erro ao filtrar produtos"})

    return JsonResponse({"success": False, "message": "Método não permitido"})

# ═══════════════════════════════════════════════════════════════════════════
# CHATBOT E IA
# ═══════════════════════════════════════════════════════════════════════════

@csrf_exempt
def chat_agent_view(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            mensagem_usuario = data.get("message", "").lower().strip()
            mensagem_usuario = mensagem_usuario[:400]  # hard limit para evitar prompt injection/extensões enormes

            api_key = getattr(settings, "GEMINI_API_KEY", None)
            if not api_key:
                # Fallback simples sem IA externa
                produtos = list(Produto.objects.filter(disponivel=True, estoque__gt=0)[:3])
                dicas = [
                    f"{p.nome} - R$ {p.preco}"
                    for p in produtos
                ]
                return JsonResponse(
                    {
                        "success": True,
                        "agent_response": "Atualmente o assistente está offline. Sugestões rápidas:\n- " + "\n- ".join(dicas)
                    }
                )

            if not request.user.is_authenticated:
                termos_pessoais = ["meu pedido", "rastrear", "minha conta", "meus dados", "meu carrinho", "carrinho"]
                if any(termo in mensagem_usuario for termo in termos_pessoais):
                    return JsonResponse(
                        {"success": True, "agent_response": "🔐 **Login Necessário**\n\nPara acessar seus dados, faça login."}
                    )

            import google.generativeai as genai

            genai.configure(api_key=api_key)

            def get_image_url(objeto, candidate_fields):
                for field in candidate_fields:
                    try:
                        img_field = getattr(objeto, field, None)
                        if img_field and hasattr(img_field, "url"):
                            return request.build_absolute_uri(img_field.url)
                    except Exception:
                        continue
                return request.build_absolute_uri(settings.STATIC_URL + "images/sem-foto.jpg")

            def formatar_produto(produto, motivo=""):
                url_img = get_image_url(produto, ["imagem_principal", "imagem", "foto"])
                try:
                    link = request.build_absolute_uri(reverse("produto_detalhe", args=[produto.slug]))
                except Exception:
                    link = request.build_absolute_uri(f"/produto/{produto.slug}/")

                preco = f"R$ {produto.preco}"
                marca = produto.marca.nome if produto.marca else "Genérica"
                return f"| TIPO: PRODUTO {motivo} | NOME: {produto.nome} | PRECO: {preco} | MARCA: {marca} | LINK: {link} | IMG: {url_img}"

            def formatar_categoria(categoria):
                try:
                    link = request.build_absolute_uri(f"/catalogo/?categoria={categoria.slug}")
                except Exception:
                    link = request.build_absolute_uri(f"/catalogo/")
                url_img = get_image_url(categoria, ["icone", "imagem"])
                return f"| TIPO: CATEGORIA | NOME: {categoria.nome} | LINK: {link} | IMG: {url_img}"

            def formatar_marca(marca):
                link = request.build_absolute_uri(f"/catalogo/?marca={marca.slug}")
                url_img = get_image_url(marca, ["logotipo", "logo", "imagem", "icone"])
                return f"| TIPO: MARCA | NOME: {marca.nome} | LINK: {link} | IMG: {url_img}"

            def formatar_cupom(cupom):
                valor = f"{int(cupom.valor_desconto)}%" if cupom.tipo_desconto == "percentual" else f"R$ {cupom.valor_desconto}"
                return f"| CUPOM: {cupom.codigo} | VALOR: {valor} | EXPIRA: {cupom.data_fim}"

            contexto_usuario = ""
            carrinho_txt = "Vazio"

            try:
                if request.user.is_authenticated:
                    carrinho = Carrinho.objects.filter(usuario=request.user).first()
                    if carrinho and carrinho.itens.exists():
                        itens = [formatar_produto(i.produto, "[NO CARRINHO]") for i in carrinho.itens.all()]
                        carrinho_txt = "\n".join(itens)
            except Exception:
                pass

            if request.user.is_authenticated:
                pedidos = Pedido.objects.filter(usuario=request.user).order_by("-data_criacao")[:3]
                if pedidos.exists():
                    hist_txt = "\n**SEUS PEDIDOS RECENTES:**"
                    for p in pedidos:
                        status = p.get_status_display()
                        try:
                            url_p = request.build_absolute_uri(f"/minha-conta/pedidos/{p.id}/")
                        except Exception:
                            url_p = "#"
                        hist_txt += f"\n- Pedido #{p.numero_pedido}: {status} | [Ver Detalhes]({url_p})"
                    contexto_usuario += hist_txt

            produtos = Produto.objects.filter(disponivel=True, estoque__gt=0)[:4]
            txt_produtos = "\n".join([formatar_produto(p) for p in produtos])

            categorias = Categoria.objects.filter(ativa=True).order_by("ordem")[:5]
            txt_categorias = "\n".join([formatar_categoria(c) for c in categorias])

            marcas = Marca.objects.filter(ativa=True)[:5]
            txt_marcas = "\n".join([formatar_marca(m) for m in marcas])

            cupons = CupomDesconto.objects.filter(ativo=True, data_fim__gte=timezone.now())[:2]
            txt_cupons = "\n".join([formatar_cupom(c) for c in cupons])

            instrucoes = f"""
            Você é o assistente virtual da Loja. Responda curto e direto.

            ### 🖼️ REGRAS DE IMAGEM (IMPORTANTE):
            Para Marcas, Categorias e Produtos, use SEMPRE este formato Markdown exato:
            [![Nome](URL_DA_IMAGEM)](LINK)

            ### DADOS DISPONÍVEIS:
            **[CLIENTE]** {contexto_usuario}
            **[CARRINHO]** {carrinho_txt}
            **[PRODUTOS DESTAQUE]** {txt_produtos}
            **[CATEGORIAS]** {txt_categorias}
            **[MARCAS]** {txt_marcas}
            **[CUPONS]** {txt_cupons}
            """

            model = genai.GenerativeModel("gemini-2.5-flash", system_instruction=instrucoes)
            response = model.generate_content(mensagem_usuario)

            return JsonResponse({"success": True, "agent_response": response.text})

        except Exception as e:
            logger.error(f"Erro chat: {e}")
            return JsonResponse({"success": True, "agent_response": "Assistente indisponível no momento. Tente novamente em instantes."})

    return JsonResponse({"error": "Método inválido"}, status=405)

# ═══════════════════════════════════════════════════════════════════════════
# RECOMENDAÇÕES IA
# ═══════════════════════════════════════════════════════════════════════════

class RecomendacaoIAView(View):
    """View otimizada para gerar recomendações via Gemini AI (2 produtos)."""

    CACHE_TIMEOUT = 3600

    def get(self, request, *args, **kwargs):
        try:
            if request.user.is_authenticated:
                user_key = f"recom_ia_user_2items_{request.user.id}"
                is_logged = True
            else:
                if not request.session.session_key:
                    request.session.save()
                user_key = f"recom_ia_anon_2items_{request.session.session_key}"
                is_logged = False

            cached_result = cache.get(user_key)
            if cached_result:
                response = JsonResponse(cached_result)
                response["X-Cache-Hit"] = "True"
                return response

            response_data = self._processar_nova_recomendacao(request, is_logged)

            if response_data.get("success") and not response_data.get("fallback_error", False):
                cache.set(user_key, response_data, self.CACHE_TIMEOUT)

            return JsonResponse(response_data)

        except Exception as e:
            logger.error(f"Erro crítico na View RecomendacaoIA: {str(e)}", exc_info=True)
            return self._retornar_fallback(request, erro_critico=True)

    def _processar_nova_recomendacao(self, request, is_logged):
        # API Key ausente: fallback direto
        api_key = getattr(settings, "GEMINI_API_KEY", None)
        if not is_logged or not api_key:
            return {
                "success": True,
                "recomendacoes": self._gerar_recomendacoes_visitante(request),
                "fallback": True,
                "user_logged_in": is_logged,
                "message": "Sugestões populares",
            }

        perfil_usuario = self._coletar_perfil_usuario(request.user)
        candidatos = self._obter_produtos_candidatos(request.user)

        if not candidatos.exists():
            return {
                "success": True,
                "recomendacoes": self._gerar_recomendacoes_visitante(request),
                "fallback": True,
                "message": "Sugestões populares",
                "user_logged_in": is_logged,
            }

        try:
            recomendacoes = self._gerar_recomendacoes_ia(request, perfil_usuario, candidatos)
            return {"success": True, "recomendacoes": recomendacoes, "fallback": False, "user_logged_in": True}
        except Exception as e:
            logger.warning(f"Falha na IA, usando fallback local: {e}")
            return {
                "success": True,
                "recomendacoes": self._gerar_fallback_local(request, candidatos, perfil_usuario),
                "fallback": True,
                "fallback_error": True,
                "user_logged_in": True,
                "message": "Sugestões rápidas enquanto a IA se reconecta",
            }

    def _coletar_perfil_usuario(self, user):
        perfil = {"historico_compras": "Nenhuma", "wishlist": "Vazia", "total_compras": 0, "tipo_usuario": "cliente_novo"}

        try:
            total_pedidos = Pedido.objects.filter(usuario=user).count()
            perfil["total_compras"] = total_pedidos
            perfil["tipo_usuario"] = "cliente_fiel" if total_pedidos > 2 else ("cliente_regular" if total_pedidos > 0 else "cliente_novo")

            if total_pedidos > 0:
                ultimos_itens = (
                    ItemPedido.objects.filter(pedido__usuario=user)
                    .select_related("produto", "produto__categoria")
                    .order_by("-pedido__data_criacao")[:5]
                )

                nomes = [f"{i.produto.nome} ({i.produto.categoria.nome})" for i in ultimos_itens]
                if nomes:
                    perfil["historico_compras"] = "; ".join(nomes)

            self._processar_wishlist(user, perfil)

        except Exception as e:
            logger.error(f"Erro perfil: {e}")

        return perfil

    def _processar_wishlist(self, user, perfil):
        try:
            wishlist = Wishlist.objects.filter(usuario=user).first()
            if wishlist:
                nomes = list(wishlist.produtos.values_list("nome", flat=True)[:10])
                if nomes:
                    perfil["wishlist"] = ", ".join(nomes)
        except Exception as e:
            logger.warning(f"Erro ao ler wishlist: {e}")

    def _obter_produtos_candidatos(self, user):
        qs = (
            Produto.objects.filter(disponivel=True, estoque__gt=0)
            .select_related("categoria", "marca")
            .defer("descricao_completa")
        )

        if user.is_authenticated:
            try:
                comprados_ids = ItemPedido.objects.filter(pedido__usuario=user).values_list("produto_id", flat=True)
                if comprados_ids:
                    qs = qs.exclude(id__in=comprados_ids)
            except Exception:
                pass

        return qs.order_by("-vendas_totais", "-data_criacao")[:30]

    def _gerar_recomendacoes_ia(self, request, perfil, candidatos):
        api_key = getattr(settings, "GEMINI_API_KEY", None)
        if not api_key:
            raise ValueError("API Key não configurada")

        import google.generativeai as genai

        genai.configure(api_key=api_key)

        model = genai.GenerativeModel("gemini-2.5-flash")

        catalogo_txt = self._formatar_catalogo_compacto(request, candidatos)
        prompt = self._construir_prompt_compacto(perfil, catalogo_txt)

        generation_config = genai.types.GenerationConfig(temperature=0.3, max_output_tokens=10000, response_mime_type="application/json")

        response = model.generate_content(prompt, generation_config=generation_config)
        texto_resposta = self._extrair_texto_resposta(response)
        if not texto_resposta:
            # Se a IA não retornou texto útil (ex: finish_reason == MAX_TOKENS), força fallback
            raise ValueError("Resposta vazia ou incompleta da IA (finish_reason/MAX_TOKENS).")

        return self._processar_resposta_ia(request, texto_resposta, candidatos)

    def _extrair_texto_resposta(self, resp):
        """Garante extração segura do texto, mesmo se response.text não existir."""
        try:
            # Tenta ler o primeiro candidato válido
            if hasattr(resp, "candidates") and resp.candidates:
                cand = resp.candidates[0]
                finish_reason = getattr(cand, "finish_reason", None)
                if finish_reason and str(finish_reason).lower() == "max_tokens":
                    return ""
                content = getattr(cand, "content", None)
                if content and getattr(content, "parts", None):
                    parts = []
                    for part in content.parts:
                        txt = getattr(part, "text", None)
                        if txt:
                            parts.append(txt)
                        elif isinstance(part, str):
                            parts.append(part)
                    if parts:
                        return "\n".join(parts)
            # Fallback: se resp.text existir e não levantar exceção
            if hasattr(resp, "text"):
                return resp.text
        except Exception:
            return ""
        return ""

    def _construir_prompt_compacto(self, perfil, catalogo):
        return f"""
        Atue como Especialista de E-commerce.
        PERFIL: {perfil['tipo_usuario']} | HISTÓRICO: {perfil['historico_compras']} | WISHLIST: {perfil['wishlist']}

        CATÁLOGO (ID|Nome|Preço|Categoria|Tags):
        {catalogo}

        TAREFA: Selecione 2 produtos ideais baseados no histórico e interesses.
        RETORNE JSON APENAS: {{ "recomendacoes": [ {{ "id": 123, "motivo": "Motivo curto" }} ] }}
        """

    def _processar_resposta_ia(self, request, text_response, candidatos):
        try:
            json_match = re.search(r"\{.*\}", text_response, re.DOTALL)
            clean_json = json_match.group(0) if json_match else text_response

            data = json.loads(clean_json)
            recs = data.get("recomendacoes", [])

            if not recs:
                raise ValueError("JSON vazio")

            produtos_map = {p.id: p for p in candidatos}
            resultado = []

            for r in recs[:2]:
                pid = int(r.get("id", 0))
                if pid in produtos_map:
                    prod = produtos_map[pid]
                    motivo = r.get("motivo", "Sugerido para você")
                    resultado.append(self._formatar_produto_resposta(request, prod, motivo))

            if not resultado:
                raise ValueError("Nenhuma recomendação válida")

            return resultado

        except Exception as e:
            logger.error(f"Erro parser IA: {e}")
            raise

    def _formatar_catalogo_compacto(self, request, candidatos):
        lines = []
        for p in candidatos[:20]:
            extras = []
            if p.em_promocao:
                extras.append("PROMO")
            if "kit" in p.nome.lower():
                extras.append("KIT")
            extra_s = "|".join(extras)
            lines.append(f"{p.id}|{p.nome[:35]}|{p.preco}|{p.categoria.nome[:15]}|{extra_s}")
        return "\n".join(lines)

    def _gerar_fallback_local(self, request, candidatos, perfil):
        prods = list(candidatos[:2])
        res = []
        msg_padrao = "Mais vendido" if perfil.get("tipo_usuario") == "visitante" else "Baseado no seu perfil"

        for p in prods:
            res.append(self._formatar_produto_resposta(request, p, msg_padrao))
        return res

    def _gerar_recomendacoes_visitante(self, request):
        top_prods = Produto.objects.filter(disponivel=True, estoque__gt=0).order_by("-vendas_totais")[:2]
        return [self._formatar_produto_resposta(request, p, "Tendência agora") for p in top_prods]

    def _formatar_produto_resposta(self, request, produto, motivo):
        img = settings.STATIC_URL + "images/sem-foto.jpg"

        campos_img = ["imagem_principal", "imagem", "foto"]
        for campo in campos_img:
            val = getattr(produto, campo, None)
            if val and hasattr(val, "url"):
                try:
                    img = request.build_absolute_uri(val.url)
                    break
                except Exception:
                    pass

        try:
            link = request.build_absolute_uri(reverse("produto_detalhe", args=[produto.slug]))
        except Exception:
            link = request.build_absolute_uri(f"/produto/{produto.slug}/")

        preco = float(produto.preco)
        old = float(produto.preco_antigo) if produto.preco_antigo else 0
        tem_desc = old > preco

        return {
            "id": produto.id,
            "nome": produto.nome,
            "preco": f"{preco:.2f}".replace(".", ","),
            "preco_antigo": f"{old:.2f}".replace(".", ",") if tem_desc else None,
            "tem_desconto": tem_desc,
            "imagem": img,
            "url_produto": link,
            "motivo": motivo[:70],
            "tags": self._gerar_tags_produto(produto),
        }

    def _gerar_tags_produto(self, produto):
        tags = []
        if produto.preco_antigo and produto.preco < produto.preco_antigo:
            try:
                perc = (1 - (produto.preco / produto.preco_antigo)) * 100
                if perc >= 5:
                    tags.append({"tipo": "oferta", "texto": f"-{int(perc)}%"})
            except Exception:
                pass

        if "kit" in produto.nome.lower():
            tags.append({"tipo": "kit", "texto": "KIT"})

        if hasattr(produto, "data_criacao") and produto.data_criacao:
            dias = (timezone.now() - produto.data_criacao).days
            if dias <= 30:
                tags.append({"tipo": "novo", "texto": "NOVO"})

        return tags

    def _dados_fallback(self, request, msg):
        # Usa success True para não quebrar o front; devolve lista vazia e mensagem
        return {"success": True, "recomendacoes": [], "fallback": True, "message": msg}

    def _retornar_fallback(self, request, erro_critico=False):
        prods = self._gerar_recomendacoes_visitante(request)
        return JsonResponse({"success": True, "recomendacoes": prods, "fallback": True, "message": "Sugestões populares"})

# ═══════════════════════════════════════════════════════════════════════════
# CUPONS DE AFILIADO
# ═══════════════════════════════════════════════════════════════════════════

@login_required
def criar_cupom_afiliado(request):
    """Permite que o usuário crie seu próprio cupom de afiliado."""
    config = ConfiguracaoSite.load()

    qtd_cupons = CupomDesconto.objects.filter(criador=request.user, ativo=True).count()
    if qtd_cupons >= 5:
        messages.warning(request, "Você já atingiu o limite de 5 cupons ativos.")
        return redirect("listar_meus_cupons")

    if request.method == "POST":
        form = CupomAfiliadoForm(request.POST)

        if form.is_valid():
            try:
                with transaction.atomic():
                    cupom = form.save(commit=False)

                    cupom.criador = request.user
                    cupom.alcance = "afiliado"
                    cupom.valor_desconto = config.afiliado_desconto_padrao
                    cupom.comissao_afiliado = config.afiliado_comissao_padrao
                    cupom.tipo_desconto = "percentual"
                    cupom.data_inicio = timezone.now()
                    cupom.data_fim = timezone.now() + timedelta(days=365)
                    cupom.ativo = True
                    cupom.save()

                messages.success(request, f"🚀 Sucesso! O cupom {cupom.codigo} foi criado e já está valendo.")
                return redirect("listar_meus_cupons")

            except Exception as e:
                logger.error(f"Erro ao criar cupom: {e}", exc_info=True)
                messages.error(request, "Ocorreu um erro ao gerar seu cupom. Tente novamente.")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
    else:
        form = CupomAfiliadoForm()

    context = {"form": form, "config": config}
    return render(request, "loja/afiliados/painel_afiliado_criar.html", context)


@login_required
def listar_meus_cupons(request):
    """Dashboard do Afiliado: Mostra os cupons criados e estatísticas básicas."""
    cupons = CupomDesconto.objects.filter(criador=request.user).order_by("-data_criacao")
    config = ConfiguracaoSite.load()

    context = {
        "cupons": cupons,
        "config": config,
        "config_site": config,
        "carrinho_count": obter_carrinho_count(request),
        "notificacoes_nao_lidas": Notificacao.objects.filter(usuario=request.user, lida=False).count()
        if request.user.is_authenticated
        else 0,
    }
    return render(request, "loja/afiliados/painel_afiliado_lista.html", context)


@login_required
def desativar_cupom(request, cupom_id):
    """Permite que o usuário desative um cupom antigo."""
    cupom = get_object_or_404(CupomDesconto, id=cupom_id, criador=request.user)

    if request.method == "POST":
        cupom.ativo = False
        cupom.save()
        messages.info(request, f"O cupom {cupom.codigo} foi desativado.")

    return redirect("listar_meus_cupons")





from django.shortcuts import render

def handler404(request, exception):
    return render(request, 'erros/404.html', status=404)

def handler500(request):
    return render(request, 'erros/500.html', status=500)

def handler403(request, exception):
    return render(request, 'erros/403.html', status=403)

def handler400(request, exception):
    return render(request, 'erros/400.html', status=400)





from django.views import View
from django.shortcuts import render
from .models import ConfiguracaoSite  # ajuste o import conforme seu projeto

class TermosView(View):
    def get(self, request, *args, **kwargs):
        config_site = ConfiguracaoSite.load()
        return render(request, "loja/termos.html", {"config_site": config_site})

class PrivacidadeView(View):
    def get(self, request, *args, **kwargs):
        config_site = ConfiguracaoSite.load()
        return render(request, "loja/privacidade.html", {"config_site": config_site})






import logging
from decimal import Decimal
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q, Sum, Count
from django.utils.decorators import method_decorator
from django.views.generic import TemplateView
from django.urls import reverse
from urllib.parse import urljoin

from .models import (
    Produto, ConfiguracaoSite, ItemPedido, CupomDesconto, 
    Usuario, Pedido, RegistroCashback, RegistroPontos, CupomDescontoUso
)

logger = logging.getLogger(__name__)


@method_decorator(login_required, name="dispatch")
class AfiliadoDashboardView(TemplateView):
    template_name = "loja/afiliados/dashboard.html"
    paginate_by = 12

    # ----------------------------
    # Helpers comissão
    # ----------------------------
    @staticmethod
    def _dec(v, default="0"):
        try:
            if v is None or v == "":
                return Decimal(str(default))
            return Decimal(str(v).replace(",", "."))
        except Exception:
            return Decimal(str(default))

    def _preco_produto(self, produto: Produto) -> Decimal:
        """Preço efetivo: promocional ou preço normal"""
        promo = self._dec(getattr(produto, "preco_promocional", None), "0")
        if promo > 0:
            return promo.quantize(Decimal("0.01"))
        preco = self._dec(getattr(produto, "preco", None), "0")
        return preco.quantize(Decimal("0.01"))

    def _comissao_pct_produto(self, produto: Produto, config_site) -> Decimal:
        """% comissão do produto ou padrão"""
        pct_prod = getattr(produto, "comissao_afiliado_pct", None)
        if pct_prod is not None:
            return self._dec(pct_prod, "0")
        pct_padrao = getattr(config_site, "afiliado_comissao_padrao", Decimal("10.00"))
        return self._dec(pct_padrao, "0")

    def _comissao_fixa_produto(self, produto: Produto, config_site) -> Decimal:
        """Comissão fixa do produto ou 0"""
        fixa_prod = getattr(produto, "comissao_afiliado_fixa", None)
        if fixa_prod is not None:
            return self._dec(fixa_prod, "0").quantize(Decimal("0.01"))
        return Decimal("0.00")

    def _calcular_comissao_valor(self, base: Decimal, pct: Decimal, fixa: Decimal) -> Decimal:
        """Calcula comissão final"""
        if fixa and fixa > 0:
            return fixa.quantize(Decimal("0.01"))
        if pct and pct > 0 and base and base > 0:
            return (base * pct / Decimal("100")).quantize(Decimal("0.01"))
        return Decimal("0.00")

    def _pedido_confirmado(self, pedido) -> bool:
        """Verifica se pedido está confirmado"""
        status = (getattr(pedido, "status", "") or "").lower()
        pag_status = (getattr(pedido, "pagamento_status", "") or "").lower()
        confirmados_pag = {"confirmado", "recebido", "recebido_parcialmente"}
        confirmados_status = {"pago", "processando", "enviado", "entregue"}
        return (pag_status in confirmados_pag) or (status in confirmados_status)

    # ----------------------------
    # Context
    # ----------------------------
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        request = self.request

        config_site = ConfiguracaoSite.load()
        codigo_ref = getattr(request.user, "codigo_referencia", "") or ""

        q = (request.GET.get("q") or "").strip()

        # ===== PRODUTOS =====
        produtos = (
            Produto.objects
            .filter(disponivel=True)
            .select_related("categoria", "marca")
            .order_by("-id")
        )

        if q:
            produtos = produtos.filter(
                Q(nome__icontains=q) |
                Q(sku__icontains=q) |
                Q(descricao_resumida__icontains=q) |
                Q(categoria__nome__icontains=q) |
                Q(marca__nome__icontains=q)
            )

        paginator = Paginator(produtos, self.paginate_by)
        page_obj = paginator.get_page(request.GET.get("page"))

        # Produtos com link + comissão estimada
        produtos_com_links = []
        for p in page_obj.object_list:
            try:
                link = p.get_link_afiliado(request.user)
            except Exception as e:
                logger.exception("Erro gerando link afiliado do produto %s: %s", p.id, e)
                link = ""

            preco_efetivo = self._preco_produto(p)
            pct = self._comissao_pct_produto(p, config_site)
            fixa = self._comissao_fixa_produto(p, config_site)
            ganho_estimado = self._calcular_comissao_valor(preco_efetivo, pct, fixa)

            produtos_com_links.append({
                "produto": p,
                "link": link,
                "preco_efetivo": preco_efetivo,
                "comissao_pct": pct,
                "comissao_fixa": fixa,
                "ganho_estimado": ganho_estimado,
            })

        # ===== CUPONS DO AFILIADO =====
        cupons = []
        if request.user.is_authenticated:
            cupons = (
                CupomDesconto.objects
                .filter(criador=request.user, alcance="afiliado")
                .annotate(uso_count=Count('usos'))
                .order_by("-data_criacao")
            )

        # ===== PEDIDOS ATRIBUÍDOS AO AFILIADO =====
        pedidos_resumo = []
        total_pendente = Decimal("0.00")
        total_confirmado = Decimal("0.00")

        if codigo_ref:
            itens = (
                ItemPedido.objects
                .filter(afiliado_codigo_ref=codigo_ref)
                .select_related("pedido", "produto")
                .order_by("-pedido__data_criacao")[:200]
            )

            por_pedido = {}
            for it in itens:
                pedido = it.pedido
                if not pedido:
                    continue
                pid = pedido.id

                if pid not in por_pedido:
                    por_pedido[pid] = {
                        "pedido": pedido,
                        "valor_itens": Decimal("0.00"),
                        "comissao": Decimal("0.00"),
                        "itens_count": 0,
                    }

                base_item = self._dec(getattr(it, "subtotal", None), "0")
                if base_item == 0:
                    base_item = (
                        self._dec(getattr(it, "preco_unitario", 0), "0") *
                        self._dec(getattr(it, "quantidade", 0), "0")
                    )
                base_item = base_item.quantize(Decimal("0.01"))

                comissao_item_field = getattr(it, "comissao_gerada", None)
                if comissao_item_field is not None:
                    comissao_item = self._dec(comissao_item_field, "0").quantize(Decimal("0.01"))
                else:
                    produto = it.produto
                    pct = (
                        self._comissao_pct_produto(produto, config_site)
                        if produto else
                        self._dec(getattr(config_site, "afiliado_comissao_padrao", 0), "0")
                    )
                    fixa = (
                        self._comissao_fixa_produto(produto, config_site)
                        if produto else Decimal("0.00")
                    )
                    comissao_item = self._calcular_comissao_valor(base_item, pct, fixa)

                por_pedido[pid]["valor_itens"] += base_item
                por_pedido[pid]["comissao"] += comissao_item
                por_pedido[pid]["itens_count"] += 1

            for pid, d in por_pedido.items():
                pedido = d["pedido"]
                com = d["comissao"].quantize(Decimal("0.01"))

                if self._pedido_confirmado(pedido):
                    total_confirmado += com
                    status_tipo = "confirmado"
                else:
                    total_pendente += com
                    status_tipo = "pendente"

                pedidos_resumo.append({
                    "pedido": pedido,
                    "itens_count": d["itens_count"],
                    "valor_itens": d["valor_itens"].quantize(Decimal("0.01")),
                    "comissao": com,
                    "status_tipo": status_tipo,
                })

            pedidos_resumo.sort(
                key=lambda x: getattr(x["pedido"], "data_criacao", None) or 0,
                reverse=True
            )
            pedidos_resumo = pedidos_resumo[:25]

        # ===== TOTAIS =====
        total_confirmado = total_confirmado.quantize(Decimal("0.01"))
        total_pendente = total_pendente.quantize(Decimal("0.01"))
        total_geral = (total_confirmado + total_pendente).quantize(Decimal("0.01"))

        # ===== ESTATÍSTICAS =====
        stats_cupons = {
            "total_cupons": cupons.count(),
            "cupons_ativos": cupons.filter(ativo=True).count(),
            "total_usos": sum(c.uso_count for c in cupons) if cupons else 0,
        }

        stats_pedidos = {
            "total_pedidos": len(pedidos_resumo),
            "pedidos_confirmados": sum(1 for p in pedidos_resumo if p["status_tipo"] == "confirmado"),
            "pedidos_pendentes": sum(1 for p in pedidos_resumo if p["status_tipo"] == "pendente"),
        }

        # ===== CASHBACK DO AFILIADO =====
        cashback_info = {
            "saldo_disponivel": getattr(request.user, "saldo_cashback", Decimal("0.00")),
            "total_recebido": getattr(request.user, "total_cashback_recebido", Decimal("0.00")),
            "saque_minimo": getattr(config_site, "afiliado_saque_minimo", Decimal("50.00")),
        }

        # ===== URL DE REFERÊNCIA (SIMPLES) =====
        referral_url = ""
        if codigo_ref:
            referral_url = urljoin(
                f"{request.scheme}://{request.get_host()}",
                f"/conta/registrar/?codigo_referencia={codigo_ref}"
            )

        context.update({
            "config_site": config_site,
            "q": q,
            "page_obj": page_obj,
            "produtos_com_links": produtos_com_links,
            "codigo_ref": codigo_ref,
            "referral_url": referral_url,

            # Cupons
            "cupons": cupons,
            "stats_cupons": stats_cupons,

            # Configurações
            "afiliado_cfg": {
                "afiliado_desconto_padrao": getattr(config_site, "afiliado_desconto_padrao", None),
                "afiliado_comissao_padrao": getattr(config_site, "afiliado_comissao_padrao", None),
                "afiliado_limite_cupons": getattr(config_site, "afiliado_limite_cupons", None),
                "afiliado_validade_dias": getattr(config_site, "afiliado_validade_dias", None),
                "afiliado_prefixo_codigo": getattr(config_site, "afiliado_prefixo_codigo", None),
                "afiliado_codigo_auto": getattr(config_site, "afiliado_codigo_auto", None),
            },

            # Pedidos
            "pedidos_resumo": pedidos_resumo,
            "stats_pedidos": stats_pedidos,
            "total_pendente": total_pendente,
            "total_confirmado": total_confirmado,
            "total_geral": total_geral,

            # Cashback
            "cashback_info": cashback_info,

            # Notificações
            "carrinho_count": getattr(request.user, "carrinho_count", 0) or 0,
            "notificacoes_nao_lidas": (
                request.user.notificacoes.filter(lida=False).count()
                if request.user.is_authenticated else 0
            ),
        })
        return context




from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_GET
from django.contrib.auth.decorators import login_required

@require_GET
def get_galeria_variacao(request, variacao_id):
    """
    API endpoint para obter as imagens de uma variação específica.
    Retorna JSON com todas as imagens da variação.
    """
    try:
        variacao = get_object_or_404(ProdutoVariacao, id=variacao_id)
        
        # Prepara os dados das imagens
        imagens = variacao.imagens_variacao.all().order_by('ordem')
        
        imagens_data = []
        for imagem in imagens:
            imagens_data.append({
                'url': request.build_absolute_uri(imagem.imagem.url),
                'legenda': imagem.legenda or '',
                'is_principal': imagem.is_principal,
                'ordem': imagem.ordem
            })
        
        # Verifica se tem imagem legada (campo imagem antigo)
        imagem_legada = None
        if variacao.imagem:
            imagem_legada = {
                'url': request.build_absolute_uri(variacao.imagem.url),
                'legenda': 'Imagem principal',
                'is_principal': True,
                'ordem': 0
            }
            # Se não houver imagens na galeria, adiciona a imagem legada
            if not imagens_data:
                imagens_data.append(imagem_legada)
        
        data = {
            'success': True,
            'variacao_id': variacao.id,
            'variacao_nome': str(variacao),
            'imagens': imagens_data,
            'tem_imagens': bool(imagens_data),
            'total_imagens': len(imagens_data)
        }
        
        return JsonResponse(data)
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e),
            'imagens': []
        }, status=500)