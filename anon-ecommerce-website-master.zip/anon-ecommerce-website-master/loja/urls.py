"""
🔥 URLs AVANÇADAS PARA E-COMMERCE COM GAMIFICAÇÃO E FIDELIDADE
Rotas organizadas por funcionalidade e seção
"""
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
    # PÁGINAS PRINCIPAIS
    path("", views.HomeView, name="home"),
    path("sobre/", views.SobreView.as_view(), name="sobre"),
    path("contato/", views.ContatoView.as_view(), name="contato"),
    path("newsletter/", views.newsletter_inscrever, name="newsletter_inscrever"),
    path("marcas/", views.MarcasView, name="marcas"),

    # AUTENTICAÇÃO
    path("conta/entrar/", views.LoginView.as_view(), name="login"),
    path("conta/sair/", views.LogoutView.as_view(), name="logout"),
    path("conta/registrar/", views.RegistroView.as_view(), name="registro"),

    # CATÁLOGO E PRODUTOS
    path("catalogo/", views.CatalogoView.as_view(), name="catalogo"),
    path("categoria/<slug:slug>/", views.CategoriaDetailView.as_view(), name="categoria"),
    path("marca/<slug:slug>/", views.MarcaDetailView.as_view(), name="marca"),
    path("produto/<slug:slug>/", views.ProdutoDetailView.as_view(), name="produto_detalhe"),
    path("autocomplete/", views.AutocompleteProdutosView.as_view(), name="autocomplete"),
    path("api/frete/", views.FreteCorreiosView.as_view(), name="frete_correios"),

    # CARRINHO
    path("carrinho/", views.CarrinhoView.as_view(), name="carrinho"),
    path("carrinho/adicionar/", views.AdicionarAoCarrinhoView.as_view(), name="adicionar_carrinho"),
    path("carrinho/atualizar/", views.AtualizarCarrinhoView.as_view(), name="atualizar_carrinho"),

    # CHECKOUT E PAGAMENTO
    path("checkout/", views.CheckoutView.as_view(), name="checkout"),
    path("pagamento/<str:numero_pedido>/", views.PagamentoView.as_view(), name="pagamento"),
    path("pagamento/sucesso/", views.PagamentoSucessoView.as_view(), name="pagamento_sucesso"),
    path("pagamento/falha/", views.PagamentoFalhaView.as_view(), name="pagamento_falha"),

    # ÁREA DO CLIENTE - PERFIL / DADOS
    path("minha-conta/", views.PerfilView.as_view(), name="perfil"),
    path("minha-conta/alterar-senha/", views.AlterarSenhaView.as_view(), name="alterar_senha"),
    path("conta/esqueci-senha/", views.EsqueciSenhaView.as_view(), name="esqueci_senha"),
    path(
        "conta/reset/<uidb64>/<token>/",
        auth_views.PasswordResetConfirmView.as_view(template_name="registration/password_reset_confirm.html"),
        name="password_reset_confirm",
    ),
    path(
        "conta/reset/done/",
        auth_views.PasswordResetCompleteView.as_view(template_name="registration/password_reset_complete.html"),
        name="password_reset_complete",
    ),
    path(
        "conta/reset/enviado/",
        auth_views.PasswordResetDoneView.as_view(template_name="registration/password_reset_done.html"),
        name="password_reset_done",
    ),
    path("minha-conta/exportar-dados/", views.ExportarDadosView.as_view(), name="exportar_dados"),
    path("minha-conta/saque-cashback/", views.SaqueCashbackView.as_view(), name="saque_cashback"),
    path("minha-conta/registros-cashback/", views.RegistrosCashbackView.as_view(), name="registros_cashback"),
    path("minha-conta/registros-pontos/", views.RegistrosPontosView.as_view(), name="registros_pontos"),

    # ÁREA DO CLIENTE - PEDIDOS
    path("minha-conta/pedidos/", views.MeusPedidosView.as_view(), name="meus_pedidos"),
    path("minha-conta/pedidos/<int:pk>/", views.DetalhePedidoView.as_view(), name="detalhe_pedido"),
    path("minha-conta/pedidos/<int:pedido_id>/cancelar/", views.cancelar_pedido, name="cancelar_pedido"),

    # ÁREA DO CLIENTE - ENDEREÇOS
    path("minha-conta/enderecos/", views.EnderecosView.as_view(), name="enderecos"),

    # ÁREA DO CLIENTE - WISHLIST
    path("minha-conta/wishlist/", views.WishlistView.as_view(), name="wishlist"),
    path("minha-conta/wishlist/adicionar/", views.AdicionarWishlistView.as_view(), name="adicionar_wishlist"),
    path("minha-conta/wishlist/remover/", views.RemoverWishlistView.as_view(), name="remover_wishlist"),
    path("minha-conta/wishlist/limpar/", views.LimparWishlistView.as_view(), name="limpar_wishlist"),

    # ÁREA DO CLIENTE - NOTIFICAÇÕES
    path("minha-conta/notificacoes/", views.NotificacoesView.as_view(), name="notificacoes"),
    path(
        "minha-conta/notificacoes/<int:notificacao_id>/marcar-lida/",
        views.MarcarNotificacaoLidaView.as_view(),
        name="marcar_notificacao_lida",
    ),

    # AVALIAÇÕES
    path("avaliacao/criar/", views.CriarAvaliacaoView.as_view(), name="criar_avaliacao"),

    # APIs E UTILITÁRIOS
    path("calcular-frete/", views.calcular_frete, name="calcular_frete"),
    path("buscar-cep/", views.buscar_cep, name="buscar_cep"),
    path("api/filtrar-produtos/", views.filtrar_produtos, name="filtrar_produtos"),
    path('api/variacao/<int:variacao_id>/galeria/', views.get_galeria_variacao, name='get_galeria_variacao'),

    # WEBHOOKS
    path("webhook/asaas/", views.webhook_asaas, name="webhook_asaas"),

    # IA E RECOMENDAÇÕES
    path("chat/agent/", views.chat_agent_view, name="chat_agent"),
    path("api/recomendacao-ia/", views.RecomendacaoIAView.as_view(), name="api_recomendacao_ia"),

    # BADGES (PUBLICO)
    path("badges/", views.BadgesListView.as_view(), name="badges"),
    path("badges/<slug:slug>/", views.BadgeDetailView.as_view(), name="badge_detalhe"),

    # AFILIADOS
    path("afiliados/painel/", views.listar_meus_cupons, name="listar_meus_cupons"),
    path("afiliados/criar/", views.criar_cupom_afiliado, name="criar_cupom_afiliado"),
    path("afiliados/desativar/<int:cupom_id>/", views.desativar_cupom, name="desativar_cupom"),
    path("afiliado/", views.AfiliadoDashboardView.as_view(), name="afiliado_dashboard"),


    path("termos/", views.TermosView.as_view(), name="termos"),
    path("privacidade/", views.PrivacidadeView.as_view(), name="privacidade"),



]


# SERVE ARQUIVOS ESTÁTICOS E MEDIA EM DEV
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
