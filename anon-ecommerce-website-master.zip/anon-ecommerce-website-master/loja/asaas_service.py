import requests
import json
import re
from django.conf import settings
from django.utils import timezone
from decimal import Decimal

# CONFIGURAÇÃO
# Tenta pegar do settings.py, se não existir, usa a hardcoded (cuidado em produção!)
ASAAS_API_KEY = getattr(settings, 'ASAAS_API_KEY', "$aact_prod_000MzkwODA2MWY2OGM3MWRlMDU2NWM3MzJlNzZmNGZhZGY6Ojg5ODVhMzkwLTk2Y2YtNDI2YS1hZjVjLWQxZTQ1NzMyMWRiNDo6JGFhY2hfMTBhNzU2NjMtZDFkMS00MGM3LTg5ZTQtOTRlZjY3M2VmYzIz")
BASE_URL = getattr(settings, 'ASAAS_API_URL', 'https://api.asaas.com/v3')

# --- CONSTANTES ---
MIN_PARCELA_CLIENTE = 5.00  # Valor mínimo aceito por parcela
MAX_PARCELAS = 21           # Máximo de parcelas aceitas

class AsaasService:
    
    def __init__(self):
        self.base_url = BASE_URL
        self.api_key = ASAAS_API_KEY
        self.headers = {
            'accept': 'application/json',
            'content-type': 'application/json',
            'access_token': self.api_key
        }
        
        # 🔥 TAXAS ASAAS (CUSTO DO LOJISTA)
        self.taxas_cartao = {
            1: {'percentual': 0.0199, 'fixa': 0.49},     # 1.99% + R$ 0,49 (à vista)
            '2_6': {'percentual': 0.0249, 'fixa': 0.49}, # 2.49% + R$ 0,49 (2-6x)
            '7_12': {'percentual': 0.0299, 'fixa': 0.49}, # 2.99% + R$ 0,49 (7-12x)
            '13_21': {'percentual': 0.0329, 'fixa': 0.49} # 3.29% + R$ 0,49 (13-21x)
        }

        # 🔥 JUROS DO CLIENTE (Mensal - PAGO PELO CLIENTE)
        self.juros_cliente = {
            '1_9': Decimal('0.0000'),    # 0% de juros (1 a 9x)
            '10_21': Decimal('0.0199')   # 1.99% a.m (10x em diante)
        }
        print("✅ Serviço Asaas inicializado.")

    def _make_request(self, method, endpoint, data=None):
        """Método genérico para fazer requisições à API Asaas"""
        url = f'{self.base_url}{endpoint}'
        
        # print(f"🔧 Asaas API Request: {method} {url}") # Descomente para logar tudo
        
        try:
            if method.upper() == 'POST':
                response = requests.post(url, json=data, headers=self.headers, timeout=30)
            elif method.upper() == 'GET':
                response = requests.get(url, headers=self.headers, timeout=30)
            elif method.upper() == 'DELETE':
                 response = requests.delete(url, headers=self.headers, timeout=30)
            elif method.upper() == 'PUT':
                 response = requests.put(url, json=data, headers=self.headers, timeout=30)
            else:
                response = requests.request(method, url, json=data, headers=self.headers, timeout=30)
            
            # Tentar parsear JSON
            try:
                response_data = response.json()
            except json.JSONDecodeError:
                if response.status_code == 200:
                    return {} 
                raise Exception(f"Resposta inválida da API (Não JSON): {response.text[:200]}")
            
            # Verificar erros HTTP lógicos do Asaas
            if response.status_code >= 400:
                error_message = self._parse_error(response_data, response.status_code)
                print(f"❌ Erro API Asaas: {error_message}")
                raise Exception(error_message)
            
            return response_data
            
        except requests.exceptions.Timeout:
            raise Exception("Timeout na conexão com a API Asaas")
        except requests.exceptions.ConnectionError:
            raise Exception("Erro de conexão com a API Asaas")
        except requests.exceptions.RequestException as e:
            raise Exception(f"Erro na requisição para API Asaas: {str(e)}")

    def _parse_error(self, response_data, status_code):
        """Parseia mensagens de erro da API Asaas"""
        if isinstance(response_data, dict):
            if 'errors' in response_data and response_data['errors']:
                errors = response_data['errors']
                if isinstance(errors, list) and errors:
                    error_desc = errors[0].get('description', 'Erro desconhecido')
                    error_code = errors[0].get('code', 'N/A')
                    return f"Asaas ({status_code}): {error_desc} (Code: {error_code})"
            
            if 'message' in response_data:
                return f"Asaas ({status_code}): {response_data['message']}"
        
        return f"Erro na API Asaas (Status {status_code})"

    def _validar_e_formatar_documento(self, documento):
        """Valida e formata CPF/CNPJ (apenas números)"""
        if not documento: return None
        doc_limpo = re.sub(r'[^0-9]', '', str(documento))
        
        # Verifica tamanhos e sequências repetidas
        if len(doc_limpo) not in [11, 14]: return None
        if len(doc_limpo) == 11 and doc_limpo == doc_limpo[0]*11: return None
        if len(doc_limpo) == 14 and doc_limpo == doc_limpo[0]*14: return None
        
        return doc_limpo

    def _format_phone(self, phone):
        """Formata telefone para 55 + DDD + Numero"""
        if not phone: return None
        cleaned = ''.join(filter(str.isdigit, str(phone)))
        if not cleaned.startswith('55'):
            cleaned = f"55{cleaned}"
        return cleaned if len(cleaned) in [12, 13] else None

    def _detectar_tipo_pix(self, chave):
        """Identifica tipo de chave Pix (CPF, CNPJ, EMAIL, PHONE, EVP)."""
        if not chave:
            return "EVP"
        chave_str = str(chave).strip()
        if re.fullmatch(r"\d{11}", chave_str):
            return "CPF"
        if re.fullmatch(r"\d{14}", chave_str):
            return "CNPJ"
        if "@" in chave_str:
            return "EMAIL"
        if re.fullmatch(r"\+?\d{10,14}", chave_str):
            return "PHONE"
        return "EVP"

    # =========================================================================
    # LÓGICA DE CLIENTE (COM AUTO-ATUALIZAÇÃO DE CPF)
    # =========================================================================

    def criar_cliente(self, usuario):
        """Cria ou atualiza um cliente no Asaas"""
        print(f"👤 Processando cliente Asaas para: {usuario.email}")
        
        # 1. Prepara os dados ideais baseados no banco de dados local
        documento_valido = self._obter_documento_valido(usuario)
        telefone_formatado = None
        if hasattr(usuario, 'telefone') and usuario.telefone:
            telefone_formatado = self._format_phone(usuario.telefone)

        # Dados base
        data_ideal = {
            "name": usuario.get_full_name() or usuario.email.split('@')[0],
            "email": usuario.email,
            "cpfCnpj": documento_valido,
            "mobilePhone": telefone_formatado,
        }

        # Adiciona endereço se disponível
        if hasattr(usuario, 'perfil') and usuario.perfil:
            p = usuario.perfil
            if p.cep and p.endereco and p.numero:
                data_ideal.update({
                    "postalCode": re.sub(r'\D', '', p.cep),
                    "address": p.endereco,
                    "addressNumber": p.numero,
                    "complement": p.complemento or "",
                    "province": p.bairro or "",
                    "city": p.cidade,
                    "state": p.estado,
                })

        # 2. Verifica se o cliente já existe no Asaas
        existing_customer = self._buscar_cliente_por_email(usuario.email)
        
        if existing_customer:
            cliente_id = existing_customer['id']
            print(f"✅ Cliente já existe no Asaas: {cliente_id}")
            
            # --- LÓGICA DE ATUALIZAÇÃO AUTOMÁTICA ---
            # Verifica se o cadastro no Asaas está incompleto (sem CPF) ou desatualizado
            cpf_remoto = existing_customer.get('cpfCnpj')
            precisa_atualizar = False

            # Se temos um CPF local válido e (o remoto é nulo OU diferente)
            if documento_valido and (not cpf_remoto or cpf_remoto != documento_valido):
                print(f"🔄 CPF divergente ou ausente no Asaas. Atualizando cadastro...")
                precisa_atualizar = True
            
            # Se quiser verificar endereço também, adicione lógica aqui
            
            if precisa_atualizar:
                try:
                    # Remove campos que não devem ser enviados na atualização se vazios
                    update_payload = {k: v for k, v in data_ideal.items() if v is not None}
                    self.atualizar_cliente(cliente_id, update_payload)
                    print(f"✅ Cadastro do cliente {cliente_id} atualizado com sucesso.")
                    existing_customer.update(update_payload) # Atualiza objeto local
                except Exception as e:
                    print(f"⚠️ Erro ao tentar atualizar cadastro existente: {e}")
            
            return existing_customer

        # 3. Se não existe, cria um novo
        print("🆕 Criando novo cliente no Asaas...")
        try:
            # Remove chaves com valor None para não dar erro
            payload_final = {k: v for k, v in data_ideal.items() if v is not None}
            return self._make_request('POST', '/customers', data=payload_final)
        except Exception as e:
            print(f"❌ Erro fatal ao criar cliente: {e}")
            # Tentativa de fallback: cria só com nome e email
            print("🔄 Tentando criar com dados mínimos (Nome + Email)...")
            return self._make_request('POST', '/customers', data={
                "name": data_ideal['name'], 
                "email": data_ideal['email']
            })

    def atualizar_cliente(self, customer_id, update_data):
        """Atualiza os dados de um cliente no Asaas"""
        endpoint = f'/customers/{customer_id}'
        return self._make_request('POST', endpoint, data=update_data)

    def _buscar_cliente_por_email(self, email):
        """Busca cliente existente no Asaas por email"""
        endpoint = f'/customers?email={email}'
        try:
            response = self._make_request('GET', endpoint)
            if response and 'data' in response and len(response['data']) > 0:
                return response['data'][0]
        except:
            pass
        return None

    def _obter_documento_valido(self, usuario):
        """Busca CPF/CNPJ no User, Perfil ou Profile"""
        candidates = []
        
        # 1. Tenta CPF injetado temporariamente na View
        if hasattr(usuario, 'cpf_temporario_checkout'):
            candidates.append(usuario.cpf_temporario_checkout)

        # 2. Tenta no modelo User
        if hasattr(usuario, 'cpf'): candidates.append(usuario.cpf)
        
        # 3. Tenta no Perfil
        if hasattr(usuario, 'perfil') and usuario.perfil:
            if hasattr(usuario.perfil, 'cpf'): candidates.append(usuario.perfil.cpf)
            if hasattr(usuario.perfil, 'cpf_cnpj'): candidates.append(usuario.perfil.cpf_cnpj)

        for doc in candidates:
            valido = self._validar_e_formatar_documento(doc)
            if valido: return valido
            
        return None

    # =========================================================================
    # PAGAMENTOS E CALCULOS FINANCEIROS
    # =========================================================================

    def _get_billing_type(self, metodo_pagamento):
        mapping = {
            'pix': 'PIX',
            'boleto': 'BOLETO',
            'cartao_credito': 'CREDIT_CARD',
            'cartao_debito': 'CREDIT_CARD',
        }
        return mapping.get(metodo_pagamento, 'UNDEFINED')
        
    def _get_juros_cliente(self, numero_parcelas):
        if 1 <= numero_parcelas <= 9:
            return self.juros_cliente['1_9']
        elif 10 <= numero_parcelas <= MAX_PARCELAS:
            return self.juros_cliente['10_21']
        return Decimal('0.0000')

    def _calcular_valor_parcela_cliente(self, valor_bruto, numero_parcelas):
        """Calcula PMT (Parcela) usando Tabela Price se houver juros"""
        valor_bruto_decimal = Decimal(str(valor_bruto))
        taxa_juros_mensal = self._get_juros_cliente(numero_parcelas)

        if taxa_juros_mensal > Decimal('0.0000'):
            i = taxa_juros_mensal
            n = numero_parcelas
            try:
                # PMT = PV * [i / (1 - (1 + i)^-n)]
                fator = i / (Decimal('1') - (Decimal('1') + i) ** (-n))
                valor_parcela = valor_bruto_decimal * fator
            except:
                valor_parcela = valor_bruto_decimal / Decimal(n)
            
            return float(valor_parcela.quantize(Decimal('0.01')))
        else:
            return round(valor_bruto / numero_parcelas, 2)

    def _calcular_valor_liquido(self, valor_total_pago, numero_parcelas):
        """Calcula quanto o lojista recebe (descontando taxas Asaas)"""
        # Define taxa baseada no número de parcelas
        if numero_parcelas == 1: taxa = self.taxas_cartao[1]
        elif 2 <= numero_parcelas <= 6: taxa = self.taxas_cartao['2_6']
        elif 7 <= numero_parcelas <= 12: taxa = self.taxas_cartao['7_12']
        else: taxa = self.taxas_cartao['13_21']

        valor_bruto = Decimal(str(valor_total_pago))
        valor_taxa_pct = valor_bruto * Decimal(str(taxa['percentual']))
        valor_taxa_fixa = Decimal(str(taxa['fixa']))
        
        valor_liquido = valor_bruto - valor_taxa_pct - valor_taxa_fixa
        
        return {
            'valor_liquido': round(float(valor_liquido), 2),
            'taxa_percentual': taxa['percentual'] * 100,
            'valor_taxa_fixa': float(valor_taxa_fixa),
            'valor_parcela_lojista': round(float(valor_liquido / Decimal(numero_parcelas)), 2)
        }

    def criar_pagamento(self, pedido, customer_id, metodo_pagamento, **kwargs):
        """Cria cobrança Pix, Boleto ou Cartão À Vista"""
        
        # Se for cartão parcelado, desvia para método específico
        num_parcelas = kwargs.get('numero_parcelas', 1)
        if metodo_pagamento == 'cartao_credito' and num_parcelas > 1:
            return self.criar_pagamento_cartao_credito_parcelado(pedido, customer_id, num_parcelas)
        
        billing_type = self._get_billing_type(metodo_pagamento)
        due_date = (timezone.now() + timezone.timedelta(days=3)).strftime('%Y-%m-%d')
        
        data = {
            "customer": customer_id,
            "billingType": billing_type,
            "value": float(pedido.total),
            "dueDate": due_date,
            "description": f"Pedido #{pedido.numero_pedido}",
            "externalReference": str(pedido.numero_pedido),
        }
        
        if metodo_pagamento == 'pix':
            data["pix"] = {"expirationSeconds": 86400} # 24h
        elif metodo_pagamento == 'boleto':
            data["postalService"] = False
        
        print(f"📦 Criando pagamento {metodo_pagamento} para {customer_id}...")
        return self._make_request('POST', '/payments', data=data)

    def criar_pagamento_cartao_credito_parcelado(self, pedido, customer_id, numero_parcelas):
        """Cria cobrança de Cartão Parcelada"""
        due_date = (timezone.now() + timezone.timedelta(days=3)).strftime('%Y-%m-%d')
        
        # 1. Calcula quanto o cliente vai pagar por mês
        valor_parcela_cliente = self._calcular_valor_parcela_cliente(float(pedido.total), numero_parcelas)
        
        # 2. Calcula valor total final (Original + Juros Cliente)
        valor_total_final = round(valor_parcela_cliente * numero_parcelas, 2)
        
        data = {
            "customer": customer_id,
            "billingType": "CREDIT_CARD",
            "value": valor_total_final,
            "dueDate": due_date,
            "description": f"Pedido #{pedido.numero_pedido} - {numero_parcelas}x",
            "externalReference": str(pedido.numero_pedido),
            "installmentCount": numero_parcelas,
            "installmentValue": valor_parcela_cliente,
        }
        
        print(f"💳 Criando pagamento Parcelado ({numero_parcelas}x) para {customer_id}...")
        return self._make_request('POST', '/payments', data=data)

    def obter_parcelas_disponiveis(self, valor_total):
        """Gera simulação de parcelamento para exibir no frontend"""
        parcelas = []
        for n in range(1, MAX_PARCELAS + 1):
            val_parc = self._calcular_valor_parcela_cliente(valor_total, n)
            val_total_cliente = round(val_parc * n, 2)
            
            # Cálculo reverso para mostrar quanto o lojista recebe
            liq = self._calcular_valor_liquido(val_total_cliente, n)
            
            if val_parc >= MIN_PARCELA_CLIENTE:
                taxa_juros = self._get_juros_cliente(n)
                tem_juros = taxa_juros > 0
                
                parcelas.append({
                    'numero': n,
                    'valor_parcela_cliente': val_parc,
                    'valor_total_cliente_pago': val_total_cliente,
                    'sem_juros': not tem_juros,
                    'texto': f"{n}x de R$ {val_parc:.2f}" + (" (Sem Juros)" if not tem_juros else "")
                })
        return parcelas

    # =========================================================================
    # MÉTODOS AUXILIARES DE LEITURA E WEBHOOKS
    # =========================================================================

    def consultar_pagamento(self, payment_id):
        return self._make_request('GET', f'/payments/{payment_id}')

    def cancelar_pagamento(self, payment_id):
        return self._make_request('DELETE', f'/payments/{payment_id}')

    def obter_url_checkout(self, payment_id):
        try:
            info = self.consultar_pagamento(payment_id)
            return info.get('invoiceUrl') or f"https://www.asaas.com/pay/{payment_id}"
        except:
            return f"https://www.asaas.com/pay/{payment_id}"

    def testar_conexao(self):
        print("🌐 Testando conexão Asaas...")
        try:
            self._make_request('GET', '/customers?limit=1')
            print("✅ Conexão OK")
            return True
        except Exception as e:
            print(f"❌ Falha Conexão: {e}")
            return False

    # =========================================================================
    # TRANSFERÊNCIAS / SAQUE DE CASHBACK VIA PIX
    # =========================================================================
    def criar_transferencia_pix_cashback(self, usuario, valor, chave_pix, descricao="Saque de cashback"):
        """
        Cria uma transferência PIX para sacar cashback do usuário.
        - valor: Decimal/float > 0
        - chave_pix: chave informada pelo usuário (cpf/cnpj/email/telefone/evp)
        """
        if not chave_pix:
            raise Exception("Chave PIX não informada.")
        valor_dec = Decimal(str(valor))
        if valor_dec <= 0:
            raise Exception("Valor de saque inválido.")

        # Opcional: valida saldo local antes de pedir ao Asaas
        if hasattr(usuario, "saldo_cashback") and valor_dec > usuario.saldo_cashback:
            raise Exception("Saldo de cashback insuficiente.")

        tipo = self._detectar_tipo_pix(chave_pix)
        # Asaas espera a chave em pixAddressKey (string). Alguns ambientes aceitam pixAddressKeyType.
        payload = {
            "value": float(valor_dec),
            "description": descricao,
            "transferType": "PIX",
            "pixAddressKey": str(chave_pix).strip(),
        }
        # Envia o tipo quando disponível (não obrigatório em todas as contas).
        if tipo:
            payload["pixAddressKeyType"] = tipo
        return self._make_request("POST", "/transfers", data=payload)

def get_asaas_service():
    """Factory simples"""
    return AsaasService()
