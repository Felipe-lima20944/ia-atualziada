"""
Signals para notificações e emails transacionais.
Organizado por categorias: Pedidos, Usuários, Pontos/Cashback, Carrinho.
"""
import logging
from typing import Optional, Tuple

from django.conf import settings
from django.core.mail import send_mail
from django.db import transaction
from django.contrib.auth import get_user_model
from django.contrib.auth.signals import user_logged_in
from django.db.models.signals import post_save, pre_save, post_delete
from django.dispatch import receiver
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.utils import timezone

from .models import (
    Pedido, 
    ItemCarrinho, 
    AbandonoCarrinho, 
    RegistroPontos, 
    RegistroCashback, 
    Notificacao
)

# ============================================================================
# CONFIGURAÇÃO E LOGGER
# ============================================================================

logger = logging.getLogger(__name__)
Usuario = get_user_model()

# Configurações de email
ENABLE_EMAILS = getattr(settings, "ENABLE_EMAIL_NOTIFICATIONS", True)
EMAIL_FAIL_SILENTLY = getattr(settings, "EMAIL_FAIL_SILENTLY", False)
DEFAULT_FROM_EMAIL = getattr(settings, "DEFAULT_FROM_EMAIL", None) or getattr(settings, "EMAIL_HOST_USER", None)
SITE_URL = getattr(settings, "SITE_URL", "").rstrip('/')


# ============================================================================
# FUNÇÕES AUXILIARES - EMAIL
# ============================================================================

def _should_send_email() -> bool:
    """Verifica se emails devem ser enviados."""
    return ENABLE_EMAILS and bool(getattr(settings, "EMAIL_HOST", None))


def _enviar_email(
    destinatario: str,
    assunto: str,
    mensagem: str,
    html: Optional[str] = None
) -> bool:
    """
    Envia email usando o backend SMTP configurado.
    
    Args:
        destinatario: Email do destinatário
        assunto: Assunto do email
        mensagem: Mensagem em texto puro
        html: Mensagem em HTML (opcional)
    
    Returns:
        True se enviado com sucesso, False caso contrário
    """
    if not _should_send_email():
        logger.debug(f"Envio de email desabilitado; assunto={assunto}")
        return False
    
    if not destinatario:
        logger.warning(f"Tentativa de envio sem destinatário; assunto={assunto}")
        return False
    
    try:
        send_mail(
            subject=assunto,
            message=mensagem,
            from_email=DEFAULT_FROM_EMAIL,
            recipient_list=[destinatario],
            fail_silently=EMAIL_FAIL_SILENTLY,
            html_message=html,
        )
        logger.info(f"Email enviado para {destinatario}: {assunto}")
        return True
    except Exception as e:
        logger.exception(f"Erro ao enviar email para {destinatario}: {e}")
        return False


def _render_email(template_name: str, context: dict) -> Tuple[str, str]:
    """
    Renderiza template de email em HTML e texto puro.
    
    Args:
        template_name: Nome do template
        context: Contexto para renderização
    
    Returns:
        Tupla (html, texto)
    """
    try:
        html = render_to_string(template_name, context)
        texto = strip_tags(html)
        return html, texto
    except Exception as e:
        logger.exception(f"Erro ao renderizar template {template_name}: {e}")
        return "", ""


def _enfileirar_envio_email(destinatario: str, assunto: str, mensagem: str, html: Optional[str] = None):
    """Enfileira envio de email para após commit da transação."""
    def _send():
        try:
            _enviar_email(destinatario, assunto, mensagem, html)
        except Exception as e:
            logger.exception(f"Falha ao enviar email enfileirado: {e}")
    
    transaction.on_commit(_send)


# ============================================================================
# FUNÇÕES AUXILIARES - NOTIFICAÇÃO
# ============================================================================

def _criar_notificacao(
    usuario,
    titulo: str,
    mensagem: str,
    tipo: str = "sistema",
    link: str = ""
) -> Optional[Notificacao]:
    """
    Cria notificação in-app de forma segura.
    
    Args:
        usuario: Instância do usuário
        titulo: Título da notificação (máx 200 chars)
        mensagem: Mensagem completa
        tipo: Tipo da notificação (sistema, pedido, pontos, pagamento)
        link: Link relacionado (opcional)
    
    Returns:
        Notificação criada ou None em caso de erro
    """
    try:
        if not usuario or not getattr(usuario, "id", None):
            logger.warning("Tentativa de criar notificação sem usuário válido")
            return None
        
        notificacao = Notificacao.objects.create(
            usuario=usuario,
            titulo=titulo[:200],  # Garantir limite
            mensagem=mensagem,
            tipo=tipo,
            link=link or "",
        )
        logger.debug(f"Notificação criada para {usuario.email}: {titulo}")
        return notificacao
        
    except Exception as e:
        logger.exception(f"Falha ao criar notificação para {usuario}: {e}")
        return None


# ============================================================================
# MONTADORES DE EMAIL - PEDIDOS
# ============================================================================

def _montar_email_pedido_recebido(pedido: Pedido) -> Tuple[str, str, str]:
    """Monta email de pedido recebido."""
    assunto = f"✅ Pedido #{pedido.numero_pedido} recebido com sucesso"
    context = {
        "pedido": pedido,
        "site_url": SITE_URL,
        "acao_texto": "Ver detalhes do pedido",
        "acao_url": f"{SITE_URL}/minha-conta/pedidos/{pedido.id}/",
        "titulo": "Pedido recebido com sucesso!",
        "descricao": f"Recebemos seu pedido #{pedido.numero_pedido} e já estamos processando. Você receberá atualizações sobre cada etapa.",
    }
    html, texto = _render_email("emails/pedido_recebido.html", context)
    return assunto, texto, html


def _montar_email_status_atualizado(pedido: Pedido, status_antigo: str) -> Tuple[str, str, str]:
    """Monta email de atualização de status do pedido."""
    assunto = f"📦 Pedido #{pedido.numero_pedido} - {pedido.get_status_display()}"
    context = {
        "pedido": pedido,
        "status_antigo": status_antigo,
        "site_url": SITE_URL,
        "acao_texto": "Acompanhar pedido",
        "acao_url": f"{SITE_URL}/minha-conta/pedidos/{pedido.id}/",
        "titulo": f"Status atualizado: {pedido.get_status_display()}",
        "descricao": f"Seu pedido #{pedido.numero_pedido} mudou de status. Confira os detalhes no painel.",
    }
    html, texto = _render_email("emails/pedido_status.html", context)
    return assunto, texto, html


def _montar_email_pedido_entregue(pedido: Pedido) -> Tuple[str, str, str]:
    """Monta email solicitando avaliação após entrega."""
    assunto = f"✅ Pedido #{pedido.numero_pedido} entregue - Avalie sua experiência!"
    context = {
        "pedido": pedido,
        "site_url": SITE_URL,
        "acao_texto": "Avaliar pedido",
        "acao_url": f"{SITE_URL}/minha-conta/pedidos/{pedido.id}/",
        "titulo": "Seu pedido foi entregue!",
        "descricao": f"Que ótimo! Seu pedido #{pedido.numero_pedido} foi entregue com sucesso. Conte-nos como foi sua experiência avaliando os produtos.",
    }
    html, texto = _render_email("emails/pedido_entregue.html", context)
    return assunto, texto, html


# ============================================================================
# MONTADORES DE EMAIL - USUÁRIO
# ============================================================================

def _montar_email_boas_vindas(usuario) -> Tuple[str, str, str]:
    """Monta email de boas-vindas."""
    assunto = "🎉 Bem-vindo(a) à The Shape Brasil!"
    context = {
        "usuario": usuario,
        "site_url": SITE_URL,
        "acao_texto": "Começar a comprar",
        "acao_url": f"{SITE_URL}/catalogo/",
        "titulo": "Cadastro confirmado com sucesso!",
        "descricao": "Sua conta foi criada. Explore nossos produtos e aproveite benefícios exclusivos.",
    }
    html, texto = _render_email("emails/boas_vindas.html", context)
    return assunto, texto, html


def _montar_email_login(usuario) -> Tuple[str, str, str]:
    """Monta email de alerta de login."""
    assunto = "🔐 Novo acesso detectado em sua conta"
    context = {
        "usuario": usuario,
        "site_url": SITE_URL,
        "acao_texto": "Gerenciar segurança",
        "acao_url": f"{SITE_URL}/minha-conta/alterar-senha/",
        "titulo": "Novo login detectado",
        "descricao": f"Detectamos um novo acesso em {timezone.now().strftime('%d/%m/%Y às %H:%M')}. Se não foi você, altere sua senha imediatamente.",
    }
    html, texto = _render_email("emails/login_alerta.html", context)
    return assunto, texto, html


# ============================================================================
# MONTADORES DE EMAIL - PONTOS E CASHBACK
# ============================================================================

def _montar_email_pontos(registro: RegistroPontos) -> Tuple[str, str, str]:
    """Monta email de movimentação de pontos."""
    usuario = registro.usuario
    sinal = "+" if registro.tipo == "adicionar" else "-"
    emoji = "⭐" if registro.tipo == "adicionar" else "🔄"
    
    assunto = f"{emoji} Movimentação de pontos - {registro.get_tipo_display()}"
    contexto = {
        "titulo": "Movimentação de pontos",
        "descricao": registro.motivo or "Atualização em sua conta de pontos.",
        "quantidade": f"{sinal}{registro.quantidade} pts",
        "pontos_disponiveis": usuario.pontos_disponiveis,
        "site_url": SITE_URL,
        "acao_texto": "Ver histórico de pontos",
        "acao_url": f"{SITE_URL}/minha-conta/registros-pontos/",
    }
    html, texto = _render_email("emails/movimentacao_pontos.html", contexto)
    return assunto, texto, html


def _montar_email_cashback(registro: RegistroCashback) -> Tuple[str, str, str]:
    """Monta email de movimentação de cashback."""
    usuario = registro.usuario
    sinal = "+" if registro.tipo == "credito" else "-"
    emoji = "💰" if registro.tipo == "credito" else "💸"
    
    assunto = f"{emoji} Movimentação de cashback - {registro.get_tipo_display()}"
    contexto = {
        "titulo": "Movimentação de cashback",
        "descricao": registro.motivo or "Atualização em sua carteira de cashback.",
        "valor": f"{sinal}R$ {registro.valor:.2f}",
        "saldo": f"R$ {usuario.saldo_cashback:.2f}",
        "site_url": SITE_URL,
        "acao_texto": "Ver histórico de cashback",
        "acao_url": f"{SITE_URL}/minha-conta/registros-cashback/",
    }
    html, texto = _render_email("emails/movimentacao_cashback.html", contexto)
    return assunto, texto, html


# ============================================================================
# SIGNALS - PEDIDOS
# ============================================================================

@receiver(pre_save, sender=Pedido)
def cache_status_anterior_pedido(sender, instance, **kwargs):
    """
    Guarda o status antigo antes de salvar para detectar mudanças.
    Evita query adicional no post_save.
    """
    if instance.pk:
        try:
            antigo = sender.objects.filter(pk=instance.pk).values_list("status", flat=True).first()
            instance._status_anterior = antigo
        except Exception as e:
            logger.warning(f"Falha ao capturar status anterior do pedido {instance.pk}: {e}")
            instance._status_anterior = None


@receiver(post_save, sender=Pedido)
def notificar_pedido(sender, instance, created, **kwargs):
    """
    Envia emails e notificações no fluxo de pedidos.
    
    Eventos tratados:
    - Pedido criado: Email de confirmação
    - Status alterado: Email de atualização
    - Pedido entregue: Email solicitando avaliação
    """
    # Validação inicial
    usuario = getattr(instance, "usuario", None)
    if not usuario:
        logger.warning(f"Pedido {instance.pk} sem usuário associado")
        return
    
    email_destino = getattr(usuario, "email", None)
    if not email_destino:
        logger.info(f"Pedido {instance.pk} - usuário sem email configurado")
        return

    # Pedido criado
    if created:
        assunto, mensagem, html = _montar_email_pedido_recebido(instance)
        _enfileirar_envio_email(email_destino, assunto, mensagem, html)
        
        _criar_notificacao(
            usuario,
            titulo=f"Pedido #{instance.numero_pedido} recebido",
            mensagem="Recebemos seu pedido e já estamos processando. Acompanhe o status em tempo real.",
            tipo="pedido",
            link=f"/minha-conta/pedidos/{instance.id}/",
        )
        logger.info(f"Notificações de criação enviadas para pedido {instance.numero_pedido}")
        return

    # Status atualizado
    status_antigo = getattr(instance, "_status_anterior", None)
    if status_antigo and status_antigo != instance.status:
        # Email padrão de atualização de status
        assunto, mensagem, html = _montar_email_status_atualizado(instance, status_antigo)
        _enfileirar_envio_email(email_destino, assunto, mensagem, html)
        
        _criar_notificacao(
            usuario,
            titulo=f"Pedido #{instance.numero_pedido} - {instance.get_status_display()}",
            mensagem=f"Status atualizado de '{status_antigo}' para '{instance.get_status_display()}'.",
            tipo="pedido",
            link=f"/minha-conta/pedidos/{instance.id}/",
        )
        logger.info(f"Pedido {instance.numero_pedido}: status alterado {status_antigo} → {instance.status}")
        
        # Se o pedido foi entregue, envia email e notificação especial solicitando avaliação
        if instance.status == "entregue":
            assunto_avaliacao, mensagem_avaliacao, html_avaliacao = _montar_email_pedido_entregue(instance)
            _enfileirar_envio_email(email_destino, assunto_avaliacao, mensagem_avaliacao, html_avaliacao)
            
            _criar_notificacao(
                usuario,
                titulo=f"⭐ Avalie seu pedido #{instance.numero_pedido}",
                mensagem="Seu pedido foi entregue! Que tal avaliar os produtos e compartilhar sua experiência?",
                tipo="pedido",
                link=f"/minha-conta/pedidos/{instance.id}/",
            )
            logger.info(f"Solicitação de avaliação enviada para pedido {instance.numero_pedido}")


# ============================================================================
# SIGNALS - USUÁRIOS
# ============================================================================

@receiver(post_save, sender=Usuario)
def notificar_cadastro(sender, instance, created, **kwargs):
    """
    Envia email de boas-vindas quando novo usuário é criado.
    """
    if not created:
        return
    
    email_destino = getattr(instance, "email", None)
    if not email_destino:
        logger.warning(f"Usuário {instance.pk} criado sem email")
        return
    
    assunto, mensagem, html = _montar_email_boas_vindas(instance)
    _enfileirar_envio_email(email_destino, assunto, mensagem, html)
    
    _criar_notificacao(
        instance,
        titulo="🎉 Bem-vindo(a)!",
        mensagem="Sua conta foi criada com sucesso. Explore nossos produtos e aproveite ofertas exclusivas.",
        tipo="sistema",
        link="/catalogo/",
    )
    logger.info(f"Email de boas-vindas enviado para {email_destino}")


@receiver(user_logged_in)
def notificar_login(sender, request, user, **kwargs):
    """
    Envia alerta de segurança quando usuário faz login.
    """
    email_destino = getattr(user, "email", None)
    if not email_destino:
        return
    
    assunto, mensagem, html = _montar_email_login(user)
    _enfileirar_envio_email(email_destino, assunto, mensagem, html)
    
    _criar_notificacao(
        user,
        titulo="🔐 Novo acesso detectado",
        mensagem="Reconhece este login? Se não foi você, altere sua senha imediatamente por segurança.",
        tipo="sistema",
        link="/minha-conta/alterar-senha/",
    )
    logger.debug(f"Alerta de login enviado para {email_destino}")


# ============================================================================
# SIGNALS - PONTOS E CASHBACK
# ============================================================================

@receiver(post_save, sender=RegistroPontos)
def notificar_movimentacao_pontos(sender, instance, created, **kwargs):
    """
    Notifica usuário sobre movimentações na conta de pontos.
    """
    if not created:
        return
    
    usuario = getattr(instance, "usuario", None)
    if not usuario:
        return
    
    email_destino = getattr(usuario, "email", None)
    if not email_destino:
        return
    
    assunto, mensagem, html = _montar_email_pontos(instance)
    _enfileirar_envio_email(email_destino, assunto, mensagem, html)
    
    sinal = "+" if instance.tipo == "adicionar" else "-"
    _criar_notificacao(
        usuario,
        titulo="⭐ Movimentação de pontos",
        mensagem=f"{sinal}{instance.quantidade} pts - {instance.motivo or instance.get_tipo_display()}",
        tipo="pontos",
        link="/minha-conta/registros-pontos/",
    )
    logger.info(f"Notificação de pontos enviada para {email_destino}: {sinal}{instance.quantidade}")


@receiver(post_save, sender=RegistroCashback)
def notificar_movimentacao_cashback(sender, instance, created, **kwargs):
    """
    Notifica usuário sobre movimentações no saldo de cashback.
    """
    if not created:
        return
    
    usuario = getattr(instance, "usuario", None)
    if not usuario:
        return
    
    email_destino = getattr(usuario, "email", None)
    if not email_destino:
        return
    
    assunto, mensagem, html = _montar_email_cashback(instance)
    _enfileirar_envio_email(email_destino, assunto, mensagem, html)
    
    sinal = "+" if instance.tipo == "credito" else "-"
    _criar_notificacao(
        usuario,
        titulo="💰 Movimentação de cashback",
        mensagem=f"{sinal}R$ {instance.valor:.2f} - {instance.motivo or instance.get_tipo_display()}",
        tipo="pagamento",
        link="/minha-conta/registros-cashback/",
    )
    logger.info(f"Notificação de cashback enviada para {email_destino}: {sinal}R$ {instance.valor:.2f}")


# ============================================================================
# SIGNALS - CARRINHO (ABANDONO)
# ============================================================================

def _atualizar_abandono_carrinho(carrinho) -> bool:
    """
    Atualiza ou cria registro de abandono de carrinho.
    
    Args:
        carrinho: Instância do carrinho
    
    Returns:
        True se atualizado com sucesso, False caso contrário
    """
    try:
        abandono, created = AbandonoCarrinho.objects.get_or_create(carrinho=carrinho)
        abandono.subtotal_snapshot = carrinho.subtotal
        abandono.status = "pendente"
        abandono.data_ultimo_evento = timezone.now()
        abandono.save(update_fields=["subtotal_snapshot", "status", "data_ultimo_evento"])
        
        action = "criado" if created else "atualizado"
        logger.debug(f"Abandono de carrinho {action} para carrinho {carrinho.pk}")
        return True
        
    except Exception as e:
        logger.exception(f"Falha ao atualizar abandono de carrinho {carrinho.pk}: {e}")
        return False


@receiver(post_save, sender=ItemCarrinho)
def registrar_abandono_ao_adicionar(sender, instance, **kwargs):
    """
    Registra atividade no carrinho quando item é adicionado/atualizado.
    """
    try:
        _atualizar_abandono_carrinho(instance.carrinho)
    except Exception as e:
        logger.exception(f"Erro ao processar abandono no save de ItemCarrinho: {e}")


@receiver(post_delete, sender=ItemCarrinho)
def registrar_abandono_ao_remover(sender, instance, **kwargs):
    """
    Atualiza status do abandono quando item é removido.
    Se carrinho ficar vazio, marca abandono como 'ignorado'.
    """
    try:
        carrinho = instance.carrinho
        
        # Se ainda tem itens, atualiza abandono
        if carrinho.itens.exists():
            _atualizar_abandono_carrinho(carrinho)
        else:
            # Carrinho vazio, marca como ignorado
            AbandonoCarrinho.objects.filter(carrinho=carrinho).update(
                status="ignorado",
                data_ultimo_evento=timezone.now()
            )
            logger.debug(f"Abandono de carrinho {carrinho.pk} marcado como ignorado (vazio)")
            
    except Exception as e:
        logger.exception(f"Erro ao processar abandono no delete de ItemCarrinho: {e}")