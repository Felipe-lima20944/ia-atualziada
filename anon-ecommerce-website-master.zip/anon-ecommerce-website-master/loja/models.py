"""
🔥 MODELS AVANÇADOS PARA E-COMMERCE COM GAMIFICAÇÃO E FIDELIDADE
Inclui: Sistema de Cupons Personalizados, Recompensas, Pontos, Badges,
Programa de Fidelidade, Cashback, Referência, Analytics e muito mais!
"""
import json
import uuid
from decimal import Decimal

from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.core.cache import cache
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models, transaction
from django.db.models import Avg, Count, F, Q, Sum
from django.utils import timezone
from django.utils.crypto import get_random_string
from django.utils.text import slugify


# ═══════════════════════════════════════════════════════════════════════════
# 0. CUSTOM USER MANAGER
# ═══════════════════════════════════════════════════════════════════════════
class UsuarioManager(BaseUserManager):
    """Gerenciador personalizado para modelo Usuario com email como identificador."""

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("O campo Email é obrigatório")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self.create_user(email, password, **extra_fields)


# ═══════════════════════════════════════════════════════════════════════════
# 1. MODELO DE USUÁRIO PERSONALIZADO
# ═══════════════════════════════════════════════════════════════════════════
class Usuario(AbstractUser):
    """Usuário personalizado com suporte a gamificação e fidelidade."""

    TIPO_CLIENTE_CHOICES = [
        ("F", "Pessoa Física"),
        ("J", "Pessoa Jurídica"),
    ]

    username = None
    email = models.EmailField(unique=True, verbose_name="E-mail")

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["first_name", "last_name"]

    objects = UsuarioManager()

    telefone = models.CharField(max_length=20, blank=True, verbose_name="Telefone")
    tipo_cliente = models.CharField(max_length=1, choices=TIPO_CLIENTE_CHOICES, default="F", verbose_name="Tipo de Cliente")
    data_nascimento = models.DateField(null=True, blank=True, verbose_name="Data de Nascimento")
    aceita_marketing = models.BooleanField(default=False, verbose_name="Aceita Receber Marketing")

    # Gamificação e fidelidade
    pontos_totais = models.PositiveIntegerField(default=0, verbose_name="Pontos Totais Acumulados")
    pontos_disponiveis = models.PositiveIntegerField(default=0, verbose_name="Pontos Disponíveis")
    nivel_fidelidade = models.CharField(
        max_length=20,
        choices=[
            ("bronze", "Bronze"),
            ("prata", "Prata"),
            ("ouro", "Ouro"),
            ("platina", "Platina"),
            ("diamante", "Diamante"),
        ],
        default="bronze",
        verbose_name="Nível de Fidelidade",
    )
    experiencia_xp = models.PositiveIntegerField(default=0, verbose_name="XP (Experiência)")

    # Cashback & referência
    saldo_cashback = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Saldo de Cashback Disponível")
    total_cashback_recebido = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Total de Cashback Recebido")
    codigo_referencia = models.CharField(max_length=20, unique=True, blank=True, verbose_name="Código de Referência Único")
    referido_por = models.ForeignKey(
        "self",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="referidos",
        verbose_name="Referido Por",
    )
    total_referencias = models.PositiveIntegerField(default=0)

    # Estatísticas
    total_gasto = models.DecimalField(max_digits=12, decimal_places=2, default=0, verbose_name="Total Gasto em Compras")
    numero_compras = models.PositiveIntegerField(default=0)
    ticket_medio = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Ticket Médio")
    frequencia_compras_dias = models.PositiveIntegerField(default=0, verbose_name="Dias entre Compras")

    # Preferências
    categoria_preferida = models.ForeignKey("Categoria", on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Categoria Preferida")
    marcas_preferidas = models.ManyToManyField("Marca", blank=True, related_name="usuarios_interessados")

    data_criacao = models.DateTimeField(auto_now_add=True)
    data_atualizacao = models.DateTimeField(auto_now=True)
    ultimo_acesso = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Usuário"
        verbose_name_plural = "Usuários"
        indexes = [
            models.Index(fields=["email"]),
            models.Index(fields=["nivel_fidelidade"]),
            models.Index(fields=["pontos_disponiveis"]),
            models.Index(fields=["codigo_referencia"]),
        ]

    def __str__(self):
        return f"{self.get_full_name()} ({self.email})"

    # ---- Helpers ----
    def _gerar_codigo_unico(self):
        """Gera código único sempre que necessário."""
        codigo = get_random_string(10).upper()
        while Usuario.objects.filter(codigo_referencia=codigo).exists():
            codigo = get_random_string(10).upper()
        return codigo

    def save(self, *args, **kwargs):
        is_new = self._state.adding
        if self.codigo_referencia:
            self.codigo_referencia = self.codigo_referencia.upper()
        if not self.codigo_referencia:
            self.codigo_referencia = self._gerar_codigo_unico()

        if self.data_nascimento and self.data_nascimento > timezone.now().date():
            raise ValidationError({"data_nascimento": "Data de nascimento não pode ser futura."})

        super().save(*args, **kwargs)
        if is_new:
            self._aplicar_bonus_referencia_registro()

    def clean(self):
        if self.data_nascimento and self.data_nascimento > timezone.now().date():
            raise ValidationError({"data_nascimento": "Data de nascimento não pode ser futura."})

    # ---- Lógica de negócios ----
    def _aplicar_bonus_referencia_registro(self):
        """Aplica benefícios imediatos de indicação no momento do cadastro, conforme ConfiguracaoSite."""
        if not self.referido_por:
            return

        config = ConfiguracaoSite.load()
        if not config:
            return

        usar_novos = config.referencia_bonus_cadastro_ativo
        if not usar_novos:
            # Compatibilidade com campos antigos se os novos não estiverem ativos
            usar_novos = (config.bonus_referencia_referidor > 0) or (config.bonus_referencia_novo > 0)

        try:
            ref_id = f"CAD-{self.pk}"
            # Evita aplicar duas vezes no mesmo cadastro
            if RegistroCashback.objects.filter(usuario=self, referencia=ref_id).exists() or RegistroPontos.objects.filter(usuario=self, referencia=ref_id).exists():
                return

            if usar_novos:
                # Benefícios para o referidor
                if config.referencia_bonus_cadastro_referidor_cashback > 0:
                    self.referido_por.adicionar_cashback(
                        config.referencia_bonus_cadastro_referidor_cashback,
                        motivo=f"Bônus por indicar {self.first_name or 'novo usuário'} (cadastro)",
                        referencia=ref_id,
                    )
                if config.referencia_bonus_cadastro_referidor_pontos > 0:
                    self.referido_por.adicionar_pontos(
                        int(config.referencia_bonus_cadastro_referidor_pontos),
                        motivo=f"Bônus de pontos por indicação de {self.first_name or 'novo usuário'}",
                        referencia=ref_id,
                    )

                # Benefícios para o novo usuário
                if config.referencia_bonus_cadastro_novo_cashback > 0:
                    self.adicionar_cashback(
                        config.referencia_bonus_cadastro_novo_cashback,
                        motivo="Bônus de cadastro por indicação",
                        referencia=ref_id,
                    )
                if config.referencia_bonus_cadastro_novo_pontos > 0:
                    self.adicionar_pontos(
                        int(config.referencia_bonus_cadastro_novo_pontos),
                        motivo="Bônus de pontos por cadastro via indicação",
                        referencia=ref_id,
                    )
            else:
                # Fallback: usar campos antigos se os novos não estiverem ativos
                if config.bonus_referencia_referidor > 0:
                    self.referido_por.adicionar_cashback(
                        config.bonus_referencia_referidor,
                        motivo=f"Bônus por indicação (cadastro) de {self.first_name or 'novo usuário'}",
                        referencia=ref_id,
                    )
                if config.bonus_referencia_novo > 0:
                    self.adicionar_cashback(
                        config.bonus_referencia_novo,
                        motivo="Bônus de cadastro por indicação",
                        referencia=ref_id,
                    )
        except Exception:
            # Não bloquear o cadastro por falha no bônus; log/monitorar em camada superior se necessário.
            pass

    def recalcular_estatisticas_compras(self):
        dados = self.pedidos.filter(status__in=["pago", "enviado", "entregue"]).aggregate(total_real=Sum("total"), qtd_pedidos=Count("id"))
        self.total_gasto = dados["total_real"] or Decimal("0.00")
        self.numero_compras = dados["qtd_pedidos"] or 0
        self.ticket_medio = self.total_gasto / self.numero_compras if self.numero_compras > 0 else Decimal("0.00")
        self.save()
        self.atualizar_nivel_fidelidade()

    def gerar_codigo_referencia(self):
        if not self.codigo_referencia:
            self.codigo_referencia = self._gerar_codigo_unico()
            self.save(update_fields=["codigo_referencia"])
        return self.codigo_referencia

    def adicionar_pontos(self, quantidade, motivo="", origem="bonus", referencia="", pedido=None):
        self.pontos_totais += quantidade
        self.pontos_disponiveis += quantidade
        self.experiencia_xp += quantidade // 10
        self.save()
        ref = referencia or (pedido.numero_pedido if pedido else "") or (motivo or f"REF-{uuid.uuid4().hex[:8]}")
        RegistroPontos.objects.create(
            usuario=self,
            quantidade=quantidade,
            tipo="adicionar",
            motivo=motivo,
            origem=origem or "bonus",
            referencia=str(ref),
            pedido=pedido,
        )
        self.atualizar_nivel_fidelidade()

    def remover_pontos(self, quantidade, motivo="", origem="resgate", referencia="", pedido=None):
        if self.pontos_disponiveis < quantidade:
            raise ValidationError("Pontos insuficientes")
        self.pontos_disponiveis -= quantidade
        self.save()
        ref = referencia or (pedido.numero_pedido if pedido else "") or (motivo or f"REF-{uuid.uuid4().hex[:8]}")
        RegistroPontos.objects.create(
            usuario=self,
            quantidade=quantidade,
            tipo="remover",
            motivo=motivo,
            origem=origem or "resgate",
            referencia=str(ref),
            pedido=pedido,
        )

    def adicionar_cashback(self, valor, motivo="", origem="bonus", referencia="", pedido=None):
        self.saldo_cashback += Decimal(str(valor))
        self.total_cashback_recebido += Decimal(str(valor))
        self.save()
        ref = referencia or (pedido.numero_pedido if pedido else "") or (motivo or f"REF-{uuid.uuid4().hex[:8]}")
        RegistroCashback.objects.create(
            usuario=self,
            valor=valor,
            tipo="credito",
            motivo=motivo,
            origem=origem or "bonus",
            referencia=str(ref),
            pedido=pedido,
        )

    def usar_cashback(self, valor, origem="compra", motivo="Utilizado em compra", referencia="", pedido=None):
        if self.saldo_cashback < Decimal(str(valor)):
            raise ValidationError("Saldo de cashback insuficiente")
        self.saldo_cashback -= Decimal(str(valor))
        self.save()
        ref = referencia or (pedido.numero_pedido if pedido else "") or (motivo or f"REF-{uuid.uuid4().hex[:8]}")
        RegistroCashback.objects.create(
            usuario=self,
            valor=valor,
            tipo="debito",
            motivo=motivo or "Utilizado em compra",
            origem=origem or "compra",
            referencia=str(ref),
            pedido=pedido,
        )

    def atualizar_nivel_fidelidade(self):
        if self.total_gasto >= 10000:
            novo_nivel = "diamante"
        elif self.total_gasto >= 5000:
            novo_nivel = "platina"
        elif self.total_gasto >= 2000:
            novo_nivel = "ouro"
        elif self.total_gasto >= 500:
            novo_nivel = "prata"
        else:
            novo_nivel = "bronze"

        if novo_nivel != self.nivel_fidelidade:
            self.nivel_fidelidade = novo_nivel
            self.save()
            Notificacao.objects.create(
                usuario=self,
                tipo="promocao",
                titulo=f"🎉 Novo Nível: {novo_nivel.title()}",
                mensagem=f"Parabéns! Você subiu para o nível {novo_nivel}",
            )

    def obter_multiplicador_pontos(self):
        multiplicadores = {"bronze": 1.0, "prata": 1.2, "ouro": 1.5, "platina": 1.8, "diamante": 2.0}
        return multiplicadores.get(self.nivel_fidelidade, 1.0)

    def obter_desconto_fidelidade(self):
        try:
            config = ConfiguracaoSite.load()
            descontos = {
                "bronze": float(getattr(config, "fidelidade_bronze_pct", 0) or 0),
                "prata": float(getattr(config, "fidelidade_prata_pct", 3) or 0),
                "ouro": float(getattr(config, "fidelidade_ouro_pct", 5) or 0),
                "platina": float(getattr(config, "fidelidade_platina_pct", 8) or 0),
                "diamante": float(getattr(config, "fidelidade_diamante_pct", 10) or 0),
            }
        except Exception:
            descontos = {"bronze": 0, "prata": 3, "ouro": 5, "platina": 8, "diamante": 10}
        return descontos.get(self.nivel_fidelidade, 0)

    @property
    def documento(self):
        if hasattr(self, "perfil"):
            return self.perfil.cpf if self.tipo_cliente == "F" else self.perfil.cnpj
        return ""

    # ---- Badges ----
    def _badge_condicao_atendida(self, badge):
        alvo = badge.condicao_valor or 0
        cond = badge.condicao_tipo
        if cond == "primeira_compra":
            return self.numero_compras >= 1
        if cond == "compras_totais":
            return self.numero_compras >= alvo
        if cond == "valor_total":
            try:
                return float(self.total_gasto) >= float(alvo)
            except Exception:
                return False
        if cond == "pontos_acumulados":
            return self.pontos_totais >= alvo
        if cond == "avaliacoes":
            try:
                return self.avaliacoes.filter(aprovado=True).count() >= alvo
            except Exception:
                return False
        if cond == "referidos":
            try:
                total_refs = max(self.total_referencias, self.referidos.count())
            except Exception:
                total_refs = self.total_referencias
            return total_refs >= alvo
        if cond == "nivel_fidelidade":
            ordem = ["bronze", "prata", "ouro", "platina", "diamante"]
            try:
                if isinstance(alvo, str):
                    alvo_nivel = alvo.strip().lower()
                    alvo_idx = ordem.index(alvo_nivel) if alvo_nivel in ordem else 0
                else:
                    alvo_idx = int(alvo)
                    alvo_idx = max(0, min(alvo_idx, len(ordem) - 1))
                return ordem.index(self.nivel_fidelidade) >= alvo_idx
            except Exception:
                return False
        return False

    def atualizar_total_referencias(self):
        """Recalcula total de referências a partir do relacionamento reverso."""
        try:
            total_refs = self.referidos.count()
        except Exception:
            total_refs = self.total_referencias
        if total_refs != self.total_referencias:
            self.total_referencias = total_refs
            try:
                self.save(update_fields=["total_referencias"])
            except Exception:
                self.total_referencias = total_refs

    def avaliar_badges(self):
        """Avalia e concede badges ativas conforme as regras configuradas."""
        # Garante que total_referencias está atualizado
        self.atualizar_total_referencias()
        badges_ativas = Badge.objects.filter(ativa=True)
        conquistadas = set(self.badges.values_list("badge_id", flat=True))

        for badge in badges_ativas:
            if badge.id in conquistadas:
                continue
            if not self._badge_condicao_atendida(badge):
                continue
            usuario_badge, created = UsuarioBadge.objects.get_or_create(
                usuario=self, badge=badge, defaults={"novo": True}
            )
            if not created:
                continue
            # Recompensas configuráveis
            if badge.pontos_bonus > 0:
                try:
                    self.adicionar_pontos(int(badge.pontos_bonus), motivo=f"Badge: {badge.nome}", origem="badge")
                except Exception:
                    pass
            if badge.cashback_bonus and badge.cashback_bonus > 0:
                try:
                    self.adicionar_cashback(float(badge.cashback_bonus), motivo=f"Badge: {badge.nome}", origem="badge")
                except Exception:
                    pass


# ═══════════════════════════════════════════════════════════════════════════
# 2. PERFIL DE USUÁRIO
# ═══════════════════════════════════════════════════════════════════════════
class PerfilUsuario(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name="perfil")
    avatar = models.ImageField(upload_to="avatares/%Y/%m/", blank=True, null=True, verbose_name="Foto de Perfil")
    cpf = models.CharField(max_length=14, blank=True, verbose_name="CPF")
    cnpj = models.CharField(max_length=18, blank=True, verbose_name="CNPJ")
    cep = models.CharField(max_length=9, blank=True, verbose_name="CEP")
    endereco = models.CharField(max_length=200, blank=True, verbose_name="Endereço")
    numero = models.CharField(max_length=10, blank=True, verbose_name="Número")
    complemento = models.CharField(max_length=100, blank=True, verbose_name="Complemento")
    bairro = models.CharField(max_length=100, blank=True, verbose_name="Bairro")
    cidade = models.CharField(max_length=100, blank=True, verbose_name="Cidade")
    estado = models.CharField(max_length=2, blank=True, verbose_name="Estado")
    pais = models.CharField(max_length=50, default="Brasil", verbose_name="País")

    class Meta:
        verbose_name = "Perfil do Usuário"
        verbose_name_plural = "Perfis dos Usuários"

    def __str__(self):
        return f"Perfil de {self.usuario.get_full_name()}"

    def clean(self):
        if self.usuario.tipo_cliente == "F" and not self.cpf:
            raise ValidationError({"cpf": "CPF é obrigatório para Pessoa Física."})
        if self.usuario.tipo_cliente == "J" and not self.cnpj:
            raise ValidationError({"cnpj": "CNPJ é obrigatório para Pessoa Jurídica."})


# ═══════════════════════════════════════════════════════════════════════════
# 3. SISTEMA DE PONTOS E CASHBACK
# ═══════════════════════════════════════════════════════════════════════════
class RegistroPontos(models.Model):
    TIPO_MOVIMENTO = [
        ("adicionar", "Adicionado"),
        ("remover", "Removido"),
        ("expirar", "Expirado"),
    ]
    ORIGEM_CHOICES = [
        ("compra", "Compra/ganho"),
        ("bonus", "Bônus/promoção"),
        ("resgate", "Resgate em pedido"),
        ("estorno", "Estorno/Ajuste"),
        ("expiracao", "Expiração"),
        ("outro", "Outro"),
    ]

    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="historico_pontos")
    quantidade = models.IntegerField()
    tipo = models.CharField(max_length=20, choices=TIPO_MOVIMENTO)
    motivo = models.CharField(max_length=255, blank=True)
    origem = models.CharField(max_length=30, choices=ORIGEM_CHOICES, default="outro")
    referencia = models.CharField(max_length=100, blank=True)
    pedido = models.ForeignKey("Pedido", on_delete=models.SET_NULL, null=True, blank=True)
    data_criacao = models.DateTimeField(auto_now_add=True)
    data_expiracao = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Registro de Pontos"
        verbose_name_plural = "Registros de Pontos"
        ordering = ["-data_criacao"]
        indexes = [models.Index(fields=["usuario", "data_criacao"])]

    def __str__(self):
        return f"{self.usuario.email} - {self.tipo}: {self.quantidade} pts"


class RegistroCashback(models.Model):
    TIPO_MOVIMENTO = [
        ("credito", "Crédito"),
        ("debito", "Débito"),
    ]
    ORIGEM_CHOICES = [
        ("compra", "Uso em compra"),
        ("saque_pix", "Saque via PIX"),
        ("saque_outro", "Saque"),
        ("bonus", "Bônus/Promoção"),
        ("comissao", "Comissão/Afiliado"),
        ("estorno", "Estorno/Ajuste"),
        ("outro", "Outro"),
    ]

    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="historico_cashback")
    valor = models.DecimalField(max_digits=10, decimal_places=2)
    tipo = models.CharField(max_length=20, choices=TIPO_MOVIMENTO)
    motivo = models.CharField(max_length=255)
    origem = models.CharField(max_length=30, choices=ORIGEM_CHOICES, default="outro")
    referencia = models.CharField(max_length=100, blank=True)
    pedido = models.ForeignKey("Pedido", on_delete=models.SET_NULL, null=True, blank=True)
    data_criacao = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Registro de Cashback"
        verbose_name_plural = "Registros de Cashback"
        ordering = ["-data_criacao"]
        indexes = [models.Index(fields=["usuario", "data_criacao"])]

    def __str__(self):
        return f"{self.usuario.email} - {self.tipo}: R$ {self.valor}"


class Badge(models.Model):
    nome = models.CharField(max_length=100, verbose_name="Nome da Badge")
    slug = models.SlugField(unique=True)
    descricao = models.CharField(max_length=255)
    icone = models.ImageField(upload_to="badges/", verbose_name="Icone da Badge")
    condicao_tipo = models.CharField(
        max_length=50,
        choices=[
            ("primeira_compra", "Primeira Compra"),
            ("compras_totais", "Total de Compras"),
            ("valor_total", "Valor Total Gasto"),
            ("pontos_acumulados", "Pontos Acumulados"),
            ("avaliacoes", "Número de Avaliações"),
            ("referidos", "Número de Referidos"),
            ("nivel_fidelidade", "Nível de Fidelidade"),
        ],
    )
    condicao_valor = models.IntegerField(verbose_name="Valor Necessário")
    raridade = models.CharField(
        max_length=20,
        choices=[
            ("comum", "Comum 🔵"),
            ("incomum", "Incomum 🟢"),
            ("rara", "Rara 🔵"),
            ("epica", "Épica 🟣"),
            ("lendaria", "Lendária 🟡"),
        ],
        default="comum",
    )
    pontos_bonus = models.PositiveIntegerField(default=10, verbose_name="Pontos Bonus")
    cashback_bonus = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Cashback Bonus")
    ativa = models.BooleanField(default=True)
    data_criacao = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Badge"
        verbose_name_plural = "Badges"

    def __str__(self):
        return self.nome

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nome)
        super().save(*args, **kwargs)


class UsuarioBadge(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="badges")
    badge = models.ForeignKey(Badge, on_delete=models.CASCADE)
    data_obtida = models.DateTimeField(auto_now_add=True)
    novo = models.BooleanField(default=True)

    class Meta:
        unique_together = ["usuario", "badge"]
        ordering = ["-data_obtida"]
        verbose_name = "Badge do Usuário"
        verbose_name_plural = "Badges dos Usuários"

    def __str__(self):
        return f"{self.usuario.email} - {self.badge.nome}"


# ═══════════════════════════════════════════════════════════════════════════
# 4. SISTEMA AVANÇADO DE CUPONS
# ═══════════════════════════════════════════════════════════════════════════
class CupomDesconto(models.Model):
    TIPO_DESCONTO = [
        ("percentual", "Percentual"),
        ("valor_fixo", "Valor Fixo"),
        ("frete_gratis", "Frete Grátis"),
        ("pontos_bonus", "Pontos Bonus"),
    ]

    ALCANCE = [
        ("global", "Todos os Usuários"),
        ("afiliado", "Cupom de Afiliado/Parceiro"),
        ("por_usuario", "Usuários Específicos"),
        ("por_nivel", "Por Nível de Fidelidade"),
        ("primeira_compra", "Primeira Compra"),
        ("por_referencia", "Por Código de Referência"),
    ]

    codigo = models.CharField(max_length=50, unique=True, verbose_name="Código do Cupom")
    nome = models.CharField(max_length=200, verbose_name="Nome do Cupom")
    descricao = models.TextField(blank=True, verbose_name="Descrição (para admin)")

    criador = models.ForeignKey(
        "Usuario",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="cupons_criados",
        verbose_name="Criado por (Dono)",
    )
    comissao_afiliado = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name="Comissão do Criador (%)", help_text="0 a 100%")
    preco_venda = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Preço de Venda (Marketplace)")
    is_publico_marketplace = models.BooleanField(default=False, verbose_name="Visível no Marketplace")

    tipo_desconto = models.CharField(max_length=20, choices=TIPO_DESCONTO, default="percentual")
    valor_desconto = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(0)], verbose_name="Valor/Percentual de Desconto")
    valor_maximo_desconto = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Máximo de Desconto (em R$)")

    valor_minimo_compra = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Valor Mínimo da Compra")

    alcance = models.CharField(max_length=20, choices=ALCANCE, default="global")
    usuarios_especificos = models.ManyToManyField("Usuario", blank=True, related_name="cupons_personalizados", verbose_name="Usuários Aplicáveis")
    niveis_fidelidade = models.CharField(
        max_length=255,
        blank=True,
        help_text="Níveis separados por vírgula: bronze,prata,ouro,platina,diamante",
        verbose_name="Níveis de Fidelidade",
    )

    produtos_aplicaveis = models.ManyToManyField("Produto", blank=True, related_name="cupons", verbose_name="Produtos Específicos")
    categorias_aplicaveis = models.ManyToManyField("Categoria", blank=True, related_name="cupons", verbose_name="Categorias Específicas")

    uso_maximo_total = models.PositiveIntegerField(default=1000, verbose_name="Uso Máximo Total")
    uso_maximo_por_usuario = models.PositiveIntegerField(default=1, verbose_name="Uso Máximo por Usuário")
    usos_atuais = models.PositiveIntegerField(default=0)

    data_inicio = models.DateTimeField(default=timezone.now)
    data_fim = models.DateTimeField(verbose_name="Data de Término")
    ativo = models.BooleanField(default=True)

    pontos_bonus_ao_usar = models.IntegerField(default=0, verbose_name="Pontos Bonus ao Usar")
    criar_badge_ao_usar = models.ForeignKey("Badge", on_delete=models.SET_NULL, null=True, blank=True, related_name="cupons_badge", verbose_name="Badge ao Usar")
    ativar_cashback_bonus = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Cashback Bonus % ao Usar")

    data_criacao = models.DateTimeField(auto_now_add=True)
    data_atualizacao = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Cupom de Desconto"
        verbose_name_plural = "Cupons de Desconto"
        ordering = ["-data_criacao"]
        indexes = [
            models.Index(fields=["codigo", "ativo"]),
            models.Index(fields=["criador"]),
        ]

    def __str__(self):
        origem = f" (Afiliado: {self.criador.email})" if self.criador else ""
        return f"{self.codigo} - {self.nome}{origem}"

    def save(self, *args, **kwargs):
        if not self.codigo:
            self.codigo = str(uuid.uuid4())[:8].upper()
        if self.criador and self.alcance == "global":
            self.alcance = "afiliado"
        super().save(*args, **kwargs)

    def clean(self):
        if self.data_fim and self.data_inicio and self.data_fim <= self.data_inicio:
            raise ValidationError({"data_fim": "Data de término deve ser posterior à data de início."})
        if self.comissao_afiliado < 0 or self.comissao_afiliado > 50:
            raise ValidationError({"comissao_afiliado": "Comissão inválida (Máximo 50%)."})

    @property
    def valido(self):
        agora = timezone.now()
        return self.ativo and self.data_inicio <= agora <= self.data_fim and self.usos_atuais < self.uso_maximo_total

    def validar_para_usuario(self, usuario, valor_total=0, carrinho=None):
        erros = []
        if not self.valido:
            erros.append("Cupom inválido ou expirado")
            return False, erros

        if self.criador and self.criador_id == usuario.id:
            erros.append("Você não pode usar seu próprio cupom de afiliado.")
            return False, erros

        if valor_total < self.valor_minimo_compra:
            erros.append(f"Valor mínimo de R$ {self.valor_minimo_compra} não atingido")
            return False, erros

        if self.alcance == "por_usuario":
            if not self.usuarios_especificos.filter(id=usuario.id).exists():
                erros.append("Cupom não aplicável para este usuário")
                return False, erros
        elif self.alcance == "por_nivel":
            niveis = [n.strip() for n in self.niveis_fidelidade.split(",") if n.strip()]
            if usuario.nivel_fidelidade not in niveis:
                erros.append(f"Cupom válido apenas para níveis: {self.niveis_fidelidade}")
                return False, erros
        elif self.alcance == "primeira_compra":
            if usuario.numero_compras > 0:
                erros.append("Cupom válido apenas para primeira compra")
                return False, erros

        uso_usuario = CupomDescontoUso.objects.filter(cupom=self, usuario=usuario).count()
        if uso_usuario >= self.uso_maximo_por_usuario:
            erros.append(f"Você já utilizou este cupom {self.uso_maximo_por_usuario} vez(es)")
            return False, erros

        if carrinho and (self.produtos_aplicaveis.exists() or self.categorias_aplicaveis.exists()):
            produtos_validos = False
            for item in carrinho.itens.all():
                if self.produtos_aplicaveis.filter(id=item.produto.id).exists():
                    produtos_validos = True
                    break
                if item.produto.categoria and self.categorias_aplicaveis.filter(id=item.produto.categoria.id).exists():
                    produtos_validos = True
                    break
            if not produtos_validos:
                erros.append("Cupom não aplicável aos produtos do carrinho")
                return False, erros

        return True, erros

    def calcular_desconto(self, valor_total):
        if not self.valido:
            return Decimal("0")
        if self.tipo_desconto == "percentual":
            desconto = Decimal(str(valor_total)) * (self.valor_desconto / 100)
            if self.valor_maximo_desconto:
                desconto = min(desconto, self.valor_maximo_desconto)
            return desconto
        if self.tipo_desconto == "valor_fixo":
            return min(self.valor_desconto, Decimal(str(valor_total)))
        return Decimal("0")

    def aplicar(self, usuario, valor_total, carrinho=None):
        valido, erros = self.validar_para_usuario(usuario, valor_total, carrinho)
        if not valido:
            return None, erros

        desconto = self.calcular_desconto(valor_total)

        valor_comissao = Decimal("0")
        if self.criador and self.comissao_afiliado > 0:
            valor_comissao = Decimal(str(valor_total)) * (self.comissao_afiliado / 100)

        uso = CupomDescontoUso.objects.create(cupom=self, usuario=usuario, valor_desconto=desconto, comissao_gerada=valor_comissao)

        self.usos_atuais += 1
        self.save()

        # 💸 Crédito automático de comissão/cashback para o criador (se não for auto-uso)
        if self.criador and self.criador_id != usuario.id and valor_comissao > 0:
            try:
                self.criador.adicionar_cashback(float(valor_comissao), motivo=f"Comissão do cupom {self.codigo}")
                Notificacao.objects.create(
                    usuario=self.criador,
                    tipo="promocao",
                    titulo="Comissão recebida",
                    mensagem=f"Seu cupom {self.codigo} gerou R$ {valor_comissao:.2f} de comissão.",
                )
            except Exception:
                pass

        recompensas = []
        if self.pontos_bonus_ao_usar > 0:
            usuario.adicionar_pontos(self.pontos_bonus_ao_usar, motivo=f"Cupom {self.codigo} utilizado")
            recompensas.append({"tipo": "pontos", "valor": self.pontos_bonus_ao_usar})

        if self.criar_badge_ao_usar:
            badge_usuario, criada = UsuarioBadge.objects.get_or_create(usuario=usuario, badge=self.criar_badge_ao_usar)
            if criada and self.criar_badge_ao_usar.pontos_bonus > 0:
                usuario.adicionar_pontos(self.criar_badge_ao_usar.pontos_bonus)
            if criada:
                recompensas.append({"tipo": "badge", "valor": self.criar_badge_ao_usar.nome})

        if self.ativar_cashback_bonus > 0:
            cashback_extra = Decimal(str(desconto)) * (self.ativar_cashback_bonus / 100)
            usuario.adicionar_cashback(float(cashback_extra), motivo=f"Cashback bonus do cupom {self.codigo}")
            recompensas.append({"tipo": "cashback", "valor": float(cashback_extra)})

        return uso, recompensas


class CupomDescontoUso(models.Model):
    cupom = models.ForeignKey(CupomDesconto, on_delete=models.CASCADE, related_name="usos")
    usuario = models.ForeignKey("Usuario", on_delete=models.CASCADE, related_name="cupons_utilizados")
    pedido = models.ForeignKey("Pedido", on_delete=models.SET_NULL, null=True, blank=True, related_name="usos_cupom")
    valor_desconto = models.DecimalField(max_digits=10, decimal_places=2)
    comissao_gerada = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Comissão Gerada (Snapshot)")
    data_uso = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Uso de Cupom"
        verbose_name_plural = "Usos de Cupons"
        ordering = ["-data_uso"]
        indexes = [
            models.Index(fields=["cupom", "usuario"]),
            models.Index(fields=["data_uso"]),
        ]

    def __str__(self):
        return f"{self.usuario.email} - {self.cupom.codigo}"


class CampanhaCupom(models.Model):
    TIPO_CAMPANHA = [
        ("automatico", "Automático (Regras)"),
        ("manual", "Manual (Seleção Usuários)"),
        ("email", "Email Marketing"),
    ]

    nome = models.CharField(max_length=200)
    descricao = models.TextField()
    tipo = models.CharField(max_length=20, choices=TIPO_CAMPANHA)
    cupom = models.OneToOneField(CupomDesconto, on_delete=models.CASCADE, related_name="campanha")

    incluir_usuarios = models.ManyToManyField("Usuario", blank=True, related_name="campanhas_inclusos")
    nivel_minimo_fidelidade = models.CharField(
        max_length=20,
        choices=[("bronze", "Bronze"), ("prata", "Prata"), ("ouro", "Ouro"), ("platina", "Platina"), ("diamante", "Diamante")],
        blank=True,
        verbose_name="Nível Mínimo de Fidelidade",
    )
    gasto_minimo = models.DecimalField(max_digits=10, decimal_places=2, default=0, verbose_name="Gasto Mínimo do Usuário")

    data_inicio = models.DateTimeField(default=timezone.now)
    data_fim = models.DateTimeField()
    ativa = models.BooleanField(default=True)

    total_enviado = models.PositiveIntegerField(default=0)
    total_utilizado = models.PositiveIntegerField(default=0)
    data_criacao = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Campanha de Cupom"
        verbose_name_plural = "Campanhas de Cupom"

    def __str__(self):
        return self.nome

    def processar_campanha(self):
        if not self.ativa:
            return
        usuarios_alvo = Usuario.objects.filter(is_active=True)

        if self.nivel_minimo_fidelidade:
            niveis_ordem = ["bronze", "prata", "ouro", "platina", "diamante"]
            try:
                idx = niveis_ordem.index(self.nivel_minimo_fidelidade)
                niveis_validos = niveis_ordem[idx:]
                usuarios_alvo = usuarios_alvo.filter(nivel_fidelidade__in=niveis_validos)
            except ValueError:
                pass

        if self.gasto_minimo > 0:
            usuarios_alvo = usuarios_alvo.filter(total_gasto__gte=self.gasto_minimo)

        if self.incluir_usuarios.exists():
            ids_alvo = list(usuarios_alvo.values_list("id", flat=True))
            ids_manuais = list(self.incluir_usuarios.values_list("id", flat=True))
            todos_ids = list(set(ids_alvo + ids_manuais))
            usuarios_alvo = Usuario.objects.filter(id__in=todos_ids)

        count_novos = 0
        for usuario in usuarios_alvo:
            if not self.cupom.usuarios_especificos.filter(id=usuario.id).exists():
                self.cupom.usuarios_especificos.add(usuario)
                count_novos += 1

        if count_novos > 0:
            self.total_enviado += count_novos
            self.save()
            if self.cupom.alcance == "global":
                self.cupom.alcance = "por_usuario"
                self.cupom.save()


# ═══════════════════════════════════════════════════════════════════════════
# 5. ENDEREÇO DE ENTREGA
# ═══════════════════════════════════════════════════════════════════════════
class EnderecoEntrega(models.Model):
    ESTADO_CHOICES = [
        ("AC", "Acre"),
        ("AL", "Alagoas"),
        ("AP", "Amapá"),
        ("AM", "Amazonas"),
        ("BA", "Bahia"),
        ("CE", "Ceará"),
        ("DF", "Distrito Federal"),
        ("ES", "Espírito Santo"),
        ("GO", "Goiás"),
        ("MA", "Maranhão"),
        ("MT", "Mato Grosso"),
        ("MS", "Mato Grosso do Sul"),
        ("MG", "Minas Gerais"),
        ("PA", "Pará"),
        ("PB", "Paraíba"),
        ("PR", "Paraná"),
        ("PE", "Pernambuco"),
        ("PI", "Piauí"),
        ("RJ", "Rio de Janeiro"),
        ("RN", "Rio Grande do Norte"),
        ("RS", "Rio Grande do Sul"),
        ("RO", "Rondônia"),
        ("RR", "Roraima"),
        ("SC", "Santa Catarina"),
        ("SP", "São Paulo"),
        ("SE", "Sergipe"),
        ("TO", "Tocantins"),
    ]

    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="enderecos_entrega")
    apelido = models.CharField(max_length=50, verbose_name="Apelido (ex: Casa, Trabalho)")
    nome_destinatario = models.CharField(max_length=100)
    telefone = models.CharField(max_length=20)
    cep = models.CharField(max_length=9)
    endereco = models.CharField(max_length=200)
    numero = models.CharField(max_length=10)
    complemento = models.CharField(max_length=100, blank=True)
    bairro = models.CharField(max_length=100)
    cidade = models.CharField(max_length=100)
    estado = models.CharField(max_length=2, choices=ESTADO_CHOICES)
    pais = models.CharField(max_length=50, default="Brasil")
    principal = models.BooleanField(default=False)
    ativo = models.BooleanField(default=True)
    data_criacao = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Endereço de Entrega"
        verbose_name_plural = "Endereços de Entrega"
        ordering = ["-principal", "-data_criacao"]
        indexes = [models.Index(fields=["usuario", "principal"])]

    def __str__(self):
        return f"{self.apelido} - {self.usuario.get_full_name()}"

    def save(self, *args, **kwargs):
        if self.principal:
            EnderecoEntrega.objects.filter(usuario=self.usuario, principal=True).exclude(id=self.id).update(principal=False)
        super().save(*args, **kwargs)

    @property
    def endereco_completo(self):
        partes = [f"{self.endereco}, {self.numero}", self.complemento, self.bairro, f"{self.cidade}/{self.estado}", f"CEP: {self.cep}"]
        return ", ".join([p for p in partes if p])


# ═══════════════════════════════════════════════════════════════════════════
# 6. CARRINHO DE COMPRAS
# ═══════════════════════════════════════════════════════════════════════════
class Carrinho(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name="carrinho", null=True, blank=True)
    session_key = models.CharField(max_length=40, blank=True)
    cupom_ativo = models.ForeignKey(CupomDesconto, on_delete=models.SET_NULL, null=True, blank=True, related_name="carrinhos_usando")
    data_criacao = models.DateTimeField(auto_now_add=True)
    data_atualizacao = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Carrinho de Compras"
        verbose_name_plural = "Carrinhos de Compras"
        indexes = [models.Index(fields=["session_key"])]

    def __str__(self):
        if self.usuario:
            return f"Carrinho de {self.usuario.get_full_name()}"
        return f"Carrinho Sessão {self.session_key}"

    @property
    def total_itens(self):
        return self.itens.aggregate(total=Sum("quantidade"))["total"] or 0

    @property
    def subtotal(self):
        return sum(item.subtotal for item in self.itens.all())

    @property
    def desconto_cupom(self):
        if self.cupom_ativo:
            return self.cupom_ativo.calcular_desconto(self.subtotal)
        return Decimal("0")

    @property
    def total(self):
        return self.subtotal - self.desconto_cupom

    def adicionar_item(self, produto, quantidade=1, variacao=None, afiliado_codigo_ref=None):
        if variacao and variacao.produto_id != produto.id:
            raise ValidationError("Variação inválida para este produto")
        if produto.has_variacoes and not variacao:
            raise ValidationError("Selecione uma variação para adicionar ao carrinho.")

        estoque_alvo = variacao.estoque if variacao else produto.estoque
        disponivel = variacao.disponivel if variacao else produto.disponivel
        if not disponivel or estoque_alvo < quantidade:
            raise ValidationError("Produto indisponível ou estoque insuficiente")

        defaults = {"quantidade": quantidade, "preco_unitario": variacao.preco_efetivo if variacao else produto.preco, "variacao": variacao, "afiliado_codigo_ref": afiliado_codigo_ref}
        filtros = {"carrinho": self, "produto": produto, "variacao": variacao}
        item, created = ItemCarrinho.objects.get_or_create(**filtros, defaults=defaults)
        if not created:
            item.quantidade += quantidade
            item.save()
        return item

    def remover_item(self, produto, variacao=None):
        self.itens.filter(produto=produto, variacao=variacao).delete()

    def atualizar_quantidade(self, produto, quantidade, variacao=None):
        if quantidade <= 0:
            return self.remover_item(produto, variacao=variacao)
        item = self.itens.filter(produto=produto, variacao=variacao).first()
        if item:
            estoque_alvo = item.variacao.estoque if item.variacao else produto.estoque
            if estoque_alvo < quantidade:
                raise ValidationError("Quantidade solicitada maior que estoque")
            item.quantidade = quantidade
            item.save()

    def limpar(self):
        self.itens.all().delete()
        self.cupom_ativo = None
        self.save()

    def aplicar_cupom(self, codigo_cupom, usuario=None):
        try:
            cupom = CupomDesconto.objects.get(codigo=codigo_cupom)
            if usuario:
                valido, erros = cupom.validar_para_usuario(usuario, float(self.subtotal), self)
                if not valido:
                    return False, erros
            self.cupom_ativo = cupom
            self.save()
            return True, ["Cupom aplicado com sucesso!"]
        except CupomDesconto.DoesNotExist:
            return False, ["Cupom não encontrado"]

    def finalizar_carrinho(self):
        for item in self.itens.all():
            if item.produto.has_variacoes and not item.variacao:
                raise ValidationError(f"Selecione uma variação para {item.produto.nome}.")
            estoque_alvo = item.variacao.estoque if item.variacao else item.produto.estoque
            if item.quantidade > estoque_alvo:
                msg = f"Estoque insuficiente para {item.produto.nome}"
                raise ValidationError(f"{msg}. Disponível: {estoque_alvo}, Solicitado: {item.quantidade}")


class ItemCarrinho(models.Model):
    carrinho = models.ForeignKey(Carrinho, on_delete=models.CASCADE, related_name="itens")
    produto = models.ForeignKey("Produto", on_delete=models.CASCADE)
    variacao = models.ForeignKey("ProdutoVariacao", on_delete=models.CASCADE, null=True, blank=True)
    quantidade = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    preco_unitario = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(0)])
    data_adicao = models.DateTimeField(auto_now_add=True)
    afiliado_codigo_ref = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        verbose_name = "Item do Carrinho"
        verbose_name_plural = "Itens do Carrinho"
        unique_together = ["carrinho", "produto", "variacao"]
        indexes = [models.Index(fields=["carrinho", "produto", "variacao"])]

    def __str__(self):
        if self.variacao:
            opcoes = ", ".join(self.variacao.opcoes.values_list("valor", flat=True))
            return f"{self.quantidade}x {self.produto.nome} ({opcoes})"
        return f"{self.quantidade}x {self.produto.nome}"

    @property
    def subtotal(self):
        return self.quantidade * self.preco_unitario

    @property
    def imagem_efetiva(self):
        """Retorna a imagem da variação, se houver, ou a imagem principal do produto."""
        if self.variacao and self.variacao.imagem:
            return self.variacao.imagem
        return getattr(self.produto, "imagem_principal", None)

    def save(self, *args, **kwargs):
        if not self.pk:
            self.preco_unitario = self.variacao.preco_efetivo if self.variacao else self.produto.preco
        super().save(*args, **kwargs)

    def clean(self):
        if self.variacao and self.variacao.produto_id != self.produto_id:
            raise ValidationError("A variação não pertence a este produto.")
        if self.produto.has_variacoes and not self.variacao:
            raise ValidationError("Selecione uma variação válida para este produto.")
        estoque_alvo = self.variacao.estoque if self.variacao else self.produto.estoque
        if self.quantidade > estoque_alvo:
            raise ValidationError(f"Quantidade solicitada ({self.quantidade}) maior que estoque ({estoque_alvo})")


from decimal import Decimal
from django.db import models, transaction
from django.db.models import Sum
from django.core.exceptions import ValidationError
from django.urls import reverse
from django.utils import timezone


class Pedido(models.Model):
    STATUS_CHOICES = [
        ("pendente", "Pendente"),
        ("aguardando_pagamento", "Aguardando Pagamento"),
        ("pago", "Pago"),
        ("processando", "Processando"),
        ("enviado", "Enviado"),
        ("entregue", "Entregue"),
        ("cancelado", "Cancelado"),
        ("reembolsado", "Reembolsado"),
    ]

    METODO_PAGAMENTO_CHOICES = [
        ("pix", "PIX"),
        ("cartao_credito", "Cartão de Crédito"),
        ("cartao_debito", "Cartão de Débito"),
        ("boleto", "Boleto Bancário"),
        ("cashback", "Cashback"),
    ]

    usuario = models.ForeignKey("Usuario", on_delete=models.CASCADE, related_name="pedidos")
    numero_pedido = models.CharField(max_length=20, unique=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pendente")
    metodo_pagamento = models.CharField(max_length=20, choices=METODO_PAGAMENTO_CHOICES, blank=True, null=True)

    numero_parcelas = models.PositiveIntegerField(default=1)
    valor_parcela = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    endereco_entrega = models.ForeignKey("EnderecoEntrega", on_delete=models.PROTECT)

    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    valor_frete = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    desconto_cupom = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    desconto_fidelidade = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    pontos_utilizados = models.PositiveIntegerField(default=0)
    valor_pontos_utilizados = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    cashback_utilizado = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2)

    cupom_utilizado = models.ForeignKey(
        "CupomDesconto",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="pedidos_usando",
    )

    pagamento_id_externo = models.CharField(max_length=100, blank=True)
    asaas_customer_id = models.CharField(max_length=100, blank=True, null=True)
    asaas_payment_id = models.CharField(max_length=100, blank=True, null=True)
    asaas_installment_id = models.CharField(max_length=100, blank=True, null=True)
    asaas_invoice_url = models.URLField(max_length=500, blank=True, null=True)
    asaas_payment_url = models.URLField(max_length=500, blank=True, null=True)
    asaas_qr_code = models.TextField(blank=True, null=True)
    asaas_barcode = models.TextField(blank=True, null=True)
    asaas_pix_code = models.TextField(blank=True, null=True)

    PAGAMENTO_STATUS_CHOICES = [
        ("pendente", "Pendente"),
        ("aguardando_confirmacao", "Aguardando Confirmação"),
        ("confirmado", "Confirmado"),
        ("recebido", "Recebido"),
        ("recebido_parcialmente", "Recebido Parcialmente"),
        ("atrasado", "Atrasado"),
        ("recusado", "Recusado"),
        ("reembolsado", "Reembolsado"),
        ("estornado", "Estornado"),
    ]
    pagamento_status = models.CharField(max_length=25, choices=PAGAMENTO_STATUS_CHOICES, default="pendente")

    data_criacao = models.DateTimeField(auto_now_add=True)
    data_pagamento = models.DateTimeField(null=True, blank=True)
    data_envio = models.DateTimeField(null=True, blank=True)
    data_entrega = models.DateTimeField(null=True, blank=True)
    data_cancelamento = models.DateTimeField(null=True, blank=True)
    data_vencimento_boleto = models.DateTimeField(null=True, blank=True)
    data_vencimento_pix = models.DateTimeField(null=True, blank=True)

    codigo_rastreamento = models.CharField(max_length=50, blank=True)
    observacoes = models.TextField(blank=True)

    class Meta:
        verbose_name = "Pedido"
        verbose_name_plural = "Pedidos"
        ordering = ["-data_criacao"]
        indexes = [
            models.Index(fields=["numero_pedido"]),
            models.Index(fields=["usuario", "status"]),
            models.Index(fields=["data_criacao"]),
        ]

    def __str__(self):
        return f"Pedido #{self.numero_pedido}"

    # =========================================================
    # RESGATE (PONTOS / CASHBACK)
    # =========================================================
    def _calcular_base_resgate(self):
        subtotal = Decimal(str(self.subtotal or 0))
        desconto_cupom = Decimal(str(self.desconto_cupom or 0))
        desconto_fidelidade = Decimal(str(self.desconto_fidelidade or 0))
        base = subtotal - desconto_cupom - desconto_fidelidade
        return base if base > 0 else Decimal("0.00")

    def _resgate_fields_alterados(self):
        if not self.pk:
            return True
        antigo = (
            Pedido.objects.filter(pk=self.pk)
            .values("pontos_utilizados", "valor_pontos_utilizados", "cashback_utilizado")
            .first()
        )
        if not antigo:
            return True
        return any(
            [
                antigo["pontos_utilizados"] != self.pontos_utilizados,
                antigo["valor_pontos_utilizados"] != self.valor_pontos_utilizados,
                antigo["cashback_utilizado"] != self.cashback_utilizado,
            ]
        )

    def _validar_limites_resgate(self):
        if self.pontos_utilizados <= 0 and self.cashback_utilizado <= 0:
            return

        config = ConfiguracaoSite.load()
        valor_ponto = Decimal(str(getattr(config, "valor_ponto_em_reais", Decimal("0.01")) or Decimal("0.01")))
        max_percent_pontos = Decimal(str(getattr(config, "max_percentual_pontos_resgate", 100) or 0))
        max_percent_cashback = Decimal(str(getattr(config, "max_percentual_cashback_resgate", 100) or 0))
        min_pontos_resgate = int(getattr(config, "pontos_minimos_resgate", 0) or 0)
        min_cashback_resgate = Decimal(str(getattr(config, "cashback_minimo_resgate", Decimal("0")) or Decimal("0")))

        base_resgate = self._calcular_base_resgate()
        erros = {}

        if self.usuario_id and self.pontos_utilizados > getattr(self.usuario, "pontos_disponiveis", 0):
            erros["pontos_utilizados"] = "Pontos insuficientes para esse resgate."

        if min_pontos_resgate and 0 < self.pontos_utilizados < min_pontos_resgate:
            erros["pontos_utilizados"] = f"Quantidade mínima para usar pontos: {min_pontos_resgate}."

        valor_pontos_solicitado = (Decimal(str(self.pontos_utilizados or 0)) * valor_ponto).quantize(Decimal("0.01"))
        max_valor_pontos = (base_resgate * (max_percent_pontos / Decimal("100"))).quantize(Decimal("0.01"))
        max_valor_pontos = max(Decimal("0.00"), max_valor_pontos)
        if valor_pontos_solicitado > max_valor_pontos:
            erros["pontos_utilizados"] = f"Uso de pontos acima do limite configurado ({int(max_percent_pontos)}%)."

        valor_pontos_aplicados = min(valor_pontos_solicitado, max_valor_pontos).quantize(Decimal("0.01"))

        base_pos_pontos = base_resgate - valor_pontos_aplicados
        base_pos_pontos = base_pos_pontos if base_pos_pontos > 0 else Decimal("0.00")

        cashback_solicitado = Decimal(str(self.cashback_utilizado or 0)).quantize(Decimal("0.01"))
        if cashback_solicitado < 0:
            cashback_solicitado = Decimal("0.00")

        if min_cashback_resgate and Decimal("0.00") < cashback_solicitado < min_cashback_resgate:
            erros["cashback_utilizado"] = f"Valor mínimo de cashback para uso: R$ {min_cashback_resgate:.2f}."

        if self.usuario_id and cashback_solicitado > getattr(self.usuario, "saldo_cashback", Decimal("0.00")):
            erros["cashback_utilizado"] = "Saldo de cashback insuficiente."

        max_cashback_valor = (base_pos_pontos * (max_percent_cashback / Decimal("100"))).quantize(Decimal("0.01"))
        max_cashback_valor = max(Decimal("0.00"), max_cashback_valor)
        if cashback_solicitado > max_cashback_valor:
            erros["cashback_utilizado"] = f"Uso de cashback acima do limite configurado ({int(max_percent_cashback)}%)."

        if erros:
            raise ValidationError(erros)

        self.valor_pontos_utilizados = valor_pontos_aplicados
        self.cashback_utilizado = cashback_solicitado

    # =========================================================
    # SAVE + TRANSIÇÕES
    # =========================================================
    def save(self, *args, **kwargs):
        if not self.numero_pedido:
            self.numero_pedido = self.gerar_numero_pedido()

        if self.metodo_pagamento == "cartao_credito" and self.numero_parcelas > 1 and not self.valor_parcela:
            self.valor_parcela = (Decimal(str(self.total)) / Decimal(str(self.numero_parcelas))).quantize(Decimal("0.01"))

        if self._resgate_fields_alterados():
            self._validar_limites_resgate()

        if self.status == "pago" and not self.data_pagamento:
            self.data_pagamento = timezone.now()
        elif self.status == "enviado" and not self.data_envio:
            self.data_envio = timezone.now()
        elif self.status == "entregue" and not self.data_entrega:
            self.data_entrega = timezone.now()
        elif self.status == "cancelado" and not self.data_cancelamento:
            self.data_cancelamento = timezone.now()

        mudou_para_pago = False
        mudou_para_cancelado_ou_reembolsado = False

        if self.pk:
            try:
                pedido_antigo = Pedido.objects.get(pk=self.pk)

                if pedido_antigo.status != "pago" and self.status == "pago":
                    mudou_para_pago = True

                if pedido_antigo.status not in ["cancelado", "reembolsado"] and self.status in ["cancelado", "reembolsado"]:
                    mudou_para_cancelado_ou_reembolsado = True

            except Pedido.DoesNotExist:
                pass
        else:
            if self.status == "pago":
                mudou_para_pago = True

        super().save(*args, **kwargs)

        if mudou_para_pago:
            # ✅ PRIMEIRO recalcula (para manter consistência geral)
            try:
                self.usuario.recalcular_estatisticas_compras()
            except Exception:
                pass

            # ✅ Agora roda gamificação (não pode dar return cedo)
            self.processar_gamificacao_pos_pagamento()

            try:
                self.usuario.avaliar_badges()
            except Exception:
                pass

            # ✅ comissão afiliado / cashback cupom (idempotente)
            self._processar_comissoes_afiliados()

        if mudou_para_cancelado_ou_reembolsado:
            self.processar_estorno_gamificacao()
            self._estornar_comissoes_afiliados()

            try:
                self.usuario.recalcular_estatisticas_compras()
            except Exception:
                pass

    # =========================================================
    # NÚMERO
    # =========================================================
    def gerar_numero_pedido(self):
        import random
        import string

        timestamp = timezone.now().strftime("%Y%m%d%H%M%S")
        random_str = "".join(random.choices(string.digits, k=4))
        return f"TS{timestamp}{random_str}"

    # =========================================================
    # POS-PAGAMENTO (NÃO pode "return" cedo e bloquear bônus)
    # =========================================================
    def processar_gamificacao_pos_pagamento(self):
        config = ConfiguracaoSite.load()

        # 1) Pontos (idempotente)
        ja_tem_pontos = RegistroPontos.objects.filter(
            pedido=self,
            tipo="adicionar",
            motivo__icontains="Compra",
        ).exists()

        pontos_finais = 0
        if not ja_tem_pontos:
            pontos_por_real = Decimal(str(getattr(config, "pontos_por_real_gasto", Decimal("1.0")) or Decimal("1.0")))
            pontos_base = Decimal(str(self.total or 0)) * pontos_por_real
            multiplicador = Decimal(str(self.usuario.obter_multiplicador_pontos() or 1))
            pontos_finais = int((pontos_base * multiplicador).quantize(Decimal("1")))

            if pontos_finais > 0:
                self.usuario.adicionar_pontos(
                    pontos_finais,
                    motivo=f"Compra - Pedido #{self.numero_pedido} (Nível {self.usuario.nivel_fidelidade.title()})",
                    origem="compra",
                    referencia=self.numero_pedido,
                    pedido=self,
                )
                Notificacao.objects.create(
                    usuario=self.usuario,
                    tipo="pontos",
                    titulo="Você ganhou pontos!",
                    mensagem=f"Sua compra #{self.numero_pedido} rendeu {pontos_finais} pontos.",
                    link="/minha-conta/pontos/",
                )

        # 2) Cashback da compra (idempotente)
        self._processar_cashback_ganho(config)

        # 3) Bônus de indicação (1ª compra) (idempotente e robusto)
        self._processar_bonus_indicacao(config)

        # 4) Analytics (idempotente simples)
        try:
            AnaliticsEvento.objects.create(
                usuario=self.usuario,
                tipo_evento="completar_compra",
                pedido=self,
                dados_adicionais={"valor": float(self.total), "pontos_ganhos": int(pontos_finais)},
            )
        except Exception:
            pass

    def _processar_cashback_ganho(self, config):
        # Idempotência: não creditar duas vezes o cashback da compra
        ref_cb = f"CB-{self.numero_pedido}"
        if RegistroCashback.objects.filter(usuario=self.usuario, referencia=ref_cb).exists():
            return

        total_cashback = Decimal("0.00")
        for item in self.itens.all():
            pct_cashback = (
                item.variacao.percentual_cashback
                if (item.variacao and item.variacao.percentual_cashback is not None)
                else item.produto.percentual_cashback
            )
            pct_cashback = Decimal(str(pct_cashback or 0))
            if pct_cashback > 0:
                valor_cb = (Decimal(str(item.subtotal or 0)) * (pct_cashback / Decimal("100"))).quantize(Decimal("0.01"))
                total_cashback += valor_cb

        if total_cashback == 0 and config and getattr(config, "cashback_automatico", False):
            pct_padrao = Decimal(str(getattr(config, "percentual_cashback_padrao", 0) or 0))
            total_cashback = (Decimal(str(self.total or 0)) * (pct_padrao / Decimal("100"))).quantize(Decimal("0.01"))

        if total_cashback > 0:
            self.usuario.adicionar_cashback(
                total_cashback,
                origem="cashback_compra",
                motivo=f"Cashback da compra #{self.numero_pedido}",
                referencia=ref_cb,
                pedido=self,
            )
            Notificacao.objects.create(
                usuario=self.usuario,
                tipo="promocao",
                titulo="Cashback Disponível!",
                mensagem=f"R$ {total_cashback:.2f} voltaram para sua carteira.",
            )

    # =========================================================
    # BÔNUS DE INDICAÇÃO - PADRINHO E NOVO USUÁRIO (1ª compra)
    # =========================================================
    def _processar_bonus_indicacao(self, config):
        # Precisa ter padrinho para existir bônus de indicação
        comprador = self.usuario
        padrinho = getattr(comprador, "referido_por", None)
        if not padrinho:
            return

        # Só faz sentido com pedido pago e confirmado/recebido
        if self.status != "pago":
            return
        if self.pagamento_status not in {"confirmado", "recebido", "recebido_parcialmente"}:
            return

        # PRIMEIRA compra robusta: se já existia outro pedido pago/enviado/entregue, não é primeira
        ja_tinha_compra_paga = Pedido.objects.filter(
            usuario=comprador,
            status__in=["pago", "enviado", "entregue"],
        ).exclude(pk=self.pk).exists()
        if ja_tinha_compra_paga:
            return

        bonus_pad = Decimal(str(getattr(config, "bonus_referencia_referidor", 0) or 0)).quantize(Decimal("0.01"))
        bonus_novo = Decimal(str(getattr(config, "bonus_referencia_novo", 0) or 0)).quantize(Decimal("0.01"))

        ref_pad = f"REF1-PAD-{self.numero_pedido}"
        ref_novo = f"REF1-NOVO-{self.numero_pedido}"

        # Padrinho
        if bonus_pad > 0 and not RegistroCashback.objects.filter(usuario=padrinho, referencia=ref_pad).exists():
            padrinho.adicionar_cashback(
                bonus_pad,
                origem="bonus_indicacao",
                motivo=f"Indicação: {comprador.first_name} fez a primeira compra (Pedido #{self.numero_pedido})",
                referencia=ref_pad,
                pedido=self,
            )
            Notificacao.objects.create(
                usuario=padrinho,
                tipo="fidelidade",
                titulo="Indicação convertida!",
                mensagem=f"Sua indicação {comprador.first_name} comprou. Você ganhou R$ {bonus_pad:.2f}.",
            )

        # Novo usuário
        if bonus_novo > 0 and not RegistroCashback.objects.filter(usuario=comprador, referencia=ref_novo).exists():
            comprador.adicionar_cashback(
                bonus_novo,
                origem="bonus_indicacao",
                motivo=f"Bônus de indicação (1ª compra) - Pedido #{self.numero_pedido}",
                referencia=ref_novo,
                pedido=self,
            )
            Notificacao.objects.create(
                usuario=comprador,
                tipo="promocao",
                titulo="Bônus de indicação!",
                mensagem=f"Você ganhou R$ {bonus_novo:.2f} na sua primeira compra.",
            )

        # Atualiza contador do padrinho (opcional)
        try:
            padrinho.atualizar_total_referencias()
        except Exception:
            try:
                padrinho.total_referencias = (padrinho.total_referencias or 0) + 1
                padrinho.save(update_fields=["total_referencias"])
            except Exception:
                pass

    # =========================================================
    # PAGAMENTO CONFIRMADO (GATILHO IDEAL)
    # =========================================================
    def processar_pagamento_confirmado(self):
        if self.status != "pago":
            self.status = "pago"
            self.pagamento_status = "confirmado"
            self.data_pagamento = timezone.now()

            for item in self.itens.select_related("variacao", "produto").all():
                produto = item.produto
                if item.variacao:
                    item.variacao.estoque -= item.quantidade
                    item.variacao.save()
                    produto.vendas_totais += item.quantidade
                    produto.save(update_fields=["vendas_totais"])
                else:
                    produto.estoque -= item.quantidade
                    produto.vendas_totais += item.quantidade
                    produto.save()

            self.save()

            try:
                HistoricoStatusPedido.objects.create(
                    pedido=self,
                    status_anterior="aguardando_pagamento",
                    status_novo="pago",
                    observacao="Pagamento confirmado via integração",
                )
            except Exception:
                pass

    # =========================================================
    # AFILIADOS (COMISSÃO POR ITEM) + BONUS CUPOM (PÓS-PAGAMENTO)
    # =========================================================
    def _processar_comissoes_afiliados(self):
        config = ConfiguracaoSite.load()

        # ✅ somente pago + confirmado/recebido
        if self.status != "pago":
            return
        if self.pagamento_status not in {"confirmado", "recebido", "recebido_parcialmente"}:
            return

        # ---------------------------------------------------------
        # ✅ Cashback bônus do cupom (NÃO depende de afiliado_ativo)
        # ---------------------------------------------------------
        try:
            cupom = getattr(self, "cupom_utilizado", None)
            pct_bonus = Decimal(str(getattr(cupom, "ativar_cashback_bonus", 0) or 0)).quantize(Decimal("0.01")) if cupom else Decimal("0.00")

            if cupom and pct_bonus > 0:
                base_bonus = Decimal(str(self.total or 0)).quantize(Decimal("0.01"))
                cashback_bonus = (base_bonus * (pct_bonus / Decimal("100.00"))).quantize(Decimal("0.01"))

                ref_cb = f"CUPCB-{self.numero_pedido}"
                if cashback_bonus > 0 and not RegistroCashback.objects.filter(usuario=self.usuario, referencia=ref_cb).exists():
                    self.usuario.adicionar_cashback(
                        cashback_bonus,
                        origem="bonus_cupom",
                        motivo=f"Cashback bônus do cupom {cupom.codigo} (Pedido #{self.numero_pedido})",
                        referencia=ref_cb,
                        pedido=self,
                    )
                    Notificacao.objects.create(
                        usuario=self.usuario,
                        tipo="promocao",
                        titulo="Cashback bônus liberado",
                        mensagem=f"Você recebeu R$ {cashback_bonus:.2f} de cashback bônus pelo cupom {cupom.codigo}.",
                        link=reverse("meus_pedidos"),
                    )
        except Exception:
            pass

        # ---------------------------------------------------------
        # ✅ Comissão afiliado (depende de afiliado_ativo)
        # ---------------------------------------------------------
        if not getattr(config, "afiliado_ativo", True):
            return

        def clamp_pct(pct):
            try:
                v = Decimal(str(pct or 0))
            except Exception:
                v = Decimal("0")
            return max(Decimal("0"), min(Decimal("100"), v))

        total_pedido = Decimal(str(self.total or 0)).quantize(Decimal("0.01"))
        min_pedido = Decimal(str(getattr(config, "afiliado_min_pedido", Decimal("0.00")) or 0)).quantize(Decimal("0.01"))
        if total_pedido < min_pedido:
            return

        itens = list(self.itens.select_related("produto").all())
        if not itens:
            return

        subtotal_itens = sum((Decimal(str(i.subtotal or 0)) for i in itens), Decimal("0.00")).quantize(Decimal("0.01"))
        if subtotal_itens <= 0:
            return

        desconto_total = (Decimal(str(self.desconto_cupom or 0)) + Decimal(str(self.desconto_fidelidade or 0))).quantize(Decimal("0.01"))
        desconto_rate = (desconto_total / subtotal_itens) if (desconto_total > 0 and subtotal_itens > 0) else Decimal("0.00")
        desconto_rate = max(Decimal("0.00"), min(Decimal("1.00"), desconto_rate))

        base_calc = getattr(config, "afiliado_base_calculo", "itens") or "itens"
        teto_por_pedido = Decimal(str(getattr(config, "afiliado_max_comissao_por_pedido", Decimal("0.00")) or 0)).quantize(Decimal("0.01"))
        comissao_acumulada = Decimal("0.00")

        for item in itens:
            codigo_ref = (getattr(item, "afiliado_codigo_ref", None) or "").strip().upper()
            if not codigo_ref:
                continue

            referidor = Usuario.objects.filter(codigo_referencia=codigo_ref).first()
            if not referidor or referidor.id == self.usuario_id:
                continue

            pct_item = getattr(item.produto, "comissao_afiliado_pct", None)
            if pct_item is None:
                pct_item = getattr(config, "afiliado_comissao_padrao", Decimal("10.00"))
            pct_item = clamp_pct(pct_item)

            base_item = Decimal(str(item.subtotal or 0)).quantize(Decimal("0.01"))
            if base_item <= 0:
                continue

            if base_calc == "itens_desconto_rateado" and desconto_total > 0:
                base_item = (base_item * (Decimal("1.00") - desconto_rate)).quantize(Decimal("0.01"))

            valor_comissao = (base_item * (pct_item / Decimal("100.00"))).quantize(Decimal("0.01"))
            if valor_comissao <= 0:
                continue

            if teto_por_pedido and teto_por_pedido > 0:
                restante = (teto_por_pedido - comissao_acumulada).quantize(Decimal("0.01"))
                if restante <= 0:
                    break
                if valor_comissao > restante:
                    valor_comissao = restante

            referencia = f"AFI-{self.numero_pedido}-{item.id}"
            if RegistroCashback.objects.filter(usuario=referidor, referencia=referencia).exists():
                continue

            with transaction.atomic():
                referidor.adicionar_cashback(
                    valor_comissao,
                    origem="comissao",
                    motivo=f"Comissão afiliado (Pedido #{self.numero_pedido}) - {item.nome_produto}",
                    referencia=referencia,
                    pedido=self,
                )

                Notificacao.objects.create(
                    usuario=referidor,
                    tipo="fidelidade",
                    titulo="Comissão de Afiliado",
                    mensagem=f"Você ganhou R$ {valor_comissao:.2f} por indicar uma venda!",
                    link=reverse("registros_cashback"),
                )

            comissao_acumulada += valor_comissao

    # =========================================================
    # ESTORNO DE COMISSÕES (CANCELADO/REEMBOLSADO)
    # =========================================================
    def _estornar_comissoes_afiliados(self):
        config = ConfiguracaoSite.load()
        if not getattr(config, "afiliado_ativo", True):
            return

        creditos = RegistroCashback.objects.filter(
            pedido=self,
            tipo="credito",
            referencia__startswith=f"AFI-{self.numero_pedido}-",
        ).select_related("usuario")

        if not creditos.exists():
            return

        for reg in creditos:
            afiliado = reg.usuario
            valor_creditado = Decimal(str(getattr(reg, "valor", 0) or 0)).quantize(Decimal("0.01"))
            if valor_creditado <= 0:
                continue

            ref_estorno = f"{reg.referencia}-ESTORNO"
            if RegistroCashback.objects.filter(usuario=afiliado, referencia=ref_estorno).exists():
                continue

            saldo = Decimal(str(getattr(afiliado, "saldo_cashback", 0) or 0)).quantize(Decimal("0.01"))
            valor_estornar = min(valor_creditado, saldo)

            if valor_estornar <= 0:
                try:
                    Notificacao.objects.create(
                        usuario=afiliado,
                        tipo="alerta",
                        titulo="Estorno de Comissão",
                        mensagem=f"O pedido #{self.numero_pedido} foi cancelado/reembolsado, mas você não tem saldo para estornar a comissão (R$ {valor_creditado:.2f}).",
                    )
                except Exception:
                    pass
                continue

            try:
                afiliado.usar_cashback(
                    valor_estornar,
                    origem="estorno_comissao",
                    motivo=f"Estorno comissão afiliado - Pedido #{self.numero_pedido}",
                    referencia=ref_estorno,
                    pedido=self,
                )

                Notificacao.objects.create(
                    usuario=afiliado,
                    tipo="alerta",
                    titulo="Estorno de Comissão",
                    mensagem=f"O pedido #{self.numero_pedido} foi cancelado/reembolsado. Comissão estornada: R$ {valor_estornar:.2f}.",
                )
            except Exception:
                pass

    # =========================================================
    # CANCELAR
    # =========================================================
    def cancelar(self, motivo=""):
        if self.status in ["pago", "processando", "enviado"]:
            for item in self.itens.select_related("variacao", "produto").all():
                produto = item.produto
                if item.variacao:
                    item.variacao.estoque += item.quantidade
                    item.variacao.save()
                    produto.vendas_totais = max(0, produto.vendas_totais - item.quantidade)
                    produto.save(update_fields=["vendas_totais"])
                else:
                    produto.estoque += item.quantidade
                    produto.vendas_totais = max(0, produto.vendas_totais - item.quantidade)
                    produto.save()

        self.status = "cancelado"
        self.data_cancelamento = timezone.now()
        self.save()


        



from decimal import Decimal
from django.db import models


class ItemPedido(models.Model):
    pedido = models.ForeignKey("Pedido", on_delete=models.CASCADE, related_name="itens")
    produto = models.ForeignKey("Produto", on_delete=models.PROTECT)
    variacao = models.ForeignKey("ProdutoVariacao", on_delete=models.PROTECT, null=True, blank=True)

    quantidade = models.PositiveIntegerField()
    preco_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)

    # snapshots
    nome_produto = models.CharField(max_length=200)
    sku_produto = models.CharField(max_length=100, blank=True)
    marca_produto = models.CharField(max_length=100, blank=True)
    imagem_produto = models.CharField(max_length=500, blank=True)
    variacao_opcoes = models.CharField(max_length=300, blank=True)

    # ✅ afiliado por produto (copiado do carrinho na criação do pedido)
    afiliado_codigo_ref = models.CharField(
        max_length=20, blank=True, null=True, db_index=True,
        help_text="Código de referência do afiliado responsável por este item (ex.: REFUSER123)."
    )

    class Meta:
        verbose_name = "Item do Pedido"
        verbose_name_plural = "Itens do Pedido"
        indexes = [
            models.Index(fields=["pedido", "produto", "variacao"]),
            models.Index(fields=["pedido", "afiliado_codigo_ref"]),
        ]

    def __str__(self):
        return f"{self.quantidade}x {self.nome_produto}"

    def save(self, *args, **kwargs):
        # Normalização do código de afiliado (consistência para lookup)
        if self.afiliado_codigo_ref:
            self.afiliado_codigo_ref = str(self.afiliado_codigo_ref).strip().upper()

        # Snapshots mínimos
        if not self.nome_produto:
            self.nome_produto = getattr(self.produto, "nome", "") or ""

        if not self.sku_produto:
            if self.variacao and getattr(self.variacao, "sku", ""):
                self.sku_produto = self.variacao.sku
            else:
                self.sku_produto = getattr(self.produto, "sku", "") or ""

        if not self.marca_produto:
            # opcional: se você tiver produto.marca ou produto.marca.nome
            marca = getattr(self.produto, "marca", None)
            self.marca_produto = getattr(marca, "nome", "") if marca else ""

        if self.variacao and not self.variacao_opcoes:
            # evita quebrar caso não exista relação "opcoes"
            opcoes_qs = getattr(self.variacao, "opcoes", None)
            if opcoes_qs is not None:
                try:
                    self.variacao_opcoes = ", ".join(opcoes_qs.values_list("valor", flat=True))
                except Exception:
                    self.variacao_opcoes = ""

        if not self.imagem_produto:
            imagem = None
            if self.variacao:
                imagem = getattr(self.variacao, "imagem_efetiva", None)
            if not imagem:
                imagem = getattr(self.produto, "imagem_principal", None)

            if imagem:
                try:
                    self.imagem_produto = imagem.url
                except Exception:
                    self.imagem_produto = str(imagem)

        # subtotal consistente
        qtd = Decimal(str(self.quantidade or 0))
        pu = self.preco_unitario if self.preco_unitario is not None else Decimal("0.00")
        self.subtotal = (qtd * pu).quantize(Decimal("0.01"))

        super().save(*args, **kwargs)



class HistoricoStatusPedido(models.Model):
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE, related_name="historico_status")
    status_anterior = models.CharField(maxlength=20) if False else models.CharField(max_length=20)
    status_novo = models.CharField(max_length=20)
    observacao = models.TextField(blank=True)
    responsavel = models.CharField(max_length=100, default="sistema")
    data_mudanca = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Histórico de Status"
        verbose_name_plural = "Históricos de Status"
        ordering = ["-data_mudanca"]
        indexes = [models.Index(fields=["pedido", "data_mudanca"])]

    def __str__(self):
        return f"{self.pedido.numero_pedido}: {self.status_anterior} → {self.status_novo}"


# ═══════════════════════════════════════════════════════════════════════════
# 8. NOTIFICAÇÕES E WISHLIST
# ═══════════════════════════════════════════════════════════════════════════
class Notificacao(models.Model):
    TIPO_CHOICES = [
        ("pedido", "Pedido"),
        ("pagamento", "Pagamento"),
        ("cupom", "Cupom"),
        ("pontos", "Pontos"),
        ("fidelidade", "Fidelidade"),
        ("promocao", "Promoção"),
        ("sistema", "Sistema"),
    ]

    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="notificacoes")
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES)
    titulo = models.CharField(max_length=200)
    mensagem = models.TextField()
    lida = models.BooleanField(default=False)
    icone = models.CharField(max_length=50, blank=True, help_text="Ícone emoji ou icon name")
    link = models.URLField(blank=True)
    data_criacao = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Notificação"
        verbose_name_plural = "Notificações"
        ordering = ["-data_criacao"]
        indexes = [models.Index(fields=["usuario", "lida"])]

    def __str__(self):
        return f"{self.titulo} - {self.usuario.email}"

    def marcar_como_lida(self):
        self.lida = True
        self.save()


class Wishlist(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name="wishlist")
    produtos = models.ManyToManyField("Produto", related_name="wishlists", blank=True)
    data_criacao = models.DateTimeField(auto_now_add=True)
    data_atualizacao = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Lista de Desejos"
        verbose_name_plural = "Listas de Desejos"

    def __str__(self):
        return f"Wishlist de {self.usuario.get_full_name()}"

    @property
    def total_itens(self):
        return self.produtos.count()

    def adicionar_produto(self, produto):
        if not self.produtos.filter(id=produto.id).exists():
            self.produtos.add(produto)

    def remover_produto(self, produto):
        self.produtos.remove(produto)

    def limpar(self):
        self.produtos.clear()


class HistoricoVisualizacao(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="historico_visualizacoes")
    produto = models.ForeignKey("Produto", on_delete=models.CASCADE)
    data_visualizacao = models.DateTimeField(auto_now_add=True)
    contador = models.PositiveIntegerField(default=1)

    class Meta:
        verbose_name = "Histórico de Visualização"
        verbose_name_plural = "Históricos de Visualização"
        ordering = ["-data_visualizacao"]
        unique_together = ["usuario", "produto"]
        indexes = [models.Index(fields=["usuario", "data_visualizacao"])]

    def __str__(self):
        return f"{self.usuario.email} - {self.produto.nome}"

    def incrementar(self):
        self.contador += 1
        self.data_visualizacao = timezone.now()
        self.save()


# ═══════════════════════════════════════════════════════════════════════════
# 9. CATEGORIAS, MARCAS E PRODUTOS
# ═══════════════════════════════════════════════════════════════════════════
class Categoria(models.Model):
    nome = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True, blank=True)
    icone = models.ImageField(upload_to="icones_categoria/", blank=True, null=True, help_text="Icone 60x60px")
    descricao = models.TextField(blank=True)
    ativa = models.BooleanField(default=True)
    ordem = models.PositiveIntegerField(default=0)
    destaque_mega_menu = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Categoria"
        verbose_name_plural = "Categorias"
        ordering = ["ordem", "nome"]
        indexes = [models.Index(fields=["slug", "ativa"])]

    def __str__(self):
        return self.nome

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nome)
        super().save(*args, **kwargs)

    @property
    def contar_produtos_ativos(self):
        return self.produtos.filter(disponivel=True, estoque__gt=0).count()


class Marca(models.Model):
    nome = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True, blank=True)
    logo = models.ImageField(upload_to="marcas/", blank=True, null=True, help_text="Logo 100x40px")
    ativa = models.BooleanField(default=True)
    ordem = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "Marca Parceira"
        verbose_name_plural = "Marcas Parceiras"
        ordering = ["ordem", "nome"]
        indexes = [models.Index(fields=["slug", "ativa"])]

    def __str__(self):
        return self.nome

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nome)
        super().save(*args, **kwargs)


class AtributoProduto(models.Model):
    nome = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(max_length=60, unique=True, blank=True)

    class Meta:
        verbose_name = "Atributo de Produto"
        verbose_name_plural = "Atributos de Produto"
        ordering = ["nome"]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nome)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nome


class OpcaoAtributo(models.Model):
    atributo = models.ForeignKey(AtributoProduto, on_delete=models.CASCADE, related_name="opcoes")
    valor = models.CharField(max_length=80)
    slug = models.SlugField(max_length=100, blank=True)

    class Meta:
        verbose_name = "Opção de Atributo"
        verbose_name_plural = "Opções de Atributo"
        unique_together = [("atributo", "valor")]
        ordering = ["atributo__nome", "valor"]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(f"{self.atributo.nome}-{self.valor}")
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.atributo.nome}: {self.valor}"


import uuid
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.exceptions import ValidationError
from django.utils.text import slugify
from django.utils import timezone
from django.db.models import Sum, Avg

# Primeiro, defina os modelos auxiliares ANTES de ProdutoVariacao

class ProdutoVariacaoImagem(models.Model):
    variacao = models.ForeignKey(
        'ProdutoVariacao', 
        on_delete=models.CASCADE, 
        related_name="imagens_variacao"
    )
    imagem = models.ImageField(
        upload_to="produtos/variacoes/galeria/%Y/%m/",
        verbose_name="Imagem da Variação"
    )
    ordem = models.PositiveIntegerField(default=0, verbose_name="Ordem")
    legenda = models.CharField(max_length=200, blank=True, verbose_name="Legenda")
    is_principal = models.BooleanField(default=False, verbose_name="Imagem principal")
    
    class Meta:
        verbose_name = "Imagem da Variação"
        verbose_name_plural = "Imagens da Variação"
        ordering = ["ordem", "id"]
        indexes = [models.Index(fields=["variacao", "ordem"])]
    
    def __str__(self):
        return f"Imagem de {self.variacao.produto.nome} - Variação {self.variacao.id}"
    
    def save(self, *args, **kwargs):
        # Se esta imagem for marcada como principal, desmarque outras
        if self.is_principal and self.variacao_id:
            ProdutoVariacaoImagem.objects.filter(
                variacao=self.variacao
            ).exclude(id=self.id).update(is_principal=False)
        
        super().save(*args, **kwargs)
        
        # Se for a primeira imagem e não houver principal, torne-a principal
        if not self.is_principal and not ProdutoVariacaoImagem.objects.filter(
            variacao=self.variacao, is_principal=True
        ).exists():
            self.is_principal = True
            self.save(update_fields=["is_principal"])

# Agora o modelo ProdutoVariacao atualizado
class ProdutoVariacao(models.Model):
    produto = models.ForeignKey("Produto", on_delete=models.CASCADE, related_name="variacoes")
    opcoes = models.ManyToManyField(OpcaoAtributo, related_name="variacoes")
    sku = models.CharField(max_length=100, unique=True, blank=True, verbose_name="SKU da variação", help_text="Obrigatório; se vazio, geramos automaticamente.")
    barcode_gtin = models.CharField(max_length=50, blank=True, verbose_name="Código de barras/GTIN")
    slug = models.SlugField(max_length=220, blank=True)

    preco = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Se vazio, usa preço do produto")
    preco_promocional = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    estoque = models.IntegerField(default=0, verbose_name="Estoque da variação")
    estoque_minimo = models.IntegerField(default=0, verbose_name="Estoque mínimo (alerta)")
    peso_gramas = models.PositiveIntegerField(default=0, verbose_name="Peso (g)", help_text="Obrigatório em gramas para frete.")
    largura_cm = models.PositiveIntegerField(default=0, verbose_name="Largura (cm)", help_text="Obrigatório em centímetros.")
    altura_cm = models.PositiveIntegerField(default=0, verbose_name="Altura (cm)", help_text="Obrigatório em centímetros.")
    profundidade_cm = models.PositiveIntegerField(default=0, verbose_name="Profundidade (cm)", help_text="Obrigatório em centímetros.")
    
    # Imagem principal (legado - para compatibilidade)
    imagem = models.ImageField(upload_to="produtos/variacoes/%Y/%m/", blank=True, null=True, verbose_name="Imagem principal (legado)", help_text="Imagem principal da variação. Se quiser múltiplas imagens, use a galeria abaixo.")

    percentual_cashback = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)

    class Meta:
        verbose_name = "Variação de Produto"
        verbose_name_plural = "Variações de Produto"
        ordering = ["produto__nome", "id"]

    def __str__(self):
        if not self.pk:
            return f"Variação de {self.produto.nome if self.produto_id else 'Produto'} (nova)"
        opcoes_txt = ", ".join(self.opcoes.values_list("valor", flat=True))
        if opcoes_txt:
            return f"{self.produto.nome} ({opcoes_txt})"
        sku_label = self.sku or "variação"
        return f"{self.produto.nome} ({sku_label})"

    def save(self, *args, **kwargs):
        creating = self._state.adding
        if not self.sku:
            self.sku = str(uuid.uuid4())[:10].upper()

        if not self.slug and not creating:
            combinacao = "-".join(self.opcoes.values_list("slug", flat=True))
            self.slug = slugify(f"{self.produto.slug}-{combinacao or self.sku}")

        super().save(*args, **kwargs)

        if creating and not self.slug:
            try:
                combinacao = "-".join(self.opcoes.values_list("slug", flat=True))
            except ValueError:
                combinacao = ""
            if combinacao:
                self.slug = slugify(f"{self.produto.slug}-{combinacao or self.sku}")
                super().save(update_fields=["slug"])

    def clean(self):
        erros = {}
        if self.produto and self.produto.has_variacoes:
            if self.peso_gramas <= 0:
                erros["peso_gramas"] = "Informe o peso em gramas para esta variação."
            if self.largura_cm <= 0 or self.altura_cm <= 0 or self.profundidade_cm <= 0:
                erros["largura_cm"] = "Informe largura/altura/profundidade em cm para esta variação."
        if self.estoque < 0:
            erros["estoque"] = "Estoque não pode ser negativo."
        if self.estoque_minimo < 0:
            erros["estoque_minimo"] = "Estoque mínimo não pode ser negativo."
        if erros:
            raise ValidationError(erros)

    @property
    def especificacoes_dict(self):
        return {
            "opcoes": ", ".join(self.opcoes.values_list("valor", flat=True)),
            "sku": self.sku,
            "peso_gramas": self.peso_gramas,
            "largura_cm": self.largura_cm,
            "altura_cm": self.altura_cm,
            "profundidade_cm": self.profundidade_cm,
        }

    @property
    def preco_efetivo(self):
        if self.preco_promocional and self.preco_promocional > 0:
            return self.preco_promocional
        if self.preco and self.preco > 0:
            return self.preco
        return self.produto.preco

    @property
    def cashback_pct(self):
        return self.percentual_cashback if self.percentual_cashback is not None else self.produto.percentual_cashback

    @property
    def disponivel(self):
        return self.estoque > 0

    # PROPRIEDADES PARA GERENCIAMENTO DE IMAGENS
    @property
    def imagem_principal(self):
        """
        Retorna a imagem principal da variação.
        Prioridade: 1) imagem principal da galeria, 2) imagem legada, 3) imagem do produto
        """
        # Busca imagem principal na galeria
        principal = self.imagens_variacao.filter(is_principal=True).first()
        if principal:
            return principal.imagem
        
        # Fallback para imagem legada
        if self.imagem:
            return self.imagem
        
        # Fallback para imagem do produto
        return getattr(self.produto, "imagem_principal", None)

    @property
    def galeria_imagens(self):
        """Retorna todas as imagens da variação em ordem"""
        return self.imagens_variacao.all().order_by('ordem')

    @property
    def tem_imagens(self):
        """Verifica se a variação tem imagens"""
        return self.imagens_variacao.exists() or bool(self.imagem)

    def adicionar_imagem(self, imagem, legenda="", is_principal=False):
        """Método auxiliar para adicionar imagens à variação"""
        if not self.pk:
            raise ValueError("A variação precisa ser salva antes de adicionar imagens")
        
        # Determina a ordem
        ultima_ordem = self.imagens_variacao.aggregate(models.Max('ordem'))['ordem__max'] or 0
        
        return ProdutoVariacaoImagem.objects.create(
            variacao=self,
            imagem=imagem,
            legenda=legenda,
            ordem=ultima_ordem + 1,
            is_principal=is_principal
        )

    @property
    def imagem_efetiva(self):
        """Alias para compatibilidade com código existente"""
        return self.imagem_principal

# O restante do modelo Produto permanece igual...
class Produto(models.Model):
    categoria = models.ForeignKey(Categoria, on_delete=models.SET_NULL, related_name="produtos", null=True)
    marca = models.ForeignKey(Marca, on_delete=models.SET_NULL, related_name="produtos", null=True, blank=True)

    nome = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True, blank=True)
    sku = models.CharField(max_length=100, unique=True, blank=True)

    descricao_resumida = models.CharField(max_length=200)
    descricao_completa = models.TextField()
    especificacoes = models.TextField(blank=True, default="", help_text="Use texto simples, ex: Peso: 1kg; Sabor: Chocolate")

    sabor = models.CharField(max_length=100, blank=True)
    peso = models.CharField(max_length=50, blank=True)
    tipo_proteina = models.CharField(max_length=100, blank=True)

    imagem_principal = models.ImageField(upload_to="produtos/%Y/%m/", help_text="300x300px")
    imagem_hover = models.ImageField(upload_to="produtos/%Y/%m/", blank=True, null=True, help_text="300x300px (hover)")
    galeria_imagens = models.ManyToManyField("ProdutoImagem", blank=True, related_name="produtos_com_esta_imagem")

    preco = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(0)])
    preco_antigo = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(0)])
    custo = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(0)])

    preco_em_pontos = models.PositiveIntegerField(default=0, verbose_name="Preço em Pontos (Resgate)")

    estoque = models.IntegerField(default=0)
    estoque_minimo = models.IntegerField(default=5)
    disponivel = models.BooleanField(default=True)
    has_variacoes = models.BooleanField(default=False, verbose_name="Possui variações")

    vendas_totais = models.IntegerField(default=0)
    visualizacoes = models.IntegerField(default=0)

    avaliacao_media = models.DecimalField(max_digits=3, decimal_places=2, default=0, validators=[MinValueValidator(0), MaxValueValidator(5)])
    numero_avaliacoes = models.IntegerField(default=0)

    is_novo = models.BooleanField(default=False)
    is_kit = models.BooleanField(default=False)
    is_destaque = models.BooleanField(default=False)
    is_mais_vendido = models.BooleanField(default=False)

    is_oferta_relampago = models.BooleanField(default=False)
    unidades_vendidas_oferta = models.IntegerField(default=0)
    limite_estoque_oferta = models.IntegerField(default=100)
    fim_oferta = models.DateTimeField(null=True, blank=True)

    meta_titulo = models.CharField(max_length=200, blank=True)
    meta_descricao = models.TextField(blank=True)
    palavras_chave = models.CharField(max_length=300, blank=True)

    percentual_cashback = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name="Cashback % ao Comprar")

    data_criacao = models.DateTimeField(auto_now_add=True)
    data_atualizacao = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Produto"
        verbose_name_plural = "Produtos"
        ordering = ["-data_criacao"]
        indexes = [
            models.Index(fields=["slug", "disponivel"]),
            models.Index(fields=["categoria", "disponivel"]),
            models.Index(fields=["is_destaque", "disponivel"]),
        ]

    def __str__(self):
        return f"{self.nome} - {self.marca.nome if self.marca else 'Sem Marca'}"

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nome)
        if not self.sku:
            self.sku = str(uuid.uuid4())[:8].upper()
        if self.has_variacoes and self.pk:
            self.disponivel = self.variacoes.filter(estoque__gt=0).exists()
        elif self.estoque <= 0:
            self.disponivel = False
        if not self.meta_titulo:
            self.meta_titulo = self.nome
        super().save(*args, **kwargs)

    @property
    def em_promocao(self):
        return self.preco_antigo and self.preco_antigo > self.preco

    @property
    def percentual_desconto(self):
        if self.em_promocao:
            try:
                desconto = float(self.preco_antigo) - float(self.preco)
                percentual = (desconto / float(self.preco_antigo)) * 100
                return int(percentual)
            except Exception:
                return 0
        return 0

    @property
    def estoque_baixo(self):
        if self.has_variacoes:
            estoque_total = self.variacoes.aggregate(total=Sum("estoque"))["total"] or 0
            return estoque_total <= self.estoque_minimo
        return self.estoque <= self.estoque_minimo

    @property
    def oferta_ativa(self):
        if self.is_oferta_relampago and self.fim_oferta:
            return self.disponivel and self.estoque > 0 and timezone.now() < self.fim_oferta
        return False

    @property
    def unidades_restantes_oferta(self):
        if self.oferta_ativa:
            return max(0, self.limite_estoque_oferta - self.unidades_vendidas_oferta)
        return 0

    def atualizar_avaliacoes_cache(self):
        avaliacoes = self.avaliacoes.filter(aprovado=True)
        total = avaliacoes.count()
        if total > 0:
            media = avaliacoes.aggregate(Avg("avaliacao"))["avaliacao__avg"]
            self.avaliacao_media = round(media, 2)
        else:
            self.avaliacao_media = 0
        self.numero_avaliacoes = total
        self.save(update_fields=["avaliacao_media", "numero_avaliacoes"])

    def registrar_venda(self, quantidade):
        self.estoque -= quantidade
        self.vendas_totais += quantidade
        if self.is_oferta_relampago:
            self.unidades_vendidas_oferta += quantidade
        self.save()

    def registrar_visualizacao(self):
        self.visualizacoes += 1
        self.save()

    @property
    def preco_base(self):
        return self.preco

    @property
    def estoque_disponivel(self):
        if self.has_variacoes:
            return self.variacoes.aggregate(total=Sum("estoque"))["total"] or 0
        return self.estoque

    def variacao_padrao(self):
        if not self.has_variacoes:
            return None
        return self.variacoes.filter(estoque__gt=0).first()

    def get_link_afiliado(self, usuario):
        """Gera link de divulgação para afiliados, combinando código de referência do usuário e SKU do produto."""
        from django.urls import reverse
        base_url = reverse('produto_detalhe', kwargs={'slug': self.slug})
        return f"{base_url}?ref={usuario.codigo_referencia}&sku={self.sku}"

class ProdutoImagem(models.Model):
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE, related_name="imagens_adicionais")
    imagem = models.ImageField(upload_to="produtos/galeria/%Y/%m/")
    ordem = models.PositiveIntegerField(default=0)
    legenda = models.CharField(max_length=200, blank=True)

    class Meta:
        verbose_name = "Imagem do Produto"
        verbose_name_plural = "Imagens do Produto"
        ordering = ["ordem"]
        indexes = [models.Index(fields=["produto", "ordem"])]

    def __str__(self):
        return f"Imagem de {self.produto.nome}"


# ═══════════════════════════════════════════════════════════════════════════
# 10. AVALIAÇÕES E DEPOIMENTOS
# ═══════════════════════════════════════════════════════════════════════════
class AvaliacaoProduto(models.Model):
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE, related_name="avaliacoes")
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="avaliacoes", null=True, blank=True)
    pedido = models.ForeignKey("Pedido", on_delete=models.SET_NULL, null=True, blank=True, related_name="avaliacoes")
    item_pedido = models.ForeignKey("ItemPedido", on_delete=models.SET_NULL, null=True, blank=True, related_name="avaliacoes")
    nome_cliente = models.CharField(max_length=100)
    email = models.EmailField()
    avaliacao = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    titulo = models.CharField(max_length=200)
    comentario = models.TextField()
    recomendacao = models.BooleanField(default=True)
    aprovado = models.BooleanField(default=False)
    data_criacao = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Avaliação de Produto"
        verbose_name_plural = "Avaliações de Produto"
        ordering = ["-data_criacao"]
        indexes = [models.Index(fields=["produto", "aprovado"]), models.Index(fields=["usuario", "produto", "pedido"])]
        unique_together = [("usuario", "produto", "pedido")]

    def __str__(self):
        return f"{self.avaliacao}★ - {self.produto.nome}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self.produto.atualizar_avaliacoes_cache()

    def delete(self, *args, **kwargs):
        produto = self.produto
        super().delete(*args, **kwargs)
        produto.atualizar_avaliacoes_cache()


class Depoimento(models.Model):
    nome_cliente = models.CharField(max_length=100)
    titulo_cliente = models.CharField(max_length=100, default="Cliente Verificado")
    citacao = models.TextField()
    avatar = models.ImageField(upload_to="avatares_depoimentos/", help_text="80x80px")
    avaliacao = models.PositiveSmallIntegerField(default=5, validators=[MinValueValidator(1), MaxValueValidator(5)])
    produto = models.ForeignKey(Produto, on_delete=models.SET_NULL, null=True, blank=True, related_name="depoimentos")
    publicado = models.BooleanField(default=True)
    ordem = models.PositiveIntegerField(default=0)
    data_criacao = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Depoimento"
        verbose_name_plural = "Depoimentos"
        ordering = ["ordem", "-data_criacao"]
        indexes = [models.Index(fields=["publicado", "ordem"])]

    def __str__(self):
        return f"Depoimento de {self.nome_cliente}"


# ═══════════════════════════════════════════════════════════════════════════
# 11. BANNERS E CONFIGURAÇÕES
# ═══════════════════════════════════════════════════════════════════════════
class Banner(models.Model):
    TIPO_CHOICES = [
        ("hero", "Banner hero (slider)"),
        ("cta", "CTA (cards menores)"),
        ("secundario", "Secundário/apoio"),
    ]

    titulo = models.CharField(max_length=150, blank=True)
    subtitulo = models.CharField(max_length=150, blank=True)
    texto_destaque = models.CharField(max_length=150, blank=True)
    imagem = models.ImageField(upload_to="banners/", help_text="1200x400px")
    link_cta = models.URLField(max_length=300, blank=True)
    texto_botao = models.CharField(max_length=50, default="Comprar Agora", blank=True)
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES, default="hero")
    cor_botao = models.CharField(
        max_length=20,
        default="primary",
        choices=[("primary", "Vermelho Principal"), ("secondary", "Laranja Secundário"), ("dark", "Preto")],
    )
    ativo = models.BooleanField(default=True)
    ordem = models.PositiveIntegerField(default=0)
    data_inicio = models.DateTimeField(default=timezone.now)
    data_fim = models.DateTimeField(null=True, blank=True)
    
    # Campos de auditoria
    data_criacao = models.DateTimeField(auto_now_add=True)
    data_atualizacao = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Banner Principal"
        verbose_name_plural = "Banners Principais"
        ordering = ["ordem", "-data_inicio"]
        indexes = [models.Index(fields=["ativo", "data_inicio"])]

    def __str__(self):
        return self.titulo or f"Banner {self.tipo}"

    @property
    def ativo_no_periodo(self):
        agora = timezone.now()
        return self.ativo and self.data_inicio <= agora and (self.data_fim is None or self.data_fim >= agora)


class NewsletterHero(models.Model):
    """Card de destaque do bloco de newsletter na home."""
    
    # Conteúdo principal
    titulo = models.CharField(max_length=120, blank=True)
    subtitulo = models.CharField(max_length=200, blank=True)
    
    # Mídia (imagem ou vídeo)
    imagem = models.ImageField(
        upload_to="newsletter/imagens/", 
        help_text="Imagem de destaque (1920x1080px recomendado)",
        blank=True,
        null=True
    )
    video = models.FileField(
        upload_to="newsletter/videos/",
        blank=True,
        null=True,
        help_text="Vídeo em formato MP4, WebM ou MOV (max 50MB)",
        verbose_name="Arquivo de vídeo"
    )
    
    # Controle do botão
    mostrar_botao = models.BooleanField(
        default=True,
        verbose_name="Exibir botão",
        help_text="Marcar para exibir o botão no modal"
    )
    cta_texto = models.CharField(
        max_length=60, 
        default="Saiba mais",
        blank=True
    )
    cta_link = models.URLField(
        blank=True,
        help_text="Link para onde o botão irá direcionar"
    )
    
    # Configurações
    ativo = models.BooleanField(default=True)
    ordem = models.PositiveIntegerField(default=0)
    
    # Campos automáticos
    data_criacao = models.DateTimeField(auto_now_add=True)
    data_atualizacao = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Newsletter - Hero"
        verbose_name_plural = "Newsletter - Heros"
        ordering = ["ordem", "-id"]

    def __str__(self):
        if self.titulo:
            return self.titulo
        elif self.imagem:
            return f"Newsletter com imagem #{self.id}"
        elif self.video:
            return f"Newsletter com vídeo #{self.id}"
        else:
            return f"Newsletter #{self.id}"

    # Métodos auxiliares
    def tem_midia(self):
        """Verifica se tem imagem ou vídeo"""
        return bool(self.imagem or self.video)
    
    def tem_conteudo(self):
        """Verifica se tem conteúdo para exibir"""
        return bool(self.titulo or self.subtitulo or self.imagem or self.video)
    
    def e_video(self):
        """Verifica se é um vídeo"""
        return bool(self.video)
    
    def deve_exibir_botao(self):
        """Verifica se deve exibir o botão"""
        return self.mostrar_botao and (self.cta_link or self.cta_texto)
    
    def get_texto_botao(self):
        """Retorna o texto do botão"""
        return self.cta_texto if self.cta_texto else "Saiba mais"


class NewsletterLead(models.Model):
    """Leads capturados pelo bloco de newsletter."""

    email = models.EmailField(unique=True)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Lead de Newsletter"
        verbose_name_plural = "Leads de Newsletter"
        ordering = ["-criado_em"]
        indexes = [models.Index(fields=["email"])]

    def __str__(self):
        return self.email


from decimal import Decimal

from django.db import models
from django.core.cache import cache
from django.core.validators import MinValueValidator, MaxValueValidator


class ConfiguracaoSite(models.Model):
    # -----------------------------------------
    # IDENTIDADE
    # -----------------------------------------
    nome_site = models.CharField(max_length=100, default="The Shape Brasil")
    logo = models.ImageField(upload_to="configuracoes/", blank=True, null=True)
    favicon = models.ImageField(upload_to="configuracoes/", blank=True, null=True)

    # -----------------------------------------
    # CONTATOS
    # -----------------------------------------
    telefone = models.CharField(max_length=20, blank=True)
    whatsapp = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)

    instagram_url = models.URLField(blank=True)
    facebook_url = models.URLField(blank=True)
    youtube_url = models.URLField(blank=True)

    # -----------------------------------------
    # FRETE
    # -----------------------------------------
    valor_frete_gratis = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("199.00"))
    valor_frete_padrao = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("15.00"))

    # -----------------------------------------
    # PONTOS & CASHBACK
    # -----------------------------------------
    pontos_por_real_gasto = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("10.00"),
        verbose_name="Pontos por R$ 1,00"
    )
    pontos_minimos_cashback = models.PositiveIntegerField(default=100)
    valor_ponto_em_reais = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("0.01"),
        verbose_name="Quanto vale 1 ponto (R$)"
    )
    pontos_minimos_resgate = models.PositiveIntegerField(
        default=0,
        verbose_name="Pontos mínimos para usar no checkout",
        help_text="0 para liberar qualquer quantidade.",
    )

    cashback_automatico = models.BooleanField(default=True)
    percentual_cashback_padrao = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("2.00"),
        verbose_name="% Cashback Padrão",
        validators=[MinValueValidator(Decimal("0.00")), MaxValueValidator(Decimal("100.00"))]
    )
    cashback_minimo_resgate = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal("0.00"),
        verbose_name="Valor mínimo de cashback para usar no checkout",
        help_text="0 para liberar qualquer valor.",
        validators=[MinValueValidator(Decimal("0.00"))]
    )

    # -----------------------------------------
    # INDICAÇÃO / REFERÊNCIA
    # -----------------------------------------
    bonus_referencia_referidor = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("20.00"),
        verbose_name="Bônus Padrinho (R$)",
        validators=[MinValueValidator(Decimal("0.00"))]
    )
    bonus_referencia_novo = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("10.00"),
        verbose_name="Bônus Novo Usuário (R$)",
        validators=[MinValueValidator(Decimal("0.00"))]
    )
    bonus_pontos_boas_vindas = models.PositiveIntegerField(default=0, verbose_name="Pontos de boas-vindas")

    max_percentual_pontos_resgate = models.PositiveIntegerField(
        default=100,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="% máximo pago com pontos",
    )
    max_percentual_cashback_resgate = models.PositiveIntegerField(
        default=100,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        verbose_name="% máximo pago com cashback",
    )

    referencia_bonus_cadastro_ativo = models.BooleanField(
        default=False, verbose_name="Ativar bônus de referência no cadastro"
    )
    referencia_bonus_cadastro_referidor_cashback = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))]
    )
    referencia_bonus_cadastro_novo_cashback = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))]
    )
    referencia_bonus_cadastro_referidor_pontos = models.PositiveIntegerField(default=0)
    referencia_bonus_cadastro_novo_pontos = models.PositiveIntegerField(default=0)

    # -----------------------------------------
    # FIDELIDADE (DESCONTOS)
    # -----------------------------------------
    fidelidade_bronze_pct = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("0.00"))
    fidelidade_prata_pct = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("3.00"))
    fidelidade_ouro_pct = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("5.00"))
    fidelidade_platina_pct = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("8.00"))
    fidelidade_diamante_pct = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal("10.00"))

    # -----------------------------------------
    # METAS FIDELIDADE
    # -----------------------------------------
    fidelidade_meta_prata = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("500.00"))
    fidelidade_meta_ouro = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("2000.00"))
    fidelidade_meta_platina = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("5000.00"))
    fidelidade_meta_diamante = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("10000.00"))

    # -----------------------------------------
    # AFILIADOS (CONFIG COMPLETA)
    # -----------------------------------------
    afiliado_ativo = models.BooleanField(default=True, verbose_name="Ativar sistema de afiliados")

    # cupom do afiliado (desconto ao comprador)
    afiliado_desconto_padrao = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("5.00"),
        validators=[MinValueValidator(Decimal("0.00")), MaxValueValidator(Decimal("100.00"))],
        verbose_name="% desconto padrão do cupom afiliado"
    )

    # comissão ao afiliado (sobre venda)
    afiliado_comissao_padrao = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("10.00"),
        validators=[MinValueValidator(Decimal("0.00")), MaxValueValidator(Decimal("100.00"))],
        verbose_name="% comissão padrão do afiliado"
    )

    afiliado_comissao_max_pct = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("30.00"),
        validators=[MinValueValidator(Decimal("0.00")), MaxValueValidator(Decimal("100.00"))],
        verbose_name="% teto de comissão (segurança)"
    )

    afiliado_min_pedido = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
        verbose_name="Valor mínimo do pedido para gerar comissão"
    )

    afiliado_max_comissao_por_pedido = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
        verbose_name="Teto de comissão em R$ por pedido",
        help_text="0 = sem limite."
    )

    AFILIADO_BASE_CHOICES = (
        ("itens", "Somente itens (subtotal dos itens)"),
        ("itens_desconto_rateado", "Itens com desconto rateado"),
    )
    afiliado_base_calculo = models.CharField(
        max_length=30, choices=AFILIADO_BASE_CHOICES, default="itens",
        verbose_name="Base de cálculo da comissão"
    )

    afiliado_pagar_somente_entregue = models.BooleanField(
        default=False,
        verbose_name="Pagar comissão somente quando o pedido estiver entregue"
    )

    afiliado_dias_liberacao = models.PositiveSmallIntegerField(
        default=7,
        verbose_name="Dias para liberar comissão",
        help_text="Ex.: 7 = libera 7 dias após pagamento/entrega (conforme sua regra)."
    )

    # regras de criação/gestão de cupons/códigos do afiliado
    afiliado_limite_cupons = models.PositiveIntegerField(default=5)
    afiliado_validade_dias = models.PositiveIntegerField(default=365)
    afiliado_prefixo_codigo = models.CharField(max_length=10, blank=True)
    afiliado_codigo_auto = models.BooleanField(default=True)

    afiliado_saque_minimo = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("50.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
        verbose_name="Saque mínimo do afiliado (R$)"
    )

    # -----------------------------------------
    # SAQUE DE CASHBACK (geral)
    # -----------------------------------------
    cashback_saque_minimo = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("10.00"),
        validators=[MinValueValidator(Decimal("0.00"))]
    )
    cashback_saque_maximo = models.DecimalField(
        max_digits=10, decimal_places=2, default=Decimal("1000.00"),
        validators=[MinValueValidator(Decimal("0.00"))]
    )

    abandono_minutos = models.PositiveIntegerField(default=45)

    # -----------------------------------------
    # SEO
    # -----------------------------------------
    meta_titulo_padrao = models.CharField(max_length=200, blank=True)
    meta_descricao_padrao = models.TextField(blank=True)

    # -----------------------------------------
    # NOVO — MODO MANUTENÇÃO
    # -----------------------------------------
    manutencao_ativa = models.BooleanField(default=False, verbose_name="Ativar modo manutenção")
    mensagem_manutencao = models.TextField(
        default="Estamos realizando melhorias. Voltamos logo! 💙",
        verbose_name="Mensagem exibida no modo manutenção"
    )

    # -----------------------------------------
    # SISTEMA
    # -----------------------------------------
    data_atualizacao = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Configuração do Site"
        verbose_name_plural = "Configuração do Site"

    def __str__(self):
        return f"Configurações - {self.nome_site}"

    # =========================
    # HELPERS AFILIADOS
    # =========================
    def clamp_pct_afiliado(self, pct):
        """
        Garante que a % usada na comissão respeita os limites configurados.
        """
        try:
            pct = Decimal(str(pct or "0"))
        except Exception:
            pct = Decimal("0.00")

        if pct < 0:
            pct = Decimal("0.00")

        teto = self.afiliado_comissao_max_pct or Decimal("0.00")
        if pct > teto:
            pct = teto

        if pct > Decimal("100.00"):
            pct = Decimal("100.00")

        return pct.quantize(Decimal("0.01"))

    def save(self, *args, **kwargs):
        # Garante apenas 1 registro (Singleton)
        self.__class__.objects.exclude(id=self.id).delete()
        super().save(*args, **kwargs)
        cache.delete("configuracao_site")

    @classmethod
    def load(cls):
        config = cache.get("configuracao_site")
        if config is None:
            obj, _ = cls.objects.get_or_create(pk=1)
            config = obj
            cache.set("configuracao_site", config, timeout=3600)
        return config




# ═══════════════════════════════════════════════════════════════════════════
# 12. LOG E ANALYTICS
# ═══════════════════════════════════════════════════════════════════════════
class LogPagamento(models.Model):
    pedido = models.ForeignKey(Pedido, on_delete=models.SET_NULL, related_name="logs_pagamento", null=True, blank=True)
    id_externo = models.CharField(max_length=100, blank=True)
    evento = models.CharField(max_length=50)
    payload_recebido = models.JSONField()
    data_criacao = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Log de Pagamento"
        verbose_name_plural = "Logs de Pagamento"
        ordering = ["-data_criacao"]
        indexes = [models.Index(fields=["id_externo", "evento"])]

    def __str__(self):
        return f"Log ({self.evento}) - {self.id_externo}"


class AnaliticsEvento(models.Model):
    TIPO_EVENTO = [
        ("visualizar_produto", "Visualizar Produto"),
        ("adicionar_carrinho", "Adicionar ao Carrinho"),
        ("remover_carrinho", "Remover do Carrinho"),
        ("aplicar_cupom", "Aplicar Cupom"),
        ("completar_compra", "Completar Compra"),
        ("avaliacao_deixada", "Avaliação Deixada"),
        ("wishlist_add", "Adicionar Wishlist"),
        ("wishlist_remove", "Remover Wishlist"),
    ]

    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name="eventos_analytics", null=True, blank=True)
    tipo_evento = models.CharField(max_length=50, choices=TIPO_EVENTO)
    produto = models.ForeignKey(Produto, on_delete=models.SET_NULL, null=True, blank=True)
    pedido = models.ForeignKey(Pedido, on_delete=models.SET_NULL, null=True, blank=True)
    dados_adicionais = models.JSONField(default=dict, blank=True)
    ip_cliente = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.CharField(max_length=500, blank=True)
    data_evento = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Evento de Analytics"
        verbose_name_plural = "Eventos de Analytics"
        ordering = ["-data_evento"]
        indexes = [
            models.Index(fields=["tipo_evento", "data_evento"]),
            models.Index(fields=["usuario", "data_evento"]),
        ]

    def __str__(self):
        return f"{self.tipo_evento} - {self.usuario.email if self.usuario else 'Anônimo'}"


# ═══════════════════════════════════════════════════════════════════════════
# 13. ABANDONO DE CARRINHO
# ═══════════════════════════════════════════════════════════════════════════
class AbandonoCarrinho(models.Model):
    STATUS = [
        ("pendente", "Pendente"),
        ("enviado", "Enviado"),
        ("ignorado", "Ignorado"),
    ]

    carrinho = models.OneToOneField("Carrinho", on_delete=models.CASCADE, related_name="abandono")
    email_contato = models.EmailField(blank=True)
    subtotal_snapshot = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS, default="pendente")
    data_ultimo_evento = models.DateTimeField(auto_now=True)
    data_disparo = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Abandono de Carrinho"
        verbose_name_plural = "Abandonos de Carrinho"
        indexes = [
            models.Index(fields=["status", "data_ultimo_evento"]),
        ]

    def __str__(self):
        return f"Abandono {self.carrinho_id} - {self.status}"
